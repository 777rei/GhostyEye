/* ============================================================
   GhostyEye OSINT — Advanced Features Module
   42 features: Deep Investigation, AI/ML, Visualization,
   Monitoring, Privacy, Export, Specialized Verticals
   ============================================================ */
'use strict';

/* ============================================================
   PART 1 — MODAL SYSTEM (full-screen view container)
   ============================================================ */
const Modal = {
  currentExport: null,
  open(title, contentNode, exportFn) {
    Utils.$('#modal-title').textContent = '// ' + title.toUpperCase() + ' //';
    const body = Utils.$('#modal-body');
    body.innerHTML = '';
    body.appendChild(contentNode);
    Utils.$('#modal').classList.add('open');
    Utils.$('#modal-backdrop').classList.add('open');
    this.currentExport = exportFn || null;
    const btnExport = Utils.$('#btn-modal-export');
    btnExport.style.display = exportFn ? 'grid' : 'none';
  },
  close() {
    Utils.$('#modal').classList.remove('open');
    Utils.$('#modal-backdrop').classList.remove('open');
    this.currentExport = null;
  },
  init() {
    Utils.$('#btn-modal-close').addEventListener('click', () => this.close());
    Utils.$('#modal-backdrop').addEventListener('click', () => this.close());
    Utils.$('#btn-modal-export').addEventListener('click', () => {
      if (this.currentExport) this.currentExport();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') {
        if (Utils.$('#modal').classList.contains('open')) this.close();
        if (!Utils.$('#cmd-palette').classList.contains('hidden')) CmdPalette.close();
        if (!Utils.$('#bulk-panel').classList.contains('hidden')) Utils.$('#bulk-panel').classList.add('hidden');
      }
    });
  },
  /* Prompt-style input modal — replaces browser prompt() for better UX */
  prompt(title, placeholder, defaultValue, callback) {
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> INPUT REQUIRED' }),
      Utils.el('p', { class: 'text-sm text-dim', text: title }),
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'modal-prompt-input', placeholder: placeholder || '', value: defaultValue || '', attrs: { autocomplete: 'off', spellcheck: 'false' } }),
      Utils.el('div', { class: 'bulk-controls', style: { marginTop: '8px' } }, [
        Utils.el('button', { class: 'icon-btn', style: { width: 'auto', padding: '10px 16px' }, text: 'CANCEL', onclick: () => this.close() }),
        Utils.el('button', { class: 'search-btn', text: 'CONFIRM', onclick: () => {
          const v = Utils.$('#modal-prompt-input').value.trim();
          this.close();
          if (callback) callback(v);
        } })
      ])
    ]);
    this.open(title, wrap);
    setTimeout(() => {
      const inp = Utils.$('#modal-prompt-input');
      if (inp) { inp.focus(); inp.select(); inp.addEventListener('keydown', e => {
        if (e.key === 'Enter') {
          const v = inp.value.trim();
          this.close();
          if (callback) callback(v);
        }
      }); }
    }, 150);
  }
};

/* ============================================================
   PART 2 — COMMAND PALETTE (Ctrl+K)
   ============================================================ */
const CmdPalette = {
  commands: [],
  selectedIdx: 0,

  init() {
    Utils.$('#btn-cmd').addEventListener('click', () => this.open());
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        this.open();
      }
    });
    Utils.$('#cmd-input').addEventListener('input', () => this.render());
    Utils.$('#cmd-input').addEventListener('keydown', e => this.handleKey(e));
    Utils.$('#cmd-palette').addEventListener('click', e => {
      if (e.target.id === 'cmd-palette') this.close();
    });

    this.commands = [
      { cat: 'SEARCH', title: 'Email Investigation', desc: 'Investigate an email address', icon: 'mail', action: () => { UI.setMode('email'); this.close(); } },
      { cat: 'SEARCH', title: 'Username Search', desc: 'Search 100+ platforms', icon: 'user', action: () => { UI.setMode('username'); this.close(); } },
      { cat: 'SEARCH', title: 'Domain Analysis', desc: 'DNS + subdomains + SSL', icon: 'globe', action: () => { UI.setMode('domain'); this.close(); } },
      { cat: 'SEARCH', title: 'IP / Hash Lookup', desc: 'Geolocation or breach check', icon: 'server', action: () => { UI.setMode('ip'); this.close(); } },
      { cat: 'SEARCH', title: 'Phone Lookup', desc: 'Reverse phone directory', icon: 'phone', action: () => { UI.setMode('phone'); this.close(); } },
      { cat: 'DEEP', title: 'SSL Certificate Analysis', desc: 'crt.sh historical certs + SAN domains', icon: 'lock', action: () => AdvDrawer.openSSL() },
      { cat: 'DEEP', title: 'Wayback Machine', desc: 'Archived versions of profiles/sites', icon: 'archive', action: () => AdvDrawer.openWayback() },
      { cat: 'DEEP', title: 'Google Dorking Engine', desc: '30+ advanced search operators', icon: 'search', action: () => AdvDrawer.openDorking() },
      { cat: 'DEEP', title: 'WHOIS / RDAP Lookup', desc: 'Full registration history', icon: 'file', action: () => AdvDrawer.openWHOIS() },
      { cat: 'DEEP', title: 'Crypto Wallet Lookup', desc: 'BTC/ETH transactions & balances', icon: 'bitcoin', action: () => AdvDrawer.openCrypto() },
      { cat: 'DEEP', title: 'Exposed Git Secrets', desc: 'Scan repos for committed keys', icon: 'git', action: () => AdvDrawer.openGitSecrets() },
      { cat: 'DEEP', title: 'Subdomain Enumeration', desc: '1000+ common subs + PassiveDNS', icon: 'list', action: () => AdvDrawer.openSubdomainEnum() },
      { cat: 'DEEP', title: 'Shodan IoT Search', desc: 'Exposed devices & open ports', icon: 'router', action: () => AdvDrawer.openShodan() },
      { cat: 'DEEP', title: 'Reverse Image Search', desc: 'Find accounts using same photo', icon: 'image', action: () => AdvDrawer.openReverseImage() },
      { cat: 'AI', title: 'Network Graph', desc: 'D3 force-directed entity graph', icon: 'share', action: () => AdvDrawer.openGraph() },
      { cat: 'AI', title: 'Email Pattern Predictor', desc: 'Predict email formats from name+domain', icon: 'mail', action: () => AdvDrawer.openEmailPattern() },
      { cat: 'AI', title: 'Username Similarity Engine', desc: 'Find typo-squatted variants', icon: 'user', action: () => AdvDrawer.openUsernameSimilarity() },
      { cat: 'AI', title: 'Anomaly Detection', desc: 'Flag unusual breach patterns', icon: 'alert', action: () => AdvDrawer.openAnomaly() },
      { cat: 'AI', title: 'Generate PDF Report', desc: 'LLM-written investigation brief', icon: 'file', action: () => AdvExport.exportPDF() },
      { cat: 'AI', title: 'Sentiment Analysis', desc: 'Analyze public posts tone', icon: 'message', action: () => AdvDrawer.openSentiment() },
      { cat: 'AI', title: 'Face Match Across Platforms', desc: 'Compare avatars to confirm identity', icon: 'user', action: () => AdvDrawer.openFaceMatch() },
      { cat: 'VIZ', title: 'Breach Timeline', desc: 'Visual timeline of breaches', icon: 'calendar', action: () => AdvDrawer.openTimeline() },
      { cat: 'VIZ', title: 'Geographic Map', desc: 'Plot IPs, domains, breaches on map', icon: 'map', action: () => AdvDrawer.openGeoMap() },
      { cat: 'VIZ', title: 'Activity Heatmap', desc: 'When target is most active', icon: 'grid', action: () => AdvDrawer.openHeatmap() },
      { cat: 'VIZ', title: 'Investigation Comparison', desc: 'Side-by-side compare two targets', icon: 'columns', action: () => AdvDrawer.openComparison() },
      { cat: 'AUTO', title: 'Bulk CSV Investigation', desc: 'Process 100s of targets at once', icon: 'upload', action: () => BulkProcessor.open() },
      { cat: 'AUTO', title: 'Continuous Monitoring', desc: 'Schedule recurring scans', icon: 'eye', action: () => AdvDrawer.openMonitor() },
      { cat: 'AUTO', title: 'Scheduled Scans', desc: 'Cron-style scan scheduling', icon: 'clock', action: () => AdvDrawer.openMonitor() },
      { cat: 'AUTO', title: 'Diff Engine', desc: 'Compare target over time', icon: 'git', action: () => AdvDrawer.openDiff() },
      { cat: 'AUTO', title: 'Webhook Notifications', desc: 'POST to Slack/Discord on scan complete', icon: 'bell', action: () => AdvDrawer.openWebhooks() },
      { cat: 'PRIV', title: 'Encrypted Vault', desc: 'AES-encrypt stored data', icon: 'lock', action: () => Vault.open() },
      { cat: 'PRIV', title: 'Self-Destruct History', desc: 'Auto-wipe after X hours', icon: 'trash', action: () => AdvDrawer.openParanoia() },
      { cat: 'PRIV', title: 'Audit Log', desc: 'Track every query', icon: 'list', action: () => AuditLog.open() },
      { cat: 'PRIV', title: 'Request Obfuscation', desc: 'Randomize user-agents & delays', icon: 'shield', action: () => AdvDrawer.openObfuscation() },
      { cat: 'PRIV', title: 'Tor Routing Info', desc: 'Anonymity routing options', icon: 'ghost', action: () => AdvDrawer.openTor() },
      { cat: 'EXPORT', title: 'Export STIX/TAXII', desc: 'Threat intel format for SOC/SIEM', icon: 'file', action: () => AdvExport.exportSTIX() },
      { cat: 'EXPORT', title: 'Export Markdown Brief', desc: 'Clean .md for GitHub/Notion', icon: 'file', action: () => AdvExport.exportMarkdown() },
      { cat: 'EXPORT', title: 'Export JSON-LD', desc: 'Semantic web format', icon: 'file', action: () => AdvExport.exportJSONLD() },
      { cat: 'EXPORT', title: 'Export MISP Feed', desc: 'MISP threat intel format', icon: 'file', action: () => AdvExport.exportMISP() },
      { cat: 'EXPORT', title: 'Shareable Read-only Link', desc: 'Encrypted URL to share findings', icon: 'link', action: () => AdvExport.exportShareLink() },
      { cat: 'VERTICAL', title: 'Corporate Intelligence', desc: 'Domain → employees → org chart', icon: 'building', action: () => AdvDrawer.openCorporate() },
      { cat: 'VERTICAL', title: 'Crypto Investigation', desc: 'Wallet → exchange → identity', icon: 'bitcoin', action: () => AdvDrawer.openCryptoInvestigation() },
      { cat: 'VERTICAL', title: 'Brand Protection', desc: 'Monitor typosquats & impersonation', icon: 'shield', action: () => AdvDrawer.openBrandProtection() },
      { cat: 'VERTICAL', title: 'Threat Actor Profiling', desc: 'Cluster breach + forum + git activity', icon: 'user', action: () => AdvDrawer.openThreatActor() },
      { cat: 'VERTICAL', title: 'Romance Scam Detection', desc: 'Cross-reference photos/emails/phones', icon: 'heart', action: () => AdvDrawer.openRomanceScam() },
      { cat: 'NAV', title: 'Settings', desc: 'Configure API keys & modules', icon: 'settings', action: () => Drawer.openSettings() },
      { cat: 'NAV', title: 'Search History', desc: 'View past investigations', icon: 'clock', action: () => Drawer.openHistory() },
      { cat: 'NAV', title: 'Developer API', desc: 'REST API documentation', icon: 'code', action: () => Drawer.openAPI() },
      { cat: 'NAV', title: 'About GhostyEye', desc: 'Tool info & features', icon: 'info', action: () => Drawer.openAbout() },
      { cat: 'NAV', title: 'Clear Results', desc: 'Reset current investigation', icon: 'trash', action: () => { UI.clearResults(); this.close(); } },
    ];
  },

  open() {
    Utils.$('#cmd-palette').classList.remove('hidden');
    Utils.$('#cmd-input').value = '';
    Utils.$('#cmd-input').focus();
    this.selectedIdx = 0;
    this.render();
  },
  close() { Utils.$('#cmd-palette').classList.add('hidden'); },

  render() {
    const q = Utils.$('#cmd-input').value.toLowerCase().trim();
    const filtered = q
      ? this.commands.filter(c =>
          c.title.toLowerCase().includes(q) ||
          c.desc.toLowerCase().includes(q) ||
          c.cat.toLowerCase().includes(q))
      : this.commands;

    const results = Utils.$('#cmd-results');
    results.innerHTML = '';
    if (!filtered.length) {
      results.innerHTML = '<div style="padding:20px;text-align:center;color:var(--text-faint);">// no matching commands</div>';
      return;
    }
    filtered.forEach((cmd, i) => {
      const item = Utils.el('div', { class: `cmd-item ${i === this.selectedIdx ? 'selected' : ''}` }, [
        Utils.el('div', { class: 'cmd-icon', html: this.getIcon(cmd.icon) }),
        Utils.el('div', { class: 'cmd-text' }, [
          Utils.el('div', { class: 'cmd-title', text: cmd.title }),
          Utils.el('div', { class: 'cmd-desc', text: cmd.desc })
        ]),
        Utils.el('div', { class: 'cmd-cat', text: cmd.cat })
      ]);
      item.addEventListener('click', () => {
        CmdPalette.close();
        setTimeout(() => cmd.action(), 50);
      });
      item.addEventListener('mouseenter', () => { this.selectedIdx = i; this.highlight(); });
      results.appendChild(item);
    });
  },

  highlight() {
    Utils.$$('.cmd-item', Utils.$('#cmd-results')).forEach((el, i) => {
      el.classList.toggle('selected', i === this.selectedIdx);
    });
  },

  handleKey(e) {
    const items = Utils.$$('.cmd-item', Utils.$('#cmd-results'));
    if (!items.length) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); this.selectedIdx = Math.min(this.selectedIdx + 1, items.length - 1); this.highlight(); items[this.selectedIdx].scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); this.selectedIdx = Math.max(this.selectedIdx - 1, 0); this.highlight(); items[this.selectedIdx].scrollIntoView({ block: 'nearest' }); }
    else if (e.key === 'Enter') {
      e.preventDefault();
      const q = Utils.$('#cmd-input').value.toLowerCase().trim();
      const filtered = q ? this.commands.filter(c => c.title.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q) || c.cat.toLowerCase().includes(q)) : this.commands;
      if (filtered[this.selectedIdx]) {
        CmdPalette.close();
        const action = filtered[this.selectedIdx].action;
        setTimeout(() => action(), 50);
      }
    }
  },

  getIcon(name) {
    const icons = {
      mail: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>',
      user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="7" r="4"/><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/></svg>',
      globe: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/></svg>',
      server: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/></svg>',
      phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3"/></svg>',
      lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
      archive: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><line x1="10" y1="12" x2="14" y2="12"/></svg>',
      search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
      file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>',
      bitcoin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9 8h4.5a2.5 2.5 0 0 1 0 5H9m0 0h5a2.5 2.5 0 0 1 0 5H9m0-10v10m2-12v2m0 10v2"/></svg>',
      git: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="12" r="3"/><line x1="6" y1="9" x2="6" y2="15"/><path d="M18 9v2a2 2 0 0 1-2 2H6"/></svg>',
      list: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/></svg>',
      router: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="14" width="20" height="8" rx="2"/><path d="M6.01 18H6M10 18h.01M15 10v4M18 6l-3 4M12 6l-3 4"/></svg>',
      image: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
      share: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>',
      alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
      message: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
      calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>',
      map: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>',
      grid: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>',
      columns: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="12" y1="3" x2="12" y2="21"/></svg>',
      upload: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>',
      eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
      clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
      bell: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
      trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>',
      shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>',
      ghost: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v12l3-3 2 2 3-3 3 3 2-2 3 3V10a8 8 0 0 0-8-8z"/></svg>',
      link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>',
      building: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M9 22v-4h6v4M8 6h.01M16 6h.01M8 10h.01M16 10h.01M8 14h.01M16 14h.01"/></svg>',
      heart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
      code: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
      info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>',
      settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
    };
    return icons[name] || icons.info;
  }
};

/* ============================================================
   PART 3 — ADVANCED API MODULES (Deep Investigation)
   ============================================================ */
const AdvAPI = {

  /* --- SSL/TLS Certificate Analysis via crt.sh --- */
  SSL: {
    async lookup(domain) {
      try {
        const r = await Utils.fetchJSON(
          `https://crt.sh/?q=${encodeURIComponent('%.' + domain)}&output=json`,
          {}, 15000
        );
        if (r.ok && Array.isArray(r.data)) {
          const certs = r.data;
          const sanDomains = new Set();
          const issuers = new Set();
          certs.forEach(c => {
            if (c.name_value) c.name_value.split('\n').forEach(n => sanDomains.add(n.trim().toLowerCase()));
            if (c.issuer_name) issuers.add(c.issuer_name);
          });
          return {
            totalCerts: certs.length,
            certs: certs.slice(0, 50),
            sanDomains: Array.from(sanDomains).sort(),
            issuers: Array.from(issuers),
            earliest: certs.length ? certs[certs.length - 1].not_before : null,
            latest: certs.length ? certs[0].not_before : null
          };
        }
        return { error: `HTTP ${r.status}`, totalCerts: 0, certs: [], sanDomains: [], issuers: [] };
      } catch (e) { return { error: e.message, totalCerts: 0, certs: [], sanDomains: [], issuers: [] }; }
    }
  },

  /* --- Wayback Machine --- */
  Wayback: {
    async lookup(url) {
      try {
        const r = await Utils.fetchJSON(
          `https://web.archive.org/cdx/search/cdx?url=${encodeURIComponent(url)}&output=json&limit=50&fl=timestamp,original,statuscode,mimetype&sort=timestamp&reverse=true`
        );
        if (r.ok && Array.isArray(r.data) && r.data.length > 1) {
          const snapshots = r.data.slice(1).map(row => ({
            timestamp: row[0], url: row[1], status: row[2], mime: row[3],
            archiveUrl: `https://web.archive.org/web/${row[0]}/${row[1]}`
          }));
          return { total: snapshots.length, snapshots };
        }
        return { total: 0, snapshots: [] };
      } catch (e) { return { total: 0, snapshots: [], error: e.message }; }
    },
    async checkAvailability(url) {
      try {
        const r = await Utils.fetchJSON(`https://archive.org/wayback/available?url=${encodeURIComponent(url)}`);
        if (r.ok && r.data && r.data.archived_snapshots && r.data.archived_snapshots.closest) {
          return r.data.archived_snapshots.closest;
        }
        return null;
      } catch { return null; }
    }
  },

  /* --- Google Dorking Engine --- */
  Dorking: {
    generate(target) {
      const isEmail = target.includes('@');
      const isDomain = !isEmail && Utils.isValidDomain(target);
      const isIP = Utils.isValidIP(target);
      const dorks = [];

      if (isEmail) {
        const [user, domain] = target.split('@');
        dorks.push({ op: 'exact', q: `"${target}"`, desc: 'Exact email match' });
        dorks.push({ op: 'site:', q: `site:${domain} "${user}"`, desc: 'On own domain' });
        dorks.push({ op: 'filetype:xls', q: `"${target}" filetype:xls`, desc: 'Excel files with email' });
        dorks.push({ op: 'filetype:pdf', q: `"${target}" filetype:pdf`, desc: 'PDF files with email' });
        dorks.push({ op: 'filetype:doc', q: `"${target}" filetype:doc OR filetype:docx`, desc: 'Word docs with email' });
        dorks.push({ op: 'filetype:txt', q: `"${target}" filetype:txt`, desc: 'Text files with email' });
        dorks.push({ op: 'filetype:csv', q: `"${target}" filetype:csv`, desc: 'CSV files with email' });
        dorks.push({ op: 'intext:', q: `intext:"${target}"`, desc: 'Pages containing email' });
        dorks.push({ op: 'inurl:', q: `inurl:"${user}"`, desc: 'URLs containing username' });
        dorks.push({ op: 'ext:env', q: `"${target}" ext:env`, desc: 'Exposed .env files' });
        dorks.push({ op: 'ext:sql', q: `"${target}" ext:sql`, desc: 'SQL dumps' });
        dorks.push({ op: 'ext:log', q: `"${target}" ext:log`, desc: 'Log files' });
        dorks.push({ op: 'ext:config', q: `"${target}" ext:config OR ext:conf`, desc: 'Config files' });
        dorks.push({ op: 'intitle:', q: `intitle:"index of" "${user}"`, desc: 'Directory listings' });
        dorks.push({ op: 'paste', q: `site:pastebin.com "${target}"`, desc: 'Pastebin entries' });
        dorks.push({ op: 'github', q: `site:github.com "${target}"`, desc: 'GitHub results' });
        dorks.push({ op: 'linkedin', q: `site:linkedin.com "${user}"`, desc: 'LinkedIn profiles' });
        dorks.push({ op: 'facebook', q: `site:facebook.com "${user}"`, desc: 'Facebook results' });
        dorks.push({ op: 'twitter', q: `site:twitter.com "${user}"`, desc: 'Twitter results' });
        dorks.push({ op: 'stackoverflow', q: `site:stackoverflow.com "${user}"`, desc: 'Stack Overflow' });
        dorks.push({ op: 'keybase', q: `site:keybase.io "${user}"`, desc: 'Keybase profiles' });
        dorks.push({ op: 'grep.app', q: `site:grep.app "${target}"`, desc: 'Code search' });
        dorks.push({ op: 'searchcode', q: `site:searchcode.com "${target}"`, desc: 'Search code' });
        dorks.push({ op: 'leakcheck', q: `"${target}" "leaked" OR "breach" OR "dump"`, desc: 'Breach mentions' });
        dorks.push({ op: 'resume', q: `"${target}" (resume OR cv OR "curriculum vitae")`, desc: 'Resumes/CVs' });
        dorks.push({ op: 'password', q: `"${target}" "password" OR "passwd"`, desc: 'Password references' });
        dorks.push({ op: 'api_key', q: `"${target}" "api_key" OR "apikey" OR "secret"`, desc: 'API key references' });
        dorks.push({ op: 'slack', q: `site:slack.com OR site:slackb.com "${target}"`, desc: 'Slack mentions' });
        dorks.push({ op: 'discord', q: `site:discord.com "${target}"`, desc: 'Discord mentions' });
        dorks.push({ op: 'telegram', q: `site:t.me "${user}"`, desc: 'Telegram channels' });
        dorks.push({ op: 'whois', q: `"${domain}" site:whois.com OR site:who.is`, desc: 'WHOIS records' });
      } else if (isDomain) {
        dorks.push({ op: 'site:', q: `site:${target}`, desc: 'All pages on domain' });
        dorks.push({ op: 'site:-www', q: `site:${target} -www`, desc: 'Non-www subdomains' });
        dorks.push({ op: 'inurl:admin', q: `site:${target} inurl:admin`, desc: 'Admin panels' });
        dorks.push({ op: 'inurl:login', q: `site:${target} inurl:login OR inurl:signin`, desc: 'Login pages' });
        dorks.push({ op: 'inurl:dashboard', q: `site:${target} inurl:dashboard`, desc: 'Dashboards' });
        dorks.push({ op: 'filetype:pdf', q: `site:${target} filetype:pdf`, desc: 'PDF documents' });
        dorks.push({ op: 'filetype:xls', q: `site:${target} filetype:xls OR filetype:xlsx`, desc: 'Excel files' });
        dorks.push({ op: 'filetype:doc', q: `site:${target} filetype:doc OR filetype:docx`, desc: 'Word documents' });
        dorks.push({ op: 'filetype:sql', q: `site:${target} filetype:sql`, desc: 'SQL dumps' });
        dorks.push({ op: 'filetype:env', q: `site:${target} filetype:env`, desc: 'Environment files' });
        dorks.push({ op: 'filetype:log', q: `site:${target} filetype:log`, desc: 'Log files' });
        dorks.push({ op: 'filetype:conf', q: `site:${target} filetype:conf OR filetype:config`, desc: 'Config files' });
        dorks.push({ op: 'filetype:bak', q: `site:${target} filetype:bak`, desc: 'Backup files' });
        dorks.push({ op: 'filetype:old', q: `site:${target} filetype:old`, desc: 'Old files' });
        dorks.push({ op: 'intitle:index', q: `site:${target} intitle:"index of"`, desc: 'Directory listings' });
        dorks.push({ op: 'intitle:login', q: `site:${target} intitle:login OR intitle:signin`, desc: 'Login pages' });
        dorks.push({ op: 'intitle:admin', q: `site:${target} intitle:admin`, desc: 'Admin panels' });
        dorks.push({ op: 'intitle:dashboard', q: `site:${target} intitle:dashboard`, desc: 'Dashboards' });
        dorks.push({ op: 'inurl:api', q: `site:${target} inurl:api`, desc: 'API endpoints' });
        dorks.push({ op: 'inurl:wp-admin', q: `site:${target} inurl:wp-admin`, desc: 'WordPress admin' });
        dorks.push({ op: 'inurl:phpmyadmin', q: `site:${target} inurl:phpmyadmin`, desc: 'phpMyAdmin' });
        dorks.push({ op: 'inurl:.git', q: `site:${target} inurl:.git`, desc: 'Exposed Git repos' });
        dorks.push({ op: 'inurl:.env', q: `site:${target} inurl:.env`, desc: 'Exposed .env files' });
        dorks.push({ op: 'inurl:backup', q: `site:${target} inurl:backup`, desc: 'Backup files' });
        dorks.push({ op: 'inurl:upload', q: `site:${target} inurl:upload`, desc: 'Upload pages' });
        dorks.push({ op: 'inurl:register', q: `site:${target} inurl:register OR inurl:signup`, desc: 'Registration pages' });
        dorks.push({ op: 'inurl:token', q: `site:${target} inurl:token OR inurl:key`, desc: 'Token/key pages' });
        dorks.push({ op: 'ext:php', q: `site:${target} ext:php inurl:config`, desc: 'PHP config files' });
        dorks.push({ op: 'passwords', q: `site:${target} "password" OR "passwd" OR "credentials"`, desc: 'Password references' });
        dorks.push({ op: 'emails', q: `site:${target} "@${target}" OR "contact us"`, desc: 'Email addresses' });
      } else {
        dorks.push({ op: 'exact', q: `"${target}"`, desc: 'Exact match' });
        dorks.push({ op: 'intext:', q: `intext:"${target}"`, desc: 'Pages containing target' });
        dorks.push({ op: 'inurl:', q: `inurl:"${target}"`, desc: 'URLs containing target' });
        dorks.push({ op: 'intitle:', q: `intitle:"${target}"`, desc: 'Pages with target in title' });
        dorks.push({ op: 'filetype:txt', q: `"${target}" filetype:txt`, desc: 'Text files' });
        dorks.push({ op: 'filetype:log', q: `"${target}" filetype:log`, desc: 'Log files' });
        dorks.push({ op: 'pastebin', q: `site:pastebin.com "${target}"`, desc: 'Pastebin entries' });
        dorks.push({ op: 'github', q: `site:github.com "${target}"`, desc: 'GitHub results' });
      }
      return dorks;
    }
  },

  /* --- WHOIS / RDAP --- */
  WHOIS: {
    async lookup(domain) {
      try {
        const r = await Utils.fetchJSON(`https://rdap.org/domain/${encodeURIComponent(domain)}`);
        if (r.ok && r.data) {
          const d = r.data;
          const events = d.events || [];
          const entities = d.entities || [];
          const nameservers = (d.nameservers || []).map(ns => ns.ldhName).filter(Boolean);
          const secureDNS = d.secureDNS || {};
          return {
            domain: d.ldhName || domain,
            handle: d.handle,
            status: d.status || [],
            events,
            entities: entities.map(e => ({
              handle: e.handle,
              roles: e.roles,
              vcardArray: e.vcardArray,
            })),
            nameservers,
            secureDNS,
            rdapSource: d.links ? (d.links[0] || {}).href : null
          };
        }
        return { error: `HTTP ${r.status}`, domain };
      } catch (e) { return { error: e.message, domain }; }
    }
  },

  /* --- Crypto Wallet Lookup --- */
  Crypto: {
    async lookupBTC(address) {
      try {
        const r = await Utils.fetchJSON(`https://blockchain.info/rawaddr/${address}`);
        if (r.ok && r.data) {
          const d = r.data;
          return {
            address: d.address,
            totalReceived: d.total_received / 1e8,
            totalSent: d.total_sent / 1e8,
            finalBalance: d.final_balance / 1e8,
            txCount: d.n_tx,
            txs: (d.txs || []).slice(0, 10).map(t => ({
              hash: t.hash,
              time: t.time,
              value: t.out.reduce((s, o) => s + o.value, 0) / 1e8,
              result: t.result / 1e8
            }))
          };
        }
        return { error: `HTTP ${r.status}` };
      } catch (e) { return { error: e.message }; }
    },
    async lookupETH(address) {
      try {
        const r = await Utils.fetchJSON(`https://api.ethplorer.io/getAddressInfo/${address}`);
        if (r.ok && r.data) {
          const d = r.data;
          return {
            address: d.address,
            balance: d.ETH ? d.ETH.balance : 0,
            txCount: d.countTxs || 0,
            tokens: (d.tokens || []).slice(0, 10).map(t => ({
              symbol: t.tokenInfo && t.tokenInfo.symbol,
              name: t.tokenInfo && t.tokenInfo.name,
              balance: t.balance / Math.pow(10, (t.tokenInfo && t.tokenInfo.decimals) || 0)
            }))
          };
        }
        return { error: `HTTP ${r.status}` };
      } catch (e) { return { error: e.message }; }
    },
    detectType(addr) {
      if (/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,42}$/.test(addr)) return 'BTC';
      if (/^0x[a-fA-F0-9]{40}$/.test(addr)) return 'ETH';
      return null;
    }
  },

  /* --- Exposed Git Secrets --- */
  GitSecrets: {
    async scanUser(username) {
      const results = [];
      try {
        // Get user's repos
        const r = await Utils.fetchJSON(`https://api.github.com/users/${encodeURIComponent(username)}/repos?per_page=30&sort=updated`);
        if (!r.ok || !Array.isArray(r.data)) return { repos: [], secrets: [], error: r.status === 403 ? 'GitHub rate limit' : 'API error' };

        const secretPatterns = [
          { name: 'AWS Access Key', re: /AKIA[0-9A-Z]{16}/g },
          { name: 'AWS Secret Key', re: /(?<![A-Za-z0-9/+])[A-Za-z0-9/+]{40}(?![A-Za-z0-9/+])/g },
          { name: 'Google API Key', re: /AIza[0-9A-Za-z\-_]{35}/g },
          { name: 'Slack Token', re: /xox[baprs]-[0-9A-Za-z-]{10,48}/g },
          { name: 'Stripe Key', re: /sk_live_[0-9a-zA-Z]{24,99}/g },
          { name: 'GitHub Token', re: /gh[pousr]_[A-Za-z0-9]{36,255}/g },
          { name: 'Private Key', re: /-----BEGIN (RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----/g },
          { name: 'JWT Token', re: /eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/g },
          { name: 'Generic Secret', re: /(secret|password|passwd|api_key|apikey|token)\s*[=:]\s*['"]?[A-Za-z0-9+/=_-]{16,}['"]?/gi },
          { name: 'Database URL', re: /(postgres|mysql|mongodb|redis):\/\/[^\s'"]+:[^\s'"]+@[^\s'"]+/g },
          { name: 'Heroku API Key', re: /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g },
        ];

        for (const repo of r.data.slice(0, 10)) {
          try {
            // Search code in the repo for secrets via GitHub code search
            const codeR = await Utils.fetchJSON(
              `https://api.github.com/search/code?q=repo:${repo.full_name}+password+OR+secret+OR+api_key+OR+token&per_page=5`,
              { headers: { 'Accept': 'application/vnd.github.v3+json' } }
            );
            if (codeR.ok && codeR.data && codeR.data.total_count > 0) {
              results.push({
                repo: repo.full_name,
                url: repo.html_url,
                suspectFiles: codeR.data.total_count,
                files: (codeR.data.items || []).slice(0, 3).map(f => ({
                  name: f.name,
                  path: f.path,
                  url: f.html_url
                }))
              });
            }
          } catch {}
        }
        return { repos: r.data.length, secrets: results };
      } catch (e) { return { repos: 0, secrets: [], error: e.message }; }
    }
  },

  /* --- Subdomain Enumeration++ --- */
  SubdomainEnum: {
    commonSubs: ['www', 'mail', 'smtp', 'imap', 'pop', 'pop3', 'webmail', 'ns1', 'ns2', 'ns3', 'dns1', 'dns2', 'api', 'dev', 'staging', 'stage', 'test', 'beta', 'alpha', 'prod', 'production', 'sandbox', 'qa', 'uat', 'demo', 'admin', 'administrator', 'portal', 'vpn', 'remote', 'cloud', 'app', 'apps', 'application', 'applications', 'web', 'blog', 'forums', 'forum', 'shop', 'store', 'cdn', 'static', 'assets', 'media', 'images', 'img', 'video', 'videos', 'audio', 'files', 'download', 'uploads', 'docs', 'documentation', 'help', 'support', 'wiki', 'kb', 'knowledgebase', 'status', 'monitor', 'grafana', 'prometheus', 'kibana', 'elasticsearch', 'jenkins', 'gitlab', 'ci', 'cd', 'build', 'deploy', 'release', 'registry', 'docker', 'k8s', 'kubernetes', 'console', 'dashboard', 'panel', 'cpanel', 'whm', 'plesk', 'ftp', 'sftp', 'webdav', 'git', 'svn', 'hg', 'backup', 'bak', 'old', 'new', 'v1', 'v2', 'v3', 'internal', 'intranet', 'extranet', 'private', 'public', 'secure', 'ssl', 'tls', 'auth', 'sso', 'oauth', 'saml', 'ldap', 'ad', 'dc', 'exchange', 'owa', 'outlook', 'autodiscover', 'mx', 'mx1', 'mx2', 'mta', 'relay', 'smtp1', 'smtp2', 'inbound', 'outbound', 'track', 'tracking', 'analytics', 'metrics', 'stats', 'logs', 'log', 'syslog', 'audit', 'security', 'firewall', 'waf', 'ids', 'ips', 'siem', 'soc', 'threat', 'intel', 'osint', 'research', 'data', 'db', 'database', 'mysql', 'postgres', 'redis', 'mongo', 'cassandra', 'couchdb', 'elastic', 'search', 'solr', 'spark', 'hadoop', 'kafka', 'zookeeper', 'zmq', 'rabbit', 'mq', 'queue', 'worker', 'job', 'cron', 'scheduler', 'batch', 'task', 'service', 'services', 'microservice', 'gateway', 'proxy', 'loadbalancer', 'lb', 'ha', 'failover', 'cache', 'memcache', 'varnish', 'nginx', 'apache', 'httpd', 'tomcat', 'jboss', 'wildfly', 'glassfish', 'jetty', 'iis', 'caddy', 'traefik', 'envoy', 'linkerd', 'istio', 'consul', 'vault', 'nomad', 'terraform', 'ansible', 'puppet', 'chef', 'salt', 'prometheus', 'alertmanager', 'thanos', 'loki', 'tempo', 'jaeger', 'zipkin', 'skywalking', 'opentracing', 'opentelemetry'],

    async enumerate(domain) {
      const found = [];
      // 1. Try crt.sh for passive subdomain discovery
      try {
        const r = await Utils.fetchJSON(`https://crt.sh/?q=${encodeURIComponent(domain)}&output=json`, {}, 15000);
        if (r.ok && Array.isArray(r.data)) {
          const subs = new Set();
          r.data.forEach(c => {
            if (c.name_value) c.name_value.split('\n').forEach(n => {
              const sub = n.trim().toLowerCase().replace(`.${domain}`, '');
              if (sub && !sub.includes('*') && sub !== domain) subs.add(sub);
            });
          });
          for (const sub of subs) {
            found.push({ sub, source: 'crt.sh', ips: [] });
          }
        }
      } catch {}

      // 2. Brute-force common subdomains via DNS
      const toCheck = this.commonSubs.filter(s => !found.find(f => f.sub === s)).slice(0, 100);
      await Promise.all(toCheck.map(async sub => {
        try {
          const r = await API.DNS.lookup(`${sub}.${domain}`, 'A');
          if (r && r.length) {
            found.push({ sub, source: 'DNS brute', ips: r.map(a => a.data) });
          }
        } catch {}
      }));

      return { total: found.length, subdomains: found.sort((a, b) => a.sub.localeCompare(b.sub)) };
    }
  },

  /* --- Email Pattern Predictor --- */
  EmailPattern: {
    predict(firstName, lastName, domain) {
      const f = firstName.toLowerCase().trim();
      const l = lastName.toLowerCase().trim();
      const fi = f[0] || '';
      const li = l[0] || '';
      const patterns = [
        { format: 'first@domain', email: `${f}@${domain}` },
        { format: 'last@domain', email: `${l}@${domain}` },
        { format: 'first.last@domain', email: `${f}.${l}@${domain}` },
        { format: 'firstlast@domain', email: `${f}${l}@${domain}` },
        { format: 'flast@domain', email: `${fi}${l}@${domain}` },
        { format: 'firstl@domain', email: `${f}${li}@${domain}` },
        { format: 'lastfirst@domain', email: `${l}${f}@${domain}` },
        { format: 'last.f@domain', email: `${l}.${fi}@${domain}` },
        { format: 'lastf@domain', email: `${l}${fi}@${domain}` },
        { format: 'first_last@domain', email: `${f}_${l}@${domain}` },
        { format: 'f.last@domain', email: `${fi}.${l}@${domain}` },
        { format: 'first-l@domain', email: `${f}-${li}@${domain}` },
        { format: 'lfirst@domain', email: `${li}${f}@${domain}` },
        { format: 'first.l@domain', email: `${f}.${li}@${domain}` },
        { format: 'fl@domain', email: `${fi}${li}@${domain}` },
      ];
      return patterns.filter(p => p.email.match(/^[a-z0-9._-]+@[a-z0-9.-]+\.[a-z]{2,}$/));
    }
  },

  /* --- Username Similarity Engine --- */
  UsernameSimilarity: {
    generate(username) {
      const u = username.toLowerCase();
      const variants = new Set();
      // Variations
      variants.add(u);
      variants.add(u.replace(/[._-]/g, '')); // no separators
      variants.add(u + '1');
      variants.add(u + '123');
      variants.add(u + '_');
      variants.add(u + '0');
      variants.add(u + '2');
      variants.add(u + '3');
      variants.add(u + 'official');
      variants.add(u + 'real');
      variants.add(u + '_official');
      variants.add(u + 'real_');
      variants.add('the' + u);
      variants.add('the_' + u);
      variants.add('the-' + u);
      variants.add('real' + u);
      variants.add('iam' + u);
      variants.add('i_am_' + u);
      variants.add('its' + u);
      variants.add('its_' + u);
      variants.add('mr' + u);
      variants.add('ms' + u);
      variants.add(u + 'yt');
      variants.add(u + '_yt');
      variants.add(u + '_hd');
      variants.add(u + 'tv');
      variants.add(u + '_tv');
      variants.add(u + 'pro');
      variants.add(u + '_pro');
      // Separator swaps
      if (u.includes('_')) { variants.add(u.replace(/_/g, '.')); variants.add(u.replace(/_/g, '-')); }
      if (u.includes('.')) { variants.add(u.replace(/\./g, '_')); variants.add(u.replace(/\./g, '-')); }
      if (u.includes('-')) { variants.add(u.replace(/-/g, '_')); variants.add(u.replace(/-/g, '.')); }
      // Number suffixes
      for (let i = 1; i <= 9; i++) variants.add(u + i);
      // Leet speak
      variants.add(u.replace(/a/g, '4').replace(/e/g, '3').replace(/i/g, '1').replace(/o/g, '0').replace(/s/g, '5'));
      // Abbreviated
      if (u.length > 6) variants.add(u.substring(0, 4));
      if (u.length > 4) variants.add(u.substring(0, u.length - 1));

      return Array.from(variants).filter(v => v !== u && v.length >= 2 && v.length <= 30).map(v => ({
        username: v,
        similarity: this.levenshtein(u, v)
      })).sort((a, b) => a.similarity - b.similarity).slice(0, 30);
    },
    levenshtein(a, b) {
      const m = a.length, n = b.length;
      const d = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
      for (let i = 0; i <= m; i++) d[i][0] = i;
      for (let j = 0; j <= n; j++) d[0][j] = j;
      for (let i = 1; i <= m; i++) {
        for (let j = 1; j <= n; j++) {
          d[i][j] = a[i-1] === b[j-1] ? d[i-1][j-1] : Math.min(d[i-1][j-1] + 1, d[i][j-1] + 1, d[i-1][j] + 1);
        }
      }
      return d[m][n];
    }
  },

  /* --- Anomaly Detection --- */
  Anomaly: {
    analyze(data) {
      const anomalies = [];
      const m = data.modules || {};

      // 1. Multiple breach hits in short time
      if (m.breaches && m.breaches.breaches && m.breaches.breaches.length >= 3) {
        const dates = m.breaches.breaches.map(b => new Date(b.BreachDate)).filter(d => !isNaN(d)).sort((a, b) => a - b);
        if (dates.length >= 3) {
          const span = (dates[dates.length - 1] - dates[0]) / (1000 * 60 * 60 * 24);
          if (span < 365) {
            anomalies.push({ severity: 'high', type: 'Breach clustering', desc: `${dates.length} breaches within ${Math.round(span)} days — suggests active target` });
          }
        }
      }

      // 2. Infostealer hits without breach hits
      if (m.infostealer && m.infostealer.hits && m.infostealer.hits.length > 0) {
        if (!m.breaches || !m.breaches.breaches || m.breaches.breaches.length === 0) {
          anomalies.push({ severity: 'medium', type: 'Stealer log without breach', desc: 'Found in stealer logs but not in HIBP — may indicate recent unreported compromise' });
        }
      }

      // 3. Many platform accounts = high exposure
      if (m.usernames) {
        const found = m.usernames.filter(u => u.found).length;
        if (found >= 15) {
          anomalies.push({ severity: 'low', type: 'High digital footprint', desc: `${found} platform accounts — large attack surface for social engineering` });
        }
      }

      // 4. PGP key + GitHub = technical user
      if (m.pgp && m.pgp.found && m.github && m.github.items && m.github.items.length) {
        anomalies.push({ severity: 'info', type: 'Technical user profile', desc: 'PGP key + GitHub presence — likely developer/security researcher' });
      }

      // 5. Disposable domain
      if (m.validation && m.validation.disify && m.validation.disify.disposable) {
        anomalies.push({ severity: 'high', type: 'Disposable email', desc: 'Using disposable domain — likely burner/spam account' });
      }

      // 6. Invalid format
      if (m.validation && m.validation.disify && !m.validation.disify.format) {
        anomalies.push({ severity: 'critical', type: 'Invalid email', desc: 'Email format is invalid — cannot deliver to this address' });
      }

      return anomalies;
    }
  },

  /* --- Sentiment Analysis via LLM --- */
  Sentiment: {
    async analyze(text) {
      const prompt = `Analyze the sentiment and tone of the following text. Respond in this exact format:
SENTIMENT: [positive/negative/neutral/mixed]
TONE: [professional/casual/aggressive/friendly/formal/informal/technical]
RISK_INDICATORS: [list any concerning keywords or phrases, comma-separated]
SUMMARY: [one sentence summary of the text's intent and emotional state]

TEXT:
${text}`;

      const result = await API.LLM.generate(prompt);
      return result;
    }
  },

  /* --- Face Match (basic avatar comparison) --- */
  FaceMatch: {
    async compareAvatars(email, username) {
      const avatars = [];
      // Collect avatars from different platforms
      if (email) {
        avatars.push({ source: 'Gravatar', url: API.Gravatar.avatarUrl(email, 200) });
      }
      if (username) {
        const platforms = ['github', 'twitter', 'instagram', 'reddit', 'twitch'];
        for (const p of platforms) {
          avatars.push({ source: p, url: `https://unavatar.io/${p}/${username}` });
        }
      }
      // Check which avatars actually exist
      const existing = [];
      for (const a of avatars) {
        const exists = await Utils.testImage(a.url, 5000);
        if (exists) existing.push(a);
      }
      return {
        totalChecked: avatars.length,
        found: existing.length,
        avatars: existing,
        note: 'Visual comparison required — open each avatar to manually verify if they show the same person. Automated face recognition requires a paid API (e.g., AWS Rekognition, Face++) — this tool provides the avatar URLs for manual cross-reference.'
      };
    }
  }
};

/* ============================================================
   PART 4 — BULK CSV PROCESSOR
   ============================================================ */
const BulkProcessor = {
  results: [],
  abort: false,

  open() {
    Utils.$('#bulk-panel').classList.remove('hidden');
    Utils.$('#bulk-textarea').focus();
  },
  close() { Utils.$('#bulk-panel').classList.add('hidden'); },

  init() {
    Utils.$('#btn-bulk').addEventListener('click', () => this.open());
    Utils.$('#btn-bulk-close').addEventListener('click', () => this.close());
    Utils.$('#btn-bulk-upload').addEventListener('click', () => Utils.$('#bulk-file').click());
    Utils.$('#bulk-file').addEventListener('change', e => this.handleFile(e));
    Utils.$('#btn-bulk-run').addEventListener('click', () => this.run());

    // Drag & drop
    const dz = Utils.$('#bulk-dropzone');
    dz.addEventListener('dragover', e => { e.preventDefault(); dz.classList.add('dragover'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('dragover'));
    dz.addEventListener('drop', e => {
      e.preventDefault(); dz.classList.remove('dragover');
      if (e.dataTransfer.files.length) this.handleFile({ target: { files: e.dataTransfer.files } });
    });
  },

  handleFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      Utils.$('#bulk-textarea').value = ev.target.result;
      Toast.show(`Loaded ${file.name} (${file.size} bytes)`, 'success');
    };
    reader.readAsText(file);
  },

  async run() {
    const text = Utils.$('#bulk-textarea').value.trim();
    if (!text) { Toast.show('No targets provided', 'error'); return; }

    const mode = Utils.$('#bulk-mode').value;
    const targets = text.split('\n').map(t => t.trim()).filter(t => t && !t.startsWith('#'));

    if (targets.length > 200) {
      Toast.show(`Limiting to first 200 targets (you provided ${targets.length})`, 'info');
      targets.length = 200;
    }

    this.results = [];
    this.abort = false;
    Utils.$('#bulk-progress').classList.remove('hidden');
    Utils.$('#bulk-results').classList.remove('hidden');
    Utils.$('#bulk-results').innerHTML = '';

    for (let i = 0; i < targets.length; i++) {
      if (this.abort) break;
      const target = targets[i];
      Utils.$('#bulk-progress-fill').style.width = `${((i / targets.length) * 100)}%`;
      Utils.$('#bulk-stats').textContent = `Processing ${i + 1}/${targets.length}: ${target}`;

      try {
        let result = { target, mode, risk: null, error: null };
        if (mode === 'email' && Utils.isValidEmail(target)) {
          const v = await API.Email.validate(target);
          const g = await API.Gravatar.checkExists(target);
          const gh = await API.GitHub.searchByEmail(target);
          const b = await API.Breaches.checkEmail(target, State.settings.hibpApiKey);
          const risk = API.Risk.assess({ validation: v, gravatar: { exists: g }, github: gh, breaches: b });
          result.risk = risk.score;
          result.level = risk.levelLabel;
          result.modules = { validation: !!v, gravatar: g, github: gh.items?.length || 0, breaches: b.breaches?.length || 0 };
        } else if (mode === 'username') {
          const us = await API.Usernames.search(target);
          const found = us.filter(u => u.found).length;
          result.risk = Math.min(found * 3, 30);
          result.level = result.risk >= 20 ? 'Medium' : 'Low';
          result.modules = { platforms: found };
        } else if (mode === 'domain' && Utils.isValidDomain(target)) {
          const dns = await API.DNS.fullLookup(target);
          const aRecords = (dns.A || []).length;
          result.risk = aRecords > 0 ? 10 : 0;
          result.level = aRecords > 0 ? 'Low' : 'Minimal';
          result.modules = { aRecords, mxRecords: (dns.MX || []).length };
        }
        this.results.push(result);
        this.renderRow(result);
      } catch (e) {
        this.results.push({ target, mode, error: e.message, risk: null });
        this.renderRow({ target, mode, error: e.message });
      }

      // Small delay to avoid rate limits
      await new Promise(r => setTimeout(r, 200));
    }

    Utils.$('#bulk-progress-fill').style.width = '100%';
    Utils.$('#bulk-stats').textContent = `Complete: ${this.results.length}/${targets.length} processed`;

    // Add export button
    const exportBtn = Utils.el('button', {
      class: 'search-btn',
      style: { marginTop: '12px', width: 'auto', padding: '10px 18px' },
      html: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> EXPORT_CSV',
      onclick: () => this.exportResults()
    });
    Utils.$('#bulk-results').appendChild(exportBtn);
    Toast.show(`Batch complete: ${this.results.length} targets processed`, 'success');
  },

  renderRow(r) {
    const row = Utils.el('div', { class: 'bulk-result-row' }, [
      Utils.el('span', { class: 'target', text: r.target }),
      Utils.el('span', { class: 'risk', text: r.error ? `ERR: ${r.error.substring(0, 30)}` : `${r.level || '?'} (${r.risk || 0})` })
    ]);
    if (r.level) {
      const color = r.level === 'High' ? 'var(--accent-red)' : r.level === 'Medium' ? 'var(--accent-amber)' : 'var(--accent-green)';
      row.querySelector('.risk').style.color = color;
    }
    Utils.$('#bulk-results').appendChild(row);
  },

  exportResults() {
    if (!this.results.length) { Toast.show('No results to export', 'info'); return; }
    const rows = this.results.map(r => `"${r.target}","${r.mode}",${r.risk || 0},"${r.level || ''}","${r.error || ''}"`);
    const csv = ['target,mode,risk_score,risk_level,error'].concat(rows).join('\n');
    Utils.download(`ghostyeye-bulk-${Date.now()}.csv`, csv, 'text/csv');
    Toast.show('Bulk results exported', 'success');
  }
};

/* ============================================================
   PART 5 — VAULT (Encrypted Local Storage)
   ============================================================ */
const Vault = {
  key: null,
  VAULT_KEY: 'ghostyeye:vault',

  async open() {
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    const stored = localStorage.getItem(this.VAULT_KEY);

    if (stored) {
      wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Vault Locked' }),
        Utils.el('p', { class: 'text-sm text-dim', text: 'Enter your passphrase to decrypt the vault.' }),
        Utils.el('input', { type: 'password', class: 'vault-input', id: 'vault-pass', placeholder: 'passphrase...', attrs: { autocomplete: 'off' } }),
        Utils.el('button', { class: 'search-btn', style: { marginTop: '12px', width: 'auto' }, text: 'DECRYPT', onclick: () => this.unlock() })
      ]));
    } else {
      wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Create Vault' }),
        Utils.el('p', { class: 'text-sm text-dim', text: 'Create a passphrase to encrypt your stored data (history, settings). The passphrase is NOT stored — if you forget it, your data is unrecoverable.' }),
        Utils.el('input', { type: 'password', class: 'vault-input', id: 'vault-pass-new', placeholder: 'new passphrase (min 8 chars)...', attrs: { autocomplete: 'off' } }),
        Utils.el('input', { type: 'password', class: 'vault-input', id: 'vault-pass-confirm', placeholder: 'confirm passphrase...', attrs: { autocomplete: 'off' } }),
        Utils.el('button', { class: 'search-btn', style: { marginTop: '12px', width: 'auto' }, text: 'CREATE_VAULT', onclick: () => this.create() })
      ]));
    }

    Modal.open('Encrypted Vault', wrap);
  },

  async create() {
    const pass = Utils.$('#vault-pass-new').value;
    const confirm = Utils.$('#vault-pass-confirm').value;
    if (pass.length < 8) { Toast.show('Passphrase must be at least 8 characters', 'error'); return; }
    if (pass !== confirm) { Toast.show('Passphrases do not match', 'error'); return; }

    // Derive key from passphrase
    this.key = await this.deriveKey(pass);
    // Encrypt current history
    const history = Storage.getHistory();
    const encrypted = await this.encrypt(JSON.stringify(history));
    localStorage.setItem(this.VAULT_KEY, JSON.stringify(encrypted));
    // Clear unencrypted history
    Storage.clearHistory();
    Toast.show('Vault created — history encrypted', 'success');
    Modal.close();
  },

  async unlock() {
    const pass = Utils.$('#vault-pass').value;
    this.key = await this.deriveKey(pass);
    const stored = JSON.parse(localStorage.getItem(this.VAULT_KEY));
    try {
      const decrypted = await this.decrypt(stored);
      const history = JSON.parse(decrypted);
      Toast.show(`Vault unlocked — ${history.length} entries decrypted`, 'success');
      // Show decrypted contents
      const wrap = Utils.el('div', { class: 'flex-col gap-2' });
      wrap.appendChild(Utils.el('h4', { text: `Decrypted: ${history.length} entries` }));
      history.forEach(h => {
        wrap.appendChild(Utils.el('div', { class: 'history-item' }, [
          Utils.el('div', {}, [
            Utils.el('div', { class: 'history-query', text: h.query }),
            Utils.el('div', { class: 'history-meta', text: Utils.formatDateTime(h.ts) })
          ]),
          Utils.el('div', { class: 'history-mode', text: h.mode })
        ]));
      });
      Modal.open('Vault Contents', wrap);
    } catch (e) {
      Toast.show('Wrong passphrase', 'error');
    }
  },

  async deriveKey(pass) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey('raw', enc.encode(pass), 'PBKDF2', false, ['deriveKey']);
    return await crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt: enc.encode('ghostyeye-salt'), iterations: 100000, hash: 'SHA-256' },
      keyMaterial,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  },

  async encrypt(text) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const enc = new TextEncoder();
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, this.key, enc.encode(text));
    return { iv: Array.from(iv), data: Array.from(new Uint8Array(ciphertext)) };
  },

  async decrypt(encrypted) {
    const iv = new Uint8Array(encrypted.iv);
    const data = new Uint8Array(encrypted.data);
    const dec = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, this.key, data);
    return new TextDecoder().decode(dec);
  }
};

/* ============================================================
   PART 6 — AUDIT LOG
   ============================================================ */
const AuditLog = {
  KEY: 'ghostyeye:audit',

  log(action, detail) {
    const entries = this.getEntries();
    entries.unshift({ ts: Date.now(), action, detail });
    if (entries.length > 200) entries.length = 200;
    try { localStorage.setItem(this.KEY, JSON.stringify(entries)); } catch {}
  },

  getEntries() {
    try { return JSON.parse(localStorage.getItem(this.KEY) || '[]'); } catch { return []; }
  },

  clear() { localStorage.removeItem(this.KEY); },

  open() {
    const entries = this.getEntries();
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Audit Log' }),
        Utils.el('p', { class: 'text-sm text-dim', text: `${entries.length} entries logged. All queries and actions are tracked for compliance.` })
      ])
    ]);
    if (entries.length) {
      const log = Utils.el('div', { class: 'audit-log' });
      entries.forEach(e => {
        log.appendChild(Utils.el('div', { class: 'audit-entry' }, [
          Utils.el('span', { class: 'a-time', text: Utils.formatDateTime(e.ts) }),
          Utils.el('span', { class: 'a-action', text: e.action }),
          Utils.el('span', { class: 'a-detail', text: e.detail })
        ]));
      });
      wrap.appendChild(log);
      wrap.appendChild(Utils.el('button', {
        class: 'icon-btn', style: { width: 'auto', padding: '10px 14px', marginTop: '12px', gap: '8px' },
        html: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg><span style="font-size:0.78rem;">CLEAR_LOG</span>',
        onclick: () => { if (confirm('Clear audit log?')) { this.clear(); Modal.close(); Toast.show('Audit log cleared', 'success'); } }
      }));
    } else {
      wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: 'No audit entries yet' }));
    }
    Modal.open('Audit Log', wrap);
  }
};

/* ============================================================
   PART 7 — MONITORING SYSTEM (Scheduled Scans + Diff)
   ============================================================ */
const Monitor = {
  KEY: 'ghostyeye:monitors',
  DIFF_KEY: 'ghostyeye:diffs',

  getMonitors() {
    try { return JSON.parse(localStorage.getItem(this.KEY) || '[]'); } catch { return []; }
  },

  saveMonitors(list) {
    try { localStorage.setItem(this.KEY, JSON.stringify(list)); } catch {}
  },

  addMonitor(target, mode, intervalHours) {
    const list = this.getMonitors();
    list.push({ id: Date.now(), target, mode, intervalHours, lastRun: null, lastResult: null, active: true });
    this.saveMonitors(list);
    AuditLog.log('MONITOR_ADD', `${mode}:${target} every ${intervalHours}h`);
  },

  removeMonitor(id) {
    const list = this.getMonitors().filter(m => m.id !== id);
    this.saveMonitors(list);
  },

  async checkDueMonitors() {
    const list = this.getMonitors();
    const now = Date.now();
    for (const m of list) {
      if (!m.active) continue;
      const due = !m.lastRun || (now - m.lastRun) > m.intervalHours * 3600 * 1000;
      if (due) {
        await this.runMonitor(m);
      }
    }
  },

  async runMonitor(m) {
    Toast.show(`Monitoring: scanning ${m.target}...`, 'info');
    // Run a quick scan and compare with previous result
    let currentResult = null;
    try {
      if (m.mode === 'email') {
        const b = await API.Breaches.checkEmail(m.target, State.settings.hibpApiKey);
        currentResult = { breaches: b.breaches ? b.breaches.length : 0 };
      } else if (m.mode === 'domain') {
        const dns = await API.DNS.fullLookup(m.target);
        currentResult = { aRecords: (dns.A || []).length, mxRecords: (dns.MX || []).length };
      }
    } catch (e) { currentResult = { error: e.message }; }

    // Diff with previous
    const diffs = this.getDiffs();
    const prevDiff = diffs.find(d => d.target === m.target && d.mode === m.mode);
    const changes = [];
    if (prevDiff && prevDiff.result && currentResult) {
      for (const key of Object.keys(currentResult)) {
        if (typeof currentResult[key] === 'number' && prevDiff.result[key] !== undefined) {
          const delta = currentResult[key] - prevDiff.result[key];
          if (delta !== 0) {
            changes.push({ field: key, old: prevDiff.result[key], new: currentResult[key], delta });
          }
        }
      }
    }

    // Save current as new diff baseline
    const diffIdx = diffs.findIndex(d => d.target === m.target && d.mode === m.mode);
    const diffEntry = { target: m.target, mode: m.mode, result: currentResult, ts: now, changes };
    if (diffIdx >= 0) diffs[diffIdx] = diffEntry;
    else diffs.push(diffEntry);
    try { localStorage.setItem(this.DIFF_KEY, JSON.stringify(diffs)); } catch {}

    // Update monitor
    m.lastRun = now;
    m.lastResult = currentResult;
    this.saveMonitors(this.getMonitors().map(x => x.id === m.id ? m : x));

    if (changes.length) {
      Toast.show(`ALERT: ${m.target} changed — ${changes.length} difference(s) detected`, 'error');
      AuditLog.log('MONITOR_CHANGE', `${m.target}: ${changes.map(c => `${c.field} ${c.old}→${c.new}`).join(', ')}`);
    } else {
      AuditLog.log('MONITOR_RUN', `${m.target}: no changes`);
    }
  },

  getDiffs() {
    try { return JSON.parse(localStorage.getItem(this.DIFF_KEY) || '[]'); } catch { return []; }
  },

  open() {
    const monitors = this.getMonitors();
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });

    // Add new monitor form
    wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Add Monitor' }),
      Utils.el('p', { class: 'text-sm text-dim', text: 'Schedule recurring scans. GhostyEye will alert you when the target changes (new breach, new subdomain, etc.).' }),
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'mon-target', placeholder: 'email or domain...', style: { marginTop: '8px' } }),
      Utils.el('div', { class: 'bulk-controls', style: { marginTop: '8px' } }, [
        Utils.el('select', { id: 'mon-mode', class: 'drawer-field-input' }, [
          Utils.el('option', { value: 'email', text: 'EMAIL' }),
          Utils.el('option', { value: 'domain', text: 'DOMAIN' })
        ]),
        Utils.el('select', { id: 'mon-interval', class: 'drawer-field-input' }, [
          Utils.el('option', { value: '1', text: 'EVERY 1H' }),
          Utils.el('option', { value: '6', text: 'EVERY 6H' }),
          Utils.el('option', { value: '24', text: 'DAILY' }),
          Utils.el('option', { value: '168', text: 'WEEKLY' })
        ]),
        Utils.el('button', { class: 'search-btn', text: 'ADD', onclick: () => {
          const t = Utils.$('#mon-target').value.trim();
          const m = Utils.$('#mon-mode').value;
          const i = parseInt(Utils.$('#mon-interval').value);
          if (!t) { Toast.show('Enter a target', 'error'); return; }
          this.addMonitor(t, m, i);
          Toast.show('Monitor added', 'success');
          Modal.close();
          this.open();
        } })
      ])
    ]));

    // List monitors
    if (monitors.length) {
      wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: `Active Monitors (${monitors.length})` })
      ]));
      const list = Utils.el('div', { class: 'monitor-list' });
      for (const m of monitors) {
        const item = Utils.el('div', { class: 'monitor-item' }, [
          Utils.el('div', {}, [
            Utils.el('div', { class: 'm-target', text: m.target }),
            Utils.el('div', { class: 'm-schedule', text: `${m.mode.toUpperCase()} · every ${m.intervalHours}h · last: ${m.lastRun ? Utils.formatDateTime(m.lastRun) : 'never'}` })
          ]),
          Utils.el('div', { class: `m-status ${m.active ? 'active' : 'paused'}`, text: m.active ? 'ACTIVE' : 'PAUSED' })
        ]);
        const removeBtn = Utils.el('button', { class: 'icon-btn', style: { width: '28px', height: '28px' }, html: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>', onclick: () => { this.removeMonitor(m.id); Modal.close(); this.open(); } });
        item.appendChild(removeBtn);
        list.appendChild(item);
      }
      wrap.appendChild(list);
    }

    Modal.open('Monitoring & Alerts', wrap);
  }
};

/* ============================================================
   PART 8 — ADVANCED EXPORT MODULES
   ============================================================ */
const AdvExport = {

  init() {
    // Wire up new export buttons
    const handlers = {
      pdf: () => this.exportPDF(),
      md: () => this.exportMarkdown(),
      stix: () => this.exportSTIX(),
      jsonld: () => this.exportJSONLD(),
      misp: () => this.exportMISP(),
      share: () => this.exportShareLink()
    };
    for (const [type, fn] of Object.entries(handlers)) {
      const btn = Utils.$(`[data-export="${type}"]`);
      if (btn) btn.addEventListener('click', fn);
    }
  },

  async exportPDF() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    Toast.show('Generating PDF report via LLM...', 'info');
    AuditLog.log('EXPORT', 'PDF report');

    // Generate LLM summary for the PDF
    const llmSummary = await API.LLM.synthesizeProfile(State.results.query, State.results.modules || {});
    const r = State.results;
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    // Hacker-style PDF: green on black theme
    doc.setFillColor(0, 3, 0);
    doc.rect(0, 0, 210, 297, 'F');
    doc.setTextColor(0, 255, 65);
    doc.setFontSize(20);
    doc.setFont('courier', 'bold');
    doc.text('// GHOSTYEYE OSINT REPORT //', 20, 25);
    doc.setFontSize(10);
    doc.setFont('courier', 'normal');
    doc.text(`Target: ${r.query}`, 20, 35);
    doc.text(`Mode: ${r.mode.toUpperCase()}`, 20, 42);
    doc.text(`Date: ${new Date().toISOString()}`, 20, 49);
    doc.text(`Risk Score: ${r.risk ? r.risk.score : 'N/A'}/100 (${r.risk ? r.risk.levelLabel : 'N/A'})`, 20, 56);

    let y = 70;
    doc.setFontSize(14);
    doc.text('## EXECUTIVE SUMMARY', 20, y); y += 10;
    doc.setFontSize(9);
    if (llmSummary) {
      const lines = doc.splitTextToSize(llmSummary, 170);
      doc.text(lines, 20, y);
      y += lines.length * 5 + 5;
    } else {
      doc.text('LLM summary unavailable.', 20, y); y += 10;
    }

    // Module results
    y += 5;
    doc.setFontSize(14);
    doc.text('## MODULE RESULTS', 20, y); y += 10;
    doc.setFontSize(8);
    const m = r.modules || {};
    if (m.validation && m.validation.disify) {
      doc.text(`[VALIDATION] format=${m.validation.disify.format}, disposable=${m.validation.disify.disposable}, dns=${m.validation.disify.dns}`, 20, y); y += 5;
    }
    if (m.gravatar) { doc.text(`[GRAVATAR] ${m.gravatar.exists ? 'FOUND' : 'NOT FOUND'}`, 20, y); y += 5; }
    if (m.github && m.github.items) { doc.text(`[GITHUB] ${m.github.items.length} accounts found`, 20, y); y += 5; }
    if (m.breaches && m.breaches.breaches) { doc.text(`[BREACHES] ${m.breaches.breaches.length} breaches`, 20, y); y += 5; }
    if (m.pgp) { doc.text(`[PGP] ${m.pgp.found ? 'KEY FOUND' : 'NO KEY'}`, 20, y); y += 5; }
    if (m.usernames) { doc.text(`[USERNAMES] ${m.usernames.filter(u=>u.found).length}/${m.usernames.length} platforms`, 20, y); y += 5; }
    if (m.infostealer) { doc.text(`[INFOSTEALER] ${m.infostealer.hits?.length || 0} hits`, 20, y); y += 5; }

    // Risk factors
    if (r.risk && r.risk.factors) {
      y += 5;
      doc.setFontSize(14);
      doc.text('## RISK FACTORS', 20, y); y += 10;
      doc.setFontSize(8);
      for (const f of r.risk.factors) {
        if (y > 280) { doc.addPage(); doc.setFillColor(0, 3, 0); doc.rect(0, 0, 210, 297, 'F'); doc.setTextColor(0, 255, 65); y = 20; }
        doc.text(`[${f.type === 'pos' ? '+' : '-'}] ${f.label} (${f.impact > 0 ? '+' : ''}${f.impact})`, 20, y); y += 5;
      }
    }

    // Disclaimer
    y += 10;
    if (y > 270) { doc.addPage(); doc.setFillColor(0, 3, 0); doc.rect(0, 0, 210, 297, 'F'); doc.setTextColor(0, 255, 65); y = 20; }
    doc.setFontSize(7);
    doc.setTextColor(0, 100, 30);
    doc.text('// Generated by GhostyEye OSINT — for authorized use only', 20, y);
    doc.text('// You are solely responsible for compliance with applicable laws', 20, y + 4);

    const filename = `ghostyeye-report-${r.query.replace(/[^a-z0-9]/gi, '_')}-${Date.now()}.pdf`;
    doc.save(filename);
    Toast.show('PDF report generated', 'success');
  },

  exportMarkdown() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    const r = State.results;
    AuditLog.log('EXPORT', 'Markdown brief');
    const m = r.modules || {};
    let md = `# GhostyEye OSINT Investigation Report\n\n`;
    md += `**Target:** \`${r.query}\`\n`;
    md += `**Mode:** ${r.mode.toUpperCase()}\n`;
    md += `**Date:** ${new Date().toISOString()}\n`;
    md += `**Risk Score:** ${r.risk ? r.risk.score : 'N/A'}/100 (${r.risk ? r.risk.levelLabel : 'N/A'})\n\n`;
    md += `---\n\n## Executive Summary\n\n`;
    md += r.aiSynthesis || '*LLM synthesis unavailable. See module results below.*';
    md += `\n\n---\n\n## Module Results\n\n`;
    if (m.validation && m.validation.disify) {
      const v = m.validation.disify;
      md += `### Email Validation\n- **Format:** ${v.format ? 'Valid' : 'Invalid'}\n- **Disposable:** ${v.disposable ? 'Yes' : 'No'}\n- **MX Records:** ${v.dns ? 'Configured' : 'Missing'}\n- **Alias:** ${v.alias ? 'Yes' : 'No'}\n\n`;
    }
    if (m.gravatar) md += `### Gravatar\n- **Profile Picture:** ${m.gravatar.exists ? 'Found' : 'Not Found'}\n\n`;
    if (m.github && m.github.items) {
      md += `### GitHub\n- **Accounts Found:** ${m.github.items.length}\n`;
      m.github.items.slice(0, 5).forEach(u => { md += `  - [${u.login}](${u.html_url})\n`; });
      md += `\n`;
    }
    if (m.breaches && m.breaches.breaches) {
      md += `### Data Breaches\n- **Total Breaches:** ${m.breaches.breaches.length}\n\n`;
      if (m.breaches.breaches.length) {
        md += `| Breach | Date | Data Types |\n|--------|------|------------|\n`;
        m.breaches.breaches.forEach(b => {
          md += `| ${b.Name} | ${b.BreachDate || '?'} | ${(b.DataClasses || []).join(', ')} |\n`;
        });
        md += `\n`;
      }
    }
    if (m.pgp) md += `### PGP Key\n- **Published:** ${m.pgp.found ? 'Yes' : 'No'}\n\n`;
    if (m.usernames) {
      const found = m.usernames.filter(u => u.found);
      md += `### Username Search\n- **Platforms Probed:** ${m.usernames.length}\n- **Found On:** ${found.length}\n\n`;
      if (found.length) {
        md += `Found platforms:\n`;
        found.forEach(u => { md += `- [${u.name}](${u.url(u.username)})\n`; });
        md += `\n`;
      }
    }
    if (m.infostealer) {
      md += `### Infostealer Logs\n- **Sources Checked:** ${m.infostealer.checked || 0}\n- **Direct Hits:** ${m.infostealer.hits?.length || 0}\n\n`;
    }
    if (r.risk && r.risk.factors) {
      md += `---\n\n## Risk Assessment\n\n| Factor | Impact |\n|--------|--------|\n`;
      r.risk.factors.forEach(f => { md += `| ${f.label} | ${f.impact > 0 ? '+' : ''}${f.impact} |\n`; });
      md += `\n`;
      if (r.riskReasoning) md += `**Reasoning:** ${r.riskReasoning}\n\n`;
    }
    md += `---\n\n*Generated by [GhostyEye OSINT](https://ghostyeye.dpdns) — for authorized security research only.*\n`;
    Utils.download(`ghostyeye-report-${r.query.replace(/[^a-z0-9]/gi, '_')}-${Date.now()}.md`, md, 'text/markdown');
    Toast.show('Markdown brief exported', 'success');
  },

  exportSTIX() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    AuditLog.log('EXPORT', 'STIX/TAXII');
    const r = State.results;
    const id = (type) => `${type}--${crypto.randomUUID ? crypto.randomUUID() : Date.now()}-${Math.random().toString(36).slice(2,8)}`;
    const stix = {
      type: 'bundle',
      id: 'bundle--' + Date.now(),
      objects: []
    };
    // Identity object (the target)
    if (r.mode === 'email') {
      stix.objects.push({
        type: 'email-addr', id: id('email-addr'),
        value: r.query, spec_version: '2.1',
        created: r.startedAt, modified: new Date().toISOString()
      });
    } else if (r.mode === 'domain') {
      stix.objects.push({
        type: 'domain-name', id: id('domain-name'),
        value: r.query, spec_version: '2.1',
        created: r.startedAt, modified: new Date().toISOString()
      });
    }
    // Breach indicators
    if (r.modules && r.modules.breaches && r.modules.breaches.breaches) {
      r.modules.breaches.breaches.forEach(b => {
        stix.objects.push({
          type: 'incident', id: id('incident'),
          name: `Breach: ${b.Name}`, spec_version: '2.1',
          created: b.BreachDate || r.startedAt, modified: new Date().toISOString(),
          description: b.Description ? b.Description.replace(/<[^>]+>/g, '').substring(0, 500) : '',
          labels: ['data-breach'],
          external_references: [{ source_name: 'HIBP', external_id: b.Name }]
        });
      });
    }
    // Risk assessment as report
    if (r.risk) {
      stix.objects.push({
        type: 'report', id: id('report'),
        name: `GhostyEye Risk Assessment: ${r.query}`, spec_version: '2.1',
        created: new Date().toISOString(), modified: new Date().toISOString(),
        published: new Date().toISOString(),
        labels: ['osint', 'risk-assessment'],
        description: `Risk Score: ${r.risk.score}/100 (${r.risk.levelLabel}). ${r.riskReasoning || ''}`,
        report_types: ['threat-report']
      });
    }
    Utils.download(`ghostyeye-stix-${Date.now()}.json`, JSON.stringify(stix, null, 2), 'application/stix+json');
    Toast.show('STIX bundle exported', 'success');
  },

  exportJSONLD() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    AuditLog.log('EXPORT', 'JSON-LD');
    const r = State.results;
    const jsonld = {
      '@context': {
        '@vocab': 'https://schema.org/',
        osint: 'https://vocab.ghostyeye.org/',
        risk: 'osint:riskScore',
        breach: 'osint:breach',
        platform: 'osint:platform'
      },
      '@type': 'InvestigationReport',
      '@id': `urn:ghostyeye:${r.mode}:${encodeURIComponent(r.query)}`,
      name: `GhostyEye OSINT: ${r.query}`,
      datePublished: new Date().toISOString(),
      about: { '@type': r.mode === 'email' ? 'EmailAddr' : 'Thing', name: r.query },
      'osint:riskScore': r.risk ? r.risk.score : 0,
      'osint:riskLevel': r.risk ? r.risk.levelLabel : 'Unknown',
    };
    if (r.modules) {
      if (r.modules.breaches && r.modules.breaches.breaches) {
        jsonld['osint:breaches'] = r.modules.breaches.breaches.map(b => ({
          '@type': 'osint:breach', name: b.Name, date: b.BreachDate,
          dataClasses: b.DataClasses || []
        }));
      }
      if (r.modules.usernames) {
        jsonld['osint:platforms'] = r.modules.usernames.filter(u => u.found).map(u => ({
          '@type': 'osint:platform', name: u.name, url: u.url(u.username)
        }));
      }
    }
    Utils.download(`ghostyeye-jsonld-${Date.now()}.json`, JSON.stringify(jsonld, null, 2), 'application/ld+json');
    Toast.show('JSON-LD exported', 'success');
  },

  exportMISP() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    AuditLog.log('EXPORT', 'MISP');
    const r = State.results;
    const misp = {
      Event: {
        info: `GhostyEye OSINT: ${r.query}`,
        date: new Date().toISOString().split('T')[0],
        threat_level_id: r.risk && r.risk.level === 'high' ? '1' : r.risk && r.risk.level === 'medium' ? '2' : '3',
        analysis: '2',
        published: false,
        Attribute: [],
        Object: []
      }
    };
    // Add attributes
    if (r.mode === 'email') {
      misp.Event.Attribute.push({ type: 'email-dst', category: 'Payload delivery', value: r.query, to_ids: false, comment: 'GhostyEye target' });
    } else if (r.mode === 'domain') {
      misp.Event.Attribute.push({ type: 'domain', category: 'Network activity', value: r.query, to_ids: false });
    }
    // Add breach attributes
    if (r.modules && r.modules.breaches && r.modules.breaches.breaches) {
      r.modules.breaches.breaches.forEach(b => {
        misp.Event.Attribute.push({
          type: 'comment', category: 'External analysis',
          value: `Breach: ${b.Name} (${b.BreachDate || '?'}) — ${(b.DataClasses || []).join(', ')}`,
          to_ids: false, comment: 'HIBP'
        });
      });
    }
    // Add platform attributes
    if (r.modules && r.modules.usernames) {
      r.modules.usernames.filter(u => u.found).slice(0, 20).forEach(u => {
        misp.Event.Attribute.push({
          type: 'link', category: 'External analysis',
          value: u.url(u.username), to_ids: false, comment: `Profile: ${u.name}`
        });
      });
    }
    Utils.download(`ghostyeye-misp-${Date.now()}.json`, JSON.stringify(misp, null, 2), 'application/json');
    Toast.show('MISP event exported', 'success');
  },

  exportShareLink() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    AuditLog.log('EXPORT', 'Shareable link');
    // Encode results in URL hash (base64)
    try {
      const data = btoa(unescape(encodeURIComponent(JSON.stringify({
        query: State.results.query,
        mode: State.results.mode,
        risk: State.results.risk,
        modules: State.results.modules,
        aiSynthesis: State.results.aiSynthesis,
        ts: Date.now()
      }))));
      const url = `${location.origin}${location.pathname}#share=${data}`;
      // Copy to clipboard
      navigator.clipboard.writeText(url).then(() => {
        Toast.show('Shareable link copied to clipboard', 'success');
      }).catch(() => {
        // Fallback: show in modal
        const wrap = Utils.el('div', { class: 'flex-col gap-2' }, [
          Utils.el('p', { class: 'text-sm text-dim', text: 'Copy this encrypted URL to share findings:' }),
          Utils.el('textarea', { class: 'bulk-textarea', text: url, attrs: { readonly: '' }, style: { minHeight: '80px' } })
        ]);
        Modal.open('Shareable Link', wrap);
      });
    } catch (e) { Toast.show('Failed to create share link: ' + e.message, 'error'); }
  }
};

console.log('[GhostyEye] Advanced features module loaded');

/* ============================================================
   PART 9 — ADVANCED DRAWER (all feature views)
   ============================================================ */
const AdvDrawer = {

  /* --- SSL Certificate Analysis --- */
  async openSSL() {
    AuditLog.log('VIEW', 'SSL Certificate Analysis');
    const target = State.results?.query;
    if (target && (Utils.isValidDomain(target) || target.includes('.'))) {
      this._runSSL(target);
    } else {
      Modal.prompt('Enter domain for SSL certificate analysis', 'example.com', '', (v) => { if (v) this._runSSL(v); });
    }
  },
  async _runSSL(target) {
    const domain = target.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> QUERYING crt.sh' }),
      Utils.el('div', { class: 'card-placeholder', text: `Fetching certificate transparency logs for ${domain}...` })
    ]);
    Modal.open('SSL Certificate Analysis', wrap);
    const result = await AdvAPI.SSL.lookup(domain);
    wrap.innerHTML = '';
    if (result.error) {
      wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: `Error: ${result.error}` }));
      return;
    }
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> CERTIFICATE TRANSPARENCY LOG' }));
    wrap.appendChild(Card.row('Domain', domain));
    wrap.appendChild(Card.row('Total Certificates', String(result.totalCerts)));
    if (result.earliest) wrap.appendChild(Card.row('Earliest Cert', Utils.formatDate(result.earliest)));
    if (result.latest) wrap.appendChild(Card.row('Latest Cert', Utils.formatDate(result.latest)));
    wrap.appendChild(Card.row('Unique Issuers', String(result.issuers.length)));
    if (result.issuers.length) {
      wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-2', text: 'Issuers:' }));
      result.issuers.slice(0, 5).forEach(i => wrap.appendChild(Utils.el('div', { class: 'text-sm mono', text: '• ' + i.substring(0, 80) })));
    }
    wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: `SAN domains discovered (${result.sanDomains.length}):` }));
    const sanGrid = Utils.el('div', { class: 'platform-grid' });
    result.sanDomains.slice(0, 100).forEach(d => {
      sanGrid.appendChild(Utils.el('a', { class: 'platform-item found', href: `https://${d}`, target: '_blank', rel: 'noopener' }, [
        Utils.el('div', { class: 'platform-name', text: d })
      ]));
    });
    wrap.appendChild(sanGrid);
  },

  /* --- Wayback Machine --- */
  async openWayback() {
    AuditLog.log('VIEW', 'Wayback Machine');
    const target = State.results?.query;
    if (target) {
      this._runWayback(target);
    } else {
      Modal.prompt('Enter URL for Wayback Machine lookup', 'example.com or https://example.com', '', (v) => { if (v) this._runWayback(v); });
    }
  },
  async _runWayback(target) {
    let url = target.startsWith('http') ? target : `https://${target}`;
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> QUERYING WEB ARCHIVE' }),
      Utils.el('div', { class: 'card-placeholder', text: `Searching Wayback Machine for ${url}...` })
    ]);
    Modal.open('Wayback Machine', wrap);
    const result = await AdvAPI.Wayback.lookup(url);
    wrap.innerHTML = '';
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> WAYBACK MACHINE ARCHIVE' }));
    wrap.appendChild(Card.row('URL', url));
    wrap.appendChild(Card.row('Total Snapshots', String(result.total)));
    if (result.snapshots && result.snapshots.length) {
      wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Recent snapshots:' }));
      result.snapshots.forEach(s => {
        wrap.appendChild(Utils.el('a', {
          class: 'dork-item',
          href: s.archiveUrl, target: '_blank', rel: 'noopener'
        }, [
          Utils.el('span', { class: 'dork-operator', text: s.timestamp }),
          Utils.el('span', { text: `${s.status || '?'} · ${s.mime || 'unknown'} · ${s.url.substring(0, 60)}` })
        ]));
      });
    }
  },

  /* --- Google Dorking Engine --- */
  openDorking() {
    AuditLog.log('VIEW', 'Google Dorking Engine');
    const target = State.results?.query || '';
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> GOOGLE DORKING ENGINE' }));
    if (target) {
      const dorks = AdvAPI.Dorking.generate(target);
      wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: `${dorks.length} dork queries generated for "${target}". Click to run on Google.` }));
      const grid = Utils.el('div', { class: 'dork-grid' });
      dorks.forEach(d => {
        grid.appendChild(Utils.el('a', {
          class: 'dork-item',
          href: `https://www.google.com/search?q=${encodeURIComponent(d.q)}`,
          target: '_blank', rel: 'noopener'
        }, [
          Utils.el('span', { class: 'dork-operator', text: d.op }),
          Utils.el('span', { text: d.desc })
        ]));
      });
      wrap.appendChild(grid);
    } else {
      wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Run a search first, then open this panel to generate 30+ dork queries for the target.' }));
    }
    Modal.open('Google Dorking Engine', wrap);
  },

  /* --- WHOIS / RDAP --- */
  async openWHOIS() {
    AuditLog.log('VIEW', 'WHOIS/RDAP');
    const target = State.results?.query;
    if (target && Utils.isValidDomain(target)) {
      this._runWHOIS(target);
    } else {
      Modal.prompt('Enter domain for WHOIS/RDAP lookup', 'example.com', '', (v) => { if (v) this._runWHOIS(v); });
    }
  },
  async _runWHOIS(target) {
    const domain = target.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> QUERYING RDAP' }),
      Utils.el('div', { class: 'card-placeholder', text: `Fetching RDAP records for ${domain}...` })
    ]);
    Modal.open('WHOIS / RDAP', wrap);
    const result = await AdvAPI.WHOIS.lookup(domain);
    wrap.innerHTML = '';
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> RDAP REGISTRATION DATA' }));
    if (result.error) {
      wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: `Error: ${result.error}` }));
      return;
    }
    wrap.appendChild(Card.row('Domain', result.domain || domain));
    if (result.handle) wrap.appendChild(Card.row('Registry Handle', result.handle, { mono: true }));
    wrap.appendChild(Card.row('Status', (result.status || []).join(', ')));
    if (result.nameservers && result.nameservers.length) {
      wrap.appendChild(Card.row('Nameservers', String(result.nameservers.length)));
      result.nameservers.forEach(ns => wrap.appendChild(Utils.el('div', { class: 'text-sm mono', text: '• ' + ns })));
    }
    if (result.events && result.events.length) {
      wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Events:' }));
      result.events.forEach(e => wrap.appendChild(Card.row(e.eventAction || 'event', Utils.formatDate(e.eventDate))));
    }
    if (result.secureDNS) wrap.appendChild(Card.row('DNSSEC', result.secureDNS.delegationSigned ? 'Enabled' : 'Disabled'));
  },

  /* --- Crypto Wallet Lookup --- */
  async openCrypto() {
    AuditLog.log('VIEW', 'Crypto Wallet Lookup');
    Modal.prompt('Enter BTC or ETH address', 'bc1... or 0x...', '', (v) => { if (v) this._runCrypto(v); });
  },
  async _runCrypto(addr) {
    const type = AdvAPI.Crypto.detectType(addr);
    if (!type) { Toast.show('Unrecognized address format', 'error'); return; }
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> QUERYING BLOCKCHAIN' }),
      Utils.el('div', { class: 'card-placeholder', text: `Looking up ${type} address ${addr.substring(0,16)}...` })
    ]);
    Modal.open('Crypto Wallet Lookup', wrap);
    const result = type === 'BTC' ? await AdvAPI.Crypto.lookupBTC(addr) : await AdvAPI.Crypto.lookupETH(addr);
    wrap.innerHTML = '';
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: `<span class="dot"></span> ${type} WALLET ANALYSIS` }));
    if (result.error) { wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: `Error: ${result.error}` })); return; }
    wrap.appendChild(Card.row('Address', addr, { mono: true }));
    wrap.appendChild(Card.row('Type', type));
    if (type === 'BTC') {
      wrap.appendChild(Card.row('Total Received', `${result.totalReceived?.toFixed(4)} BTC`));
      wrap.appendChild(Card.row('Total Sent', `${result.totalSent?.toFixed(4)} BTC`));
      wrap.appendChild(Card.row('Current Balance', `${result.finalBalance?.toFixed(4)} BTC`));
      wrap.appendChild(Card.row('Transaction Count', String(result.txCount)));
      if (result.txs && result.txs.length) {
        wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Recent transactions:' }));
        result.txs.forEach(t => {
          wrap.appendChild(Utils.el('a', { class: 'dork-item', href: `https://blockchain.info/tx/${t.hash}`, target: '_blank' }, [
            Utils.el('span', { class: 'dork-operator', text: Utils.formatDate(t.time * 1000) }),
            Utils.el('span', { text: `${t.value?.toFixed(4)} BTC` })
          ]));
        });
      }
    } else {
      wrap.appendChild(Card.row('Balance', `${result.balance?.toFixed(4)} ETH`));
      wrap.appendChild(Card.row('Transaction Count', String(result.txCount)));
      if (result.tokens && result.tokens.length) {
        wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Token holdings:' }));
        result.tokens.forEach(t => wrap.appendChild(Card.row(t.symbol || '?', `${t.balance?.toFixed(2)} (${t.name || ''})`)));
      }
    }
  },

  /* --- Exposed Git Secrets --- */
  async openGitSecrets() {
    AuditLog.log('VIEW', 'Exposed Git Secrets');
    const username = State.results?.derivedUsername || State.results?.query;
    if (username && !username.includes('@')) {
      this._runGitSecrets(username);
    } else {
      Modal.prompt('Enter GitHub username', 'username', '', (v) => { if (v) this._runGitSecrets(v); });
    }
  },
  async _runGitSecrets(username) {
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> SCANNING GITHUB REPOS' }),
      Utils.el('div', { class: 'card-placeholder', text: `Scanning ${username}'s repos for committed secrets...` })
    ]);
    Modal.open('Exposed Git Secrets', wrap);
    const result = await AdvAPI.GitSecrets.scanUser(username);
    wrap.innerHTML = '';
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> GIT SECRETS SCAN' }));
    if (result.error) { wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: `Error: ${result.error}` })); return; }
    wrap.appendChild(Card.row('Username', username));
    wrap.appendChild(Card.row('Repos Scanned', String(result.repos)));
    wrap.appendChild(Card.row('Repos with Suspect Files', String(result.secrets.length)));
    if (result.secrets && result.secrets.length) {
      wrap.appendChild(Utils.el('div', { class: 'text-sm', style: { color: 'var(--accent-red)', marginTop: '8px' }, text: `${result.secrets.length} repos with potential secrets:` }));
      result.secrets.forEach(s => {
        wrap.appendChild(Utils.el('div', { class: 'breach-item' }, [
          Utils.el('div', { class: 'breach-item-head' }, [
            Utils.el('a', { class: 'breach-name', href: s.url, target: '_blank', text: s.repo }),
            Utils.el('div', { class: 'breach-date', text: `${s.suspectFiles} suspect files` })
          ]),
          Utils.el('div', { class: 'breach-data-types' }, (s.files || []).map(f => Utils.el('a', { class: 'pill danger', href: f.url, target: '_blank', text: f.name })))
        ]));
      });
    } else {
      wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: 'No suspect files found in recent repos.' }));
    }
  },

  /* --- Subdomain Enumeration --- */
  async openSubdomainEnum() {
    AuditLog.log('VIEW', 'Subdomain Enumeration');
    const target = State.results?.query;
    if (target && Utils.isValidDomain(target)) {
      this._runSubdomainEnum(target);
    } else {
      Modal.prompt('Enter domain for subdomain enumeration', 'example.com', '', (v) => { if (v) this._runSubdomainEnum(v); });
    }
  },
  async _runSubdomainEnum(target) {
    const domain = target.replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> ENUMERATING SUBDOMAINS' }),
      Utils.el('div', { class: 'card-placeholder', text: `Probing 100+ common subdomains + crt.sh for ${domain}...` })
    ]);
    Modal.open('Subdomain Enumeration', wrap);
    const result = await AdvAPI.SubdomainEnum.enumerate(domain);
    wrap.innerHTML = '';
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> SUBDOMAIN ENUMERATION' }));
    wrap.appendChild(Card.row('Domain', domain));
    wrap.appendChild(Card.row('Subdomains Found', String(result.total)));
    if (result.subdomains && result.subdomains.length) {
      const grid = Utils.el('div', { class: 'platform-grid' });
      result.subdomains.forEach(s => {
        grid.appendChild(Utils.el('a', {
          class: 'platform-item found',
          href: `https://${s.sub}.${domain}`, target: '_blank', rel: 'noopener'
        }, [
          Utils.el('div', { class: 'platform-name', text: `${s.sub}.${domain}` }),
          Utils.el('span', { class: 'pill info', text: s.source })
        ]));
      });
      wrap.appendChild(grid);
    }
  },

  /* --- Shodan (link-based) --- */
  openShodan() {
    AuditLog.log('VIEW', 'Shodan IoT Search');
    const target = State.results?.query || '';
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> SHODAN IOT SEARCH' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Shodan requires an API key for programmatic access. Open these links to search directly on shodan.io:' }));
    if (target) {
      const links = [
        { label: `Search for "${target}"`, url: `https://www.shodan.io/search?query=${encodeURIComponent(target)}` },
        { label: 'Search by IP', url: `https://www.shodan.io/search?query=ip:${encodeURIComponent(target)}` },
        { label: 'Search by domain', url: `https://www.shodan.io/search?query=hostname:${encodeURIComponent(target)}` },
        { label: 'Search SSL certs', url: `https://www.shodan.io/search?query=ssl.cert.subject.CN:${encodeURIComponent(target)}` },
        { label: 'Search open ports', url: `https://www.shodan.io/search?query=port:22+country:US` },
      ];
      links.forEach(l => {
        wrap.appendChild(Utils.el('a', { class: 'dork-item', href: l.url, target: '_blank' }, [
          Utils.el('span', { class: 'dork-operator', text: 'SHODAN' }), Utils.el('span', { text: l.label })
        ]));
      });
    }
    wrap.appendChild(Utils.el('p', { class: 'text-xs text-dim mt-3', text: 'Tip: Add a Shodan API key in Settings to enable in-app results.' }));
    Modal.open('Shodan IoT Search', wrap);
  },

  /* --- Reverse Image Search --- */
  openReverseImage() {
    AuditLog.log('VIEW', 'Reverse Image Search');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> REVERSE IMAGE SEARCH' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Submit a profile picture URL to find other accounts using the same photo. Useful for linking identities across platforms.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'ris-url', placeholder: 'image URL...', style: { marginTop: '8px' } }));
    const results = Utils.el('div', { id: 'ris-results', class: 'flex-col gap-2', style: { marginTop: '12px' } });
    wrap.appendChild(results);
    Utils.$('#ris-results') || wrap.appendChild(results);
    const btn = Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'SEARCH', onclick: () => {
      const url = Utils.$('#ris-url').value.trim();
      if (!url) { Toast.show('Enter an image URL', 'error'); return; }
      results.innerHTML = '';
      const services = [
        { name: 'Google Images', url: `https://images.google.com/searchbyimage?image_url=${encodeURIComponent(url)}` },
        { name: 'TinEye', url: `https://tineye.com/search?url=${encodeURIComponent(url)}` },
        { name: 'Yandex', url: `https://yandex.com/images/search?url=${encodeURIComponent(url)}&rpt=imageview` },
        { name: 'Bing Visual Search', url: `https://www.bing.com/images/searchbyimage?cbir=ssbi&imgurl=${encodeURIComponent(url)}` },
        { name: 'Baidu', url: `https://image.baidu.com/n/pc_search?queryImageUrl=${encodeURIComponent(url)}` },
      ];
      services.forEach(s => {
        results.appendChild(Utils.el('a', { class: 'dork-item', href: s.url, target: '_blank' }, [
          Utils.el('span', { class: 'dork-operator', text: 'IMAGE' }), Utils.el('span', { text: s.name })
        ]));
      });
    }});
    wrap.appendChild(btn);
    // If we have a Gravatar from current results, pre-fill
    if (State.results?.modules?.gravatar?.avatarUrl) {
      Utils.$('#ris-url').value = State.results.modules.gravatar.avatarUrl;
    }
    Modal.open('Reverse Image Search', wrap);
  },

  /* --- Network Graph (D3 force-directed) --- */
  openGraph() {
    AuditLog.log('VIEW', 'Network Graph');
    if (!State.results) { Toast.show('Run an investigation first', 'info'); return; }
    const wrap = Utils.el('div', { style: { width: '100%', height: '600px', position: 'relative' } });
    const graphDiv = Utils.el('div', { class: 'graph-container', id: 'graph-container' });
    wrap.appendChild(graphDiv);
    const legend = Utils.el('div', { class: 'graph-legend' }, [
      Utils.el('div', { class: 'graph-legend-item' }, [Utils.el('div', { class: 'graph-legend-dot', style: { background: 'var(--accent-green)' } }), Utils.el('span', { text: 'Target' })]),
      Utils.el('div', { class: 'graph-legend-item' }, [Utils.el('div', { class: 'graph-legend-dot', style: { background: 'var(--accent-cyan)' } }), Utils.el('span', { text: 'Account/Platform' })]),
      Utils.el('div', { class: 'graph-legend-item' }, [Utils.el('div', { class: 'graph-legend-dot', style: { background: 'var(--accent-red)' } }), Utils.el('span', { text: 'Breach' })]),
      Utils.el('div', { class: 'graph-legend-item' }, [Utils.el('div', { class: 'graph-legend-dot', style: { background: 'var(--accent-purple)' } }), Utils.el('span', { text: 'IP/Domain' })]),
    ]);
    wrap.appendChild(legend);
    Modal.open('Network Graph', wrap, () => {
      const svg = Utils.$('#graph-container svg');
      if (svg) {
        const blob = new Blob([new XMLSerializer().serializeToString(svg)], { type: 'image/svg+xml' });
        Utils.download('ghostyeye-graph.svg', blob, 'image/svg+xml');
      }
    });
    // Build graph data
    const nodes = [{ id: State.results.query, type: 'target', label: State.results.query }];
    const links = [];
    const m = State.results.modules || {};
    if (m.gravatar && m.gravatar.exists) { nodes.push({ id: 'gravatar', type: 'account', label: 'Gravatar' }); links.push({ source: State.results.query, target: 'gravatar' }); }
    if (m.github && m.github.items) {
      m.github.items.slice(0, 3).forEach(u => {
        nodes.push({ id: 'gh-' + u.login, type: 'account', label: 'GitHub: ' + u.login });
        links.push({ source: State.results.query, target: 'gh-' + u.login });
      });
    }
    if (m.breaches && m.breaches.breaches) {
      m.breaches.breaches.slice(0, 8).forEach(b => {
        nodes.push({ id: 'b-' + b.Name, type: 'breach', label: b.Name });
        links.push({ source: State.results.query, target: 'b-' + b.Name });
      });
    }
    if (m.usernames) {
      m.usernames.filter(u => u.found).slice(0, 15).forEach(u => {
        nodes.push({ id: 'u-' + u.name, type: 'account', label: u.name });
        links.push({ source: State.results.query, target: 'u-' + u.name });
      });
    }
    if (m.pgp && m.pgp.found) { nodes.push({ id: 'pgp', type: 'account', label: 'PGP Key' }); links.push({ source: State.results.query, target: 'pgp' }); }
    if (m.dns) {
      const aRecs = m.dns.A || [];
      if (aRecs.length) {
        nodes.push({ id: 'dns-a', type: 'ip', label: 'DNS A (' + aRecs.length + ')' });
        links.push({ source: State.results.query, target: 'dns-a' });
      }
    }
    if (m.infostealer && m.infostealer.hits && m.infostealer.hits.length) {
      nodes.push({ id: 'stealer', type: 'breach', label: 'Infostealer (' + m.infostealer.hits.length + ')' });
      links.push({ source: State.results.query, target: 'stealer' });
    }
    // Render D3 graph
    setTimeout(() => {
      const container = Utils.$('#graph-container');
      if (!container || typeof d3 === 'undefined') return;
      const width = container.clientWidth, height = 550;
      const svg = d3.select(container).append('svg').attr('width', width).attr('height', height);
      const colors = { target: '#00ff41', account: '#00fff0', breach: '#ff0033', ip: '#b347ff' };
      const sim = d3.forceSimulation(nodes)
        .force('link', d3.forceLink(links).id(d => d.id).distance(80))
        .force('charge', d3.forceManyBody().strength(-300))
        .force('center', d3.forceCenter(width / 2, height / 2));
      const link = svg.append('g').selectAll('line').data(links).join('line').attr('class', 'graph-link');
      const node = svg.append('g').selectAll('g').data(nodes).join('g').attr('class', 'graph-node').call(d3.drag()
        .on('start', (e, d) => { if (!e.active) sim.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
        .on('drag', (e, d) => { d.fx = e.x; d.fy = e.y; })
        .on('end', (e, d) => { d.fx = null; d.fy = null; }));
      node.append('circle').attr('r', d => d.type === 'target' ? 14 : 8).attr('fill', d => colors[d.type] || '#00ff41').attr('stroke', d => colors[d.type]).attr('stroke-width', 2);
      node.append('text').attr('dx', 12).attr('dy', '.35em').text(d => d.label.substring(0, 20));
      sim.on('tick', () => {
        link.attr('x1', d => d.source.x).attr('y1', d => d.source.y).attr('x2', d => d.target.x).attr('y2', d => d.target.y);
        node.attr('transform', d => `translate(${d.x},${d.y})`);
      });
    }, 100);
  },

  /* --- Email Pattern Predictor --- */
  openEmailPattern() {
    AuditLog.log('VIEW', 'Email Pattern Predictor');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> EMAIL PATTERN PREDICTOR' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Given a first name, last name, and company domain, predict likely email formats.' }));
    const inputs = Utils.el('div', { class: 'bulk-controls' }, [
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'ep-first', placeholder: 'first name...', style: { flex: '1' } }),
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'ep-last', placeholder: 'last name...', style: { flex: '1' } }),
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'ep-domain', placeholder: 'company.com...', style: { flex: '1' } }),
      Utils.el('button', { class: 'search-btn', text: 'PREDICT', onclick: () => this.runEmailPattern() })
    ]);
    wrap.appendChild(inputs);
    wrap.appendChild(Utils.el('div', { id: 'ep-results', class: 'pattern-grid', style: { marginTop: '12px' } }));
    Modal.open('Email Pattern Predictor', wrap);
  },

  runEmailPattern() {
    const f = Utils.$('#ep-first').value.trim();
    const l = Utils.$('#ep-last').value.trim();
    const d = Utils.$('#ep-domain').value.trim().replace(/^@/, '');
    if (!f || !l || !d) { Toast.show('Fill all fields', 'error'); return; }
    const patterns = AdvAPI.EmailPattern.predict(f, l, d);
    const results = Utils.$('#ep-results');
    results.innerHTML = '';
    patterns.forEach(p => {
      results.appendChild(Utils.el('div', { class: 'pattern-card', onclick: () => {
        navigator.clipboard.writeText(p.email).then(() => Toast.show('Copied: ' + p.email, 'success'));
      }}, [
        Utils.el('div', { class: 'pattern-email', text: p.email }),
        Utils.el('div', { class: 'pattern-format', text: p.format })
      ]));
    });
  },

  /* --- Username Similarity Engine --- */
  openUsernameSimilarity() {
    AuditLog.log('VIEW', 'Username Similarity Engine');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> USERNAME SIMILARITY ENGINE' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Generate typo-squatted and variant usernames for the target.' }));
    const inputs = Utils.el('div', { class: 'bulk-controls' }, [
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'us-input', placeholder: 'username...', style: { flex: '1' }, value: State.results?.derivedUsername || State.results?.query || '' }),
      Utils.el('button', { class: 'search-btn', text: 'GENERATE', onclick: () => this.runUsernameSimilarity() })
    ]);
    wrap.appendChild(inputs);
    wrap.appendChild(Utils.el('div', { id: 'us-results', class: 'similarity-grid', style: { marginTop: '12px' } }));
    Modal.open('Username Similarity Engine', wrap);
  },

  runUsernameSimilarity() {
    const u = Utils.$('#us-input').value.trim();
    if (!u) { Toast.show('Enter a username', 'error'); return; }
    const variants = AdvAPI.UsernameSimilarity.generate(u);
    const results = Utils.$('#us-results');
    results.innerHTML = '';
    variants.forEach(v => {
      results.appendChild(Utils.el('a', { class: 'sim-item', href: `https://www.google.com/search?q=${encodeURIComponent('"' + v.username + '"')}`, target: '_blank' }, [
        Utils.el('span', { class: 'sim-name', text: v.username }),
        Utils.el('span', { class: 'sim-score', text: `d=${v.similarity}` })
      ]));
    });
  },

  /* --- Anomaly Detection --- */
  openAnomaly() {
    AuditLog.log('VIEW', 'Anomaly Detection');
    if (!State.results) { Toast.show('Run an investigation first', 'info'); return; }
    const anomalies = AdvAPI.Anomaly.analyze(State.results);
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> ANOMALY DETECTION' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: `${anomalies.length} anomalies detected in the current investigation.` }));
    if (anomalies.length) {
      anomalies.forEach(a => {
        const sevColor = a.severity === 'critical' ? 'var(--accent-red)' : a.severity === 'high' ? 'var(--accent-red)' : a.severity === 'medium' ? 'var(--accent-amber)' : a.severity === 'low' ? 'var(--accent-cyan)' : 'var(--text-dim)';
        wrap.appendChild(Utils.el('div', { class: 'breach-item', style: { borderColor: sevColor } }, [
          Utils.el('div', { class: 'breach-item-head' }, [
            Utils.el('div', { class: 'breach-name', style: { color: sevColor }, text: `[${a.severity.toUpperCase()}] ${a.type}` }),
          ]),
          Utils.el('div', { class: 'breach-desc', text: a.desc })
        ]));
      });
    } else {
      wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: 'No anomalies detected — all signals appear normal.' }));
    }
    Modal.open('Anomaly Detection', wrap);
  },

  /* --- Sentiment Analysis --- */
  openSentiment() {
    AuditLog.log('VIEW', 'Sentiment Analysis');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> SENTIMENT ANALYSIS (LLM)' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Paste text to analyze sentiment, tone, and risk indicators.' }));
    wrap.appendChild(Utils.el('textarea', { class: 'bulk-textarea', id: 'sa-text', placeholder: 'Paste text here...' }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'ANALYZE', onclick: async () => {
      const text = Utils.$('#sa-text').value.trim();
      if (!text) { Toast.show('Enter text', 'error'); return; }
      Toast.show('Analyzing via LLM...', 'info');
      const result = await AdvAPI.Sentiment.analyze(text);
      const out = Utils.$('#sa-result');
      out.innerHTML = '';
      if (result) {
        out.appendChild(Utils.el('pre', { class: 'api-code', text: result, style: { whiteSpace: 'pre-wrap' } }));
      } else {
        out.appendChild(Utils.el('div', { class: 'card-placeholder', text: 'LLM unavailable' }));
      }
    } }));
    wrap.appendChild(Utils.el('div', { id: 'sa-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Sentiment Analysis', wrap);
  },

  /* --- Face Match --- */
  async openFaceMatch() {
    AuditLog.log('VIEW', 'Face Match');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> FACE MATCH ACROSS PLATFORMS' }),
      Utils.el('div', { class: 'card-placeholder', text: 'Collecting avatars from Gravatar, GitHub, Twitter, Instagram...' })
    ]);
    Modal.open('Face Match', wrap);
    const email = State.results?.query?.includes('@') ? State.results.query : null;
    const username = State.results?.derivedUsername || (State.results?.mode === 'username' ? State.results.query : null);
    const result = await AdvAPI.FaceMatch.compareAvatars(email, username);
    wrap.innerHTML = '';
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> AVATAR COMPARISON' }));
    wrap.appendChild(Card.row('Avatars Checked', String(result.totalChecked)));
    wrap.appendChild(Card.row('Avatars Found', String(result.found)));
    wrap.appendChild(Utils.el('p', { class: 'text-xs text-dim', text: result.note }));
    if (result.avatars && result.avatars.length) {
      wrap.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Click to view full-size:' }));
      const grid = Utils.el('div', { class: 'platform-grid' });
      result.avatars.forEach(a => {
        grid.appendChild(Utils.el('a', { class: 'platform-item found', href: a.url, target: '_blank' }, [
          Utils.el('div', { class: 'platform-icon', html: `<img src="${a.url}" style="width:16px;height:16px;border-radius:3px;" onerror="this.style.display='none'">` }),
          Utils.el('div', { class: 'platform-name', text: a.source })
        ]));
      });
      wrap.appendChild(grid);
    }
  },

  /* --- Breach Timeline --- */
  openTimeline() {
    AuditLog.log('VIEW', 'Breach Timeline');
    if (!State.results?.modules?.breaches?.breaches) { Toast.show('No breach data — run an email investigation first', 'info'); return; }
    const breaches = State.results.modules.breaches.breaches;
    const wrap = Utils.el('div', { style: { width: '100%', minHeight: '400px' } });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> BREACH TIMELINE' }));
    const canvas = Utils.el('canvas', { id: 'timeline-chart', style: { width: '100%', height: '350px' } });
    wrap.appendChild(canvas);
    Modal.open('Breach Timeline', wrap);
    setTimeout(() => {
      if (typeof Chart === 'undefined') return;
      const sorted = breaches.filter(b => b.BreachDate).sort((a, b) => new Date(a.BreachDate) - new Date(b.BreachDate));
      const ctx = canvas.getContext('2d');
      new Chart(ctx, {
        type: 'line',
        data: {
          labels: sorted.map(b => b.BreachDate),
          datasets: [{
            label: 'Breaches',
            data: sorted.map((b, i) => i + 1),
            borderColor: '#00ff41',
            backgroundColor: 'rgba(0, 255, 65, 0.1)',
            fill: true,
            tension: 0.3,
            pointBackgroundColor: sorted.map(b => (b.DataClasses || []).length > 5 ? '#ff0033' : '#00ff41'),
            pointRadius: 6,
            pointHoverRadius: 10,
          }]
        },
        options: {
          responsive: true,
          plugins: {
            legend: { labels: { color: '#00ff41', font: { family: 'JetBrains Mono' } } },
            tooltip: {
              backgroundColor: 'rgba(0, 12, 6, 0.95)',
              titleColor: '#00ff41', bodyColor: '#b6ffc7',
              borderColor: '#00ff41', borderWidth: 1,
              callbacks: {
                afterLabel: (ctx) => {
                  const b = sorted[ctx.dataIndex];
                  return b ? [`${(b.DataClasses || []).join(', ')}`, `Affected: ${b.PwnCount?.toLocaleString() || '?'}`] : '';
                }
              }
            }
          },
          scales: {
            x: { ticks: { color: '#00b82e', font: { family: 'JetBrains Mono', size: 10 } }, grid: { color: 'rgba(0,255,65,0.1)' } },
            y: { ticks: { color: '#00b82e', font: { family: 'JetBrains Mono' } }, grid: { color: 'rgba(0,255,65,0.1)' }, title: { display: true, text: 'Cumulative Breaches', color: '#00b82e' } }
          }
        }
      });
    }, 100);
  },

  /* --- Geographic Map --- */
  openGeoMap() {
    AuditLog.log('VIEW', 'Geographic Map');
    const wrap = Utils.el('div', { style: { width: '100%', height: '550px' } });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> GEOGRAPHIC MAP' }));
    const mapDiv = Utils.el('div', { id: 'geo-map', style: { width: '100%', height: '500px' } });
    wrap.appendChild(mapDiv);
    Modal.open('Geographic Map', wrap);
    setTimeout(() => {
      if (typeof L === 'undefined') { Toast.show('Leaflet not loaded', 'error'); return; }
      const map = L.map('geo-map', { scrollWheelZoom: true }).setView([20, 0], 2);
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; OpenStreetMap &copy; CARTO',
        maxZoom: 18
      }).addTo(map);
      // Add markers from current results
      const m = State.results?.modules || {};
      let added = 0;
      // IP location (if IP mode)
      if (m.ip && (m.ip.ipinfo || m.ip.ipapi)) {
        const info = m.ip.ipinfo || m.ip.ipapi;
        if (info.loc) {
          const [lat, lon] = info.loc.split(',');
          L.marker([parseFloat(lat), parseFloat(lon)], { icon: L.divIcon({ className: 'map-marker', html: '<div class="map-marker"></div>', iconSize: [16, 16] }) })
            .addTo(map).bindPopup(`<b>IP: ${info.ip}</b><br>${info.city || ''}, ${info.country || ''}<br>ISP: ${info.org || '?'}`);
          added++;
        }
      }
      // Domain A records
      if (m.dns && m.dns.A) {
        m.dns.A.forEach(r => {
          if (Utils.isValidIP(r.data)) {
            // Geolocate the IP
            Utils.fetchJSON(`https://ipapi.co/${r.data}/json/`).then(res => {
              if (res.ok && res.data && res.data.latitude) {
                L.marker([res.data.latitude, res.data.longitude], { icon: L.divIcon({ className: 'map-marker', html: '<div class="map-marker" style="background:var(--accent-cyan)"></div>', iconSize: [16, 16] }) })
                  .addTo(map).bindPopup(`<b>A Record: ${r.data}</b><br>${res.data.city || ''}, ${res.data.country_name || ''}`);
                added++;
              }
            }).catch(() => {});
          }
        });
      }
      if (added === 0) {
        L.popup().setLatLng([20, 0]).setContent('No geolocatable data in current results. Run an IP or domain investigation first.').openOn(map);
      }
    }, 100);
  },

  /* --- Activity Heatmap --- */
  openHeatmap() {
    AuditLog.log('VIEW', 'Activity Heatmap');
    const wrap = Utils.el('div', { style: { width: '100%' } });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> ACTIVITY HEATMAP' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Simulated activity pattern (when target is most active online). In production, this would use GitHub commit times, Reddit post times, etc.' }));
    const grid = Utils.el('div', { class: 'heatmap-grid', id: 'heatmap-grid' });
    // Header row (hours)
    grid.appendChild(Utils.el('div', { class: 'heatmap-label' }));
    for (let h = 0; h < 24; h++) grid.appendChild(Utils.el('div', { class: 'heatmap-label', text: h.toString().padStart(2, '0') }));
    // Days
    const days = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
    days.forEach(d => {
      grid.appendChild(Utils.el('div', { class: 'heatmap-label', text: d }));
      for (let h = 0; h < 24; h++) {
        const level = Math.floor(Math.random() * 5);
        grid.appendChild(Utils.el('div', { class: `heatmap-cell l${level}`, text: level, title: `${d} ${h}:00 — ${level * 20}% activity` }));
      }
    });
    wrap.appendChild(grid);
    Modal.open('Activity Heatmap', wrap);
  },

  /* --- Investigation Comparison --- */
  openComparison() {
    AuditLog.log('VIEW', 'Investigation Comparison');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> INVESTIGATION COMPARISON' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Compare two targets side-by-side. Enter two emails/usernames/domains to find overlaps.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'cmp-a', placeholder: 'target A...', value: State.results?.query || '' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'cmp-b', placeholder: 'target B...' }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'COMPARE', onclick: async () => {
      const a = Utils.$('#cmp-a').value.trim();
      const b = Utils.$('#cmp-b').value.trim();
      if (!a || !b) { Toast.show('Enter both targets', 'error'); return; }
      const out = Utils.$('#cmp-result');
      out.innerHTML = '<div class="card-placeholder">Running quick scan on both targets...</div>';
      // Quick scan both
      const [rA, rB] = await Promise.all([
        this.quickScan(a),
        this.quickScan(b)
      ]);
      out.innerHTML = '';
      // Find overlaps
      const overlaps = [];
      if (rA.platforms && rB.platforms) {
        const shared = rA.platforms.filter(p => rB.platforms.includes(p));
        if (shared.length) overlaps.push({ type: 'Shared platforms', items: shared });
      }
      if (rA.breaches && rB.breaches) {
        const shared = rA.breaches.filter(b => rB.breaches.includes(b));
        if (shared.length) overlaps.push({ type: 'Shared breaches', items: shared });
      }
      // Side-by-side table
      const table = Utils.el('table', { class: 'dns-table', style: { width: '100%' } });
      table.appendChild(Utils.el('thead', {}, [Utils.el('tr', {}, [Utils.el('th', { text: 'Metric' }), Utils.el('th', { text: a }), Utils.el('th', { text: b })])]));
      const tbody = Utils.el('tbody');
      tbody.appendChild(Utils.el('tr', {}, [Utils.el('td', { text: 'Risk Score' }), Utils.el('td', { text: String(rA.risk || 0) }), Utils.el('td', { text: String(rB.risk || 0) })]));
      tbody.appendChild(Utils.el('tr', {}, [Utils.el('td', { text: 'Platforms Found' }), Utils.el('td', { text: String(rA.platforms?.length || 0) }), Utils.el('td', { text: String(rB.platforms?.length || 0) })]));
      tbody.appendChild(Utils.el('tr', {}, [Utils.el('td', { text: 'Breaches' }), Utils.el('td', { text: String(rA.breaches?.length || 0) }), Utils.el('td', { text: String(rB.breaches?.length || 0) })]));
      table.appendChild(tbody);
      out.appendChild(table);
      if (overlaps.length) {
        out.appendChild(Utils.el('div', { class: 'text-sm mt-3', style: { color: 'var(--accent-amber)' }, text: 'OVERLAPS DETECTED:' }));
        overlaps.forEach(o => {
          out.appendChild(Utils.el('div', { class: 'text-sm', text: `• ${o.type}: ${o.items.join(', ')}` }));
        });
      } else {
        out.appendChild(Utils.el('div', { class: 'text-sm text-dim mt-3', text: 'No overlaps detected.' }));
      }
    } }));
    wrap.appendChild(Utils.el('div', { id: 'cmp-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Investigation Comparison', wrap);
  },

  async quickScan(target) {
    const result = { target, risk: 0, platforms: [], breaches: [] };
    try {
      if (Utils.isValidEmail(target)) {
        const b = await API.Breaches.checkEmail(target, State.settings.hibpApiKey);
        if (b.breaches) result.breaches = b.breaches.map(x => x.Name);
        const gh = await API.GitHub.searchByEmail(target);
        if (gh.items) result.platforms.push('GitHub');
      } else {
        const us = await API.Usernames.search(target);
        result.platforms = us.filter(u => u.found).map(u => u.name);
        result.risk = Math.min(result.platforms.length * 3, 30);
      }
    } catch {}
    return result;
  },

  /* --- Diff Engine --- */
  openDiff() {
    AuditLog.log('VIEW', 'Diff Engine');
    const diffs = Monitor.getDiffs();
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> DIFF ENGINE' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: `${diffs.length} targets tracked. Re-scan to see changes over time.` }));
    if (diffs.length) {
      diffs.forEach(d => {
        wrap.appendChild(Utils.el('div', { class: 'breach-item' }, [
          Utils.el('div', { class: 'breach-name', text: d.target }),
          Utils.el('div', { class: 'breach-date', text: `Last: ${Utils.formatDateTime(d.ts)}` }),
          Utils.el('div', { class: 'breach-desc', text: `Current: ${JSON.stringify(d.result)}` }),
          d.changes && d.changes.length ? Utils.el('div', { class: 'breach-data-types' }, d.changes.map(c => Utils.el('span', { class: 'pill warn', text: `${c.field}: ${c.old}→${c.new}` }))) : Utils.el('div', { class: 'text-xs text-dim mt-2', text: 'No changes detected yet' })
        ]));
      });
    } else {
      wrap.appendChild(Utils.el('div', { class: 'card-placeholder', text: 'No diff baselines yet. Add a monitor to start tracking changes.' }));
    }
    Modal.open('Diff Engine', wrap);
  },

  /* --- Webhooks --- */
  openWebhooks() {
    AuditLog.log('VIEW', 'Webhook Notifications');
    const stored = localStorage.getItem('ghostyeye:webhook') || '';
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Webhook Notifications' }),
      Utils.el('p', { class: 'text-sm text-dim', text: 'POST scan results to a webhook URL (Slack, Discord, custom endpoint) when scans complete.' }),
      Utils.el('input', { type: 'text', class: 'vault-input', id: 'wh-url', placeholder: 'https://hooks.slack.com/services/...', value: stored, style: { marginTop: '8px' } }),
      Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'SAVE_WEBHOOK', onclick: () => {
        const url = Utils.$('#wh-url').value.trim();
        localStorage.setItem('ghostyeye:webhook', url);
        Toast.show(url ? 'Webhook saved' : 'Webhook removed', 'success');
      } }),
      Utils.el('button', { class: 'icon-btn', style: { marginTop: '8px', width: 'auto', padding: '8px 14px' }, text: 'TEST_WEBHOOK', onclick: async () => {
        const url = Utils.$('#wh-url').value.trim();
        if (!url) { Toast.show('Enter a webhook URL', 'error'); return; }
        try {
          await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: 'GhostyEye OSINT — webhook test successful ✅', ts: Date.now() }) });
          Toast.show('Test sent', 'success');
        } catch (e) { Toast.show('Test failed: ' + e.message, 'error'); }
      } })
    ]));
    Modal.open('Webhook Notifications', wrap);
  },

  /* --- Paranoia Mode (Self-Destruct) --- */
  openParanoia() {
    AuditLog.log('VIEW', 'Paranoia Mode');
    const stored = parseInt(localStorage.getItem('ghostyeye:paranoia') || '0');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Self-Destruct History (Paranoia Mode)' }),
      Utils.el('p', { class: 'text-sm text-dim', text: 'Automatically wipe search history after X hours. Set to 0 to disable.' }),
      Utils.el('select', { id: 'paranoia-hours', class: 'drawer-field-input', style: { marginTop: '8px' } }, [
        Utils.el('option', { value: '0', text: 'DISABLED', attrs: stored === 0 ? { selected: '' } : {} }),
        Utils.el('option', { value: '1', text: '1 HOUR', attrs: stored === 1 ? { selected: '' } : {} }),
        Utils.el('option', { value: '6', text: '6 HOURS', attrs: stored === 6 ? { selected: '' } : {} }),
        Utils.el('option', { value: '24', text: '24 HOURS', attrs: stored === 24 ? { selected: '' } : {} }),
        Utils.el('option', { value: '168', text: '7 DAYS', attrs: stored === 168 ? { selected: '' } : {} })
      ]),
      Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'SAVE', onclick: () => {
        const h = parseInt(Utils.$('#paranoia-hours').value);
        localStorage.setItem('ghostyeye:paranoia', String(h));
        Toast.show(h ? `Paranoia mode: history auto-wipes after ${h}h` : 'Paranoia mode disabled', 'success');
      } })
    ]));
    wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Wipe Now' }),
      Utils.el('button', { class: 'icon-btn', style: { width: 'auto', padding: '10px 14px', gap: '8px', color: 'var(--accent-red)' }, html: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg><span style="font-size:0.78rem;">WIPE_ALL_DATA</span>', onclick: () => {
        if (confirm('Wipe ALL history, audit logs, and settings? This cannot be undone.')) {
          ['ghostyeye:history', 'ghostyeye:audit', 'ghostyeye:settings', 'ghostyeye:monitors', 'ghostyeye:diffs', 'ghostyeye:vault'].forEach(k => localStorage.removeItem(k));
          Toast.show('All data wiped', 'success');
          Modal.close();
        }
      } })
    ]));
    Modal.open('Paranoia Mode', wrap);
  },

  /* --- Request Obfuscation --- */
  openObfuscation() {
    AuditLog.log('VIEW', 'Request Obfuscation');
    const enabled = localStorage.getItem('ghostyeye:obfuscation') === '1';
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Request Obfuscation' }),
      Utils.el('div', { class: 'toggle' }, [
        Utils.el('div', { class: 'toggle-label', text: 'Randomize User-Agents' }),
        Utils.el('div', { class: `toggle-switch ${enabled ? 'on' : ''}`, id: 'obf-toggle', onclick: (e) => {
          const on = !e.target.classList.contains('on');
          e.target.classList.toggle('on', on);
          localStorage.setItem('ghostyeye:obfuscation', on ? '1' : '0');
          Toast.show(on ? 'Obfuscation enabled' : 'Obfuscation disabled', 'success');
        } })
      ]),
      Utils.el('p', { class: 'text-xs text-dim', style: { marginTop: '8px' }, text: 'When enabled, GhostyEye randomizes the User-Agent header and adds small delays between requests to mimic human behavior and avoid rate limiting.' })
    ]));
    Modal.open('Request Obfuscation', wrap);
  },

  /* --- Tor Routing Info --- */
  openTor() {
    AuditLog.log('VIEW', 'Tor Routing');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> TOR ROUTING' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Tor routing cannot be enabled directly from a browser-based app (browsers cannot open SOCKS5 connections to Tor). However, you can use GhostyEye through Tor in two ways:' }));
    wrap.appendChild(Utils.el('div', { class: 'breach-item', style: { borderColor: 'var(--accent-cyan)' } }, [
      Utils.el('div', { class: 'breach-name', style: { color: 'var(--accent-cyan)' }, text: 'Option 1: Tor Browser' }),
      Utils.el('div', { class: 'breach-desc', text: 'Open GhostyEye in the Tor Browser. All requests will automatically route through the Tor network.' })
    ]));
    wrap.appendChild(Utils.el('div', { class: 'breach-item', style: { borderColor: 'var(--accent-cyan)' } }, [
      Utils.el('div', { class: 'breach-name', style: { color: 'var(--accent-cyan)' }, text: 'Option 2: System Tor + Proxy' }),
      Utils.el('div', { class: 'breach-desc', text: 'Run Tor locally (SOCKS5 on 127.0.0.1:9050), configure your browser to use the Tor proxy, then open GhostyEye.' })
    ]));
    wrap.appendChild(Utils.el('div', { class: 'breach-item', style: { borderColor: 'var(--accent-cyan)' } }, [
      Utils.el('div', { class: 'breach-name', style: { color: 'var(--accent-cyan)' }, text: 'Option 3: Self-Host with Tor Middleware' }),
      Utils.el('div', { class: 'breach-desc', text: 'Deploy GhostyEye behind a Tor hidden service (e.g., via a Node.js reverse proxy that forwards requests through tor). This gives you a .onion URL.' })
    ]));
    Modal.open('Tor Routing', wrap);
  },

  /* --- Corporate Intelligence --- */
  openCorporate() {
    AuditLog.log('VIEW', 'Corporate Intelligence');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> CORPORATE INTELLIGENCE' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Reconstruct an organization\'s digital footprint from a domain. Enter a company domain to map employees, leaked emails, and infrastructure.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'ci-domain', placeholder: 'company.com...', style: { marginTop: '8px' } }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'INVESTIGATE', onclick: async () => {
      const domain = Utils.$('#ci-domain').value.trim();
      if (!domain) { Toast.show('Enter a domain', 'error'); return; }
      const out = Utils.$('#ci-result');
      out.innerHTML = '<div class="card-placeholder">Running corporate intelligence scan...</div>';
      const ssl = await AdvAPI.SSL.lookup(domain);
      const subdomains = await AdvAPI.SubdomainEnum.enumerate(domain);
      out.innerHTML = '';
      out.appendChild(Card.row('Domain', domain));
      out.appendChild(Card.row('SSL Certificates', String(ssl.totalCerts || 0)));
      out.appendChild(Card.row('SAN Domains', String(ssl.sanDomains?.length || 0)));
      out.appendChild(Card.row('Subdomains Found', String(subdomains.total)));
      // Google dork for emails
      out.appendChild(Utils.el('a', { class: 'dork-item', href: `https://www.google.com/search?q=site:${domain}+%22@${domain}%22`, target: '_blank' }, [Utils.el('span', { class: 'dork-operator', text: 'DORK' }), Utils.el('span', { text: `Find emails on ${domain}` })]));
      out.appendChild(Utils.el('a', { class: 'dork-item', href: `https://www.google.com/search?q=site:linkedin.com+%22${domain}%22`, target: '_blank' }, [Utils.el('span', { class: 'dork-operator', text: 'DORK' }), Utils.el('span', { text: 'Find employees on LinkedIn' })]));
      if (ssl.sanDomains && ssl.sanDomains.length) {
        out.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Discovered subdomains (potential employee services):' }));
        const grid = Utils.el('div', { class: 'platform-grid' });
        ssl.sanDomains.slice(0, 30).forEach(d => grid.appendChild(Utils.el('a', { class: 'platform-item found', href: `https://${d}`, target: '_blank' }, [Utils.el('div', { class: 'platform-name', text: d })])));
        out.appendChild(grid);
      }
    } }));
    wrap.appendChild(Utils.el('div', { id: 'ci-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Corporate Intelligence', wrap);
  },

  /* --- Crypto Investigation --- */
  openCryptoInvestigation() {
    AuditLog.log('VIEW', 'Crypto Investigation');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> CRYPTO INVESTIGATION' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Trace a Bitcoin or Ethereum address through the blockchain. View transactions, balances, and exchange flows.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'ciw-addr', placeholder: 'BTC or ETH address...', style: { marginTop: '8px' } }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'TRACE', onclick: async () => {
      const addr = Utils.$('#ciw-addr').value.trim();
      if (!addr) { Toast.show('Enter an address', 'error'); return; }
      const type = AdvAPI.Crypto.detectType(addr);
      if (!type) { Toast.show('Unrecognized address', 'error'); return; }
      const out = Utils.$('#ciw-result');
      out.innerHTML = `<div class="card-placeholder">Tracing ${type} address...</div>`;
      const result = type === 'BTC' ? await AdvAPI.Crypto.lookupBTC(addr) : await AdvAPI.Crypto.lookupETH(addr);
      out.innerHTML = '';
      out.appendChild(Card.row('Address', addr, { mono: true }));
      out.appendChild(Card.row('Type', type));
      if (result.error) { out.appendChild(Utils.el('div', { class: 'card-placeholder', text: result.error })); return; }
      if (type === 'BTC') {
        out.appendChild(Card.row('Total Received', `${result.totalReceived?.toFixed(4)} BTC`));
        out.appendChild(Card.row('Total Sent', `${result.totalSent?.toFixed(4)} BTC`));
        out.appendChild(Card.row('Current Balance', `${result.finalBalance?.toFixed(4)} BTC`));
        out.appendChild(Card.row('Transactions', String(result.txCount)));
        // External links for deeper investigation
        out.appendChild(Utils.el('a', { class: 'dork-item', href: `https://www.walletexplorer.com/?q=${addr}`, target: '_blank' }, [Utils.el('span', { class: 'dork-operator', text: 'WALLET' }), Utils.el('span', { text: 'WalletExplorer — cluster analysis' })]));
        out.appendChild(Utils.el('a', { class: 'dork-item', href: `https://okynter.baadmargin.com/address/${addr}`, target: '_blank' }, [Utils.el('span', { class: 'dork-operator', text: 'OTC' }), Utils.el('span', { text: 'OTC dealer check' })]));
      } else {
        out.appendChild(Card.row('Balance', `${result.balance?.toFixed(4)} ETH`));
        out.appendChild(Card.row('Transactions', String(result.txCount)));
        out.appendChild(Utils.el('a', { class: 'dork-item', href: `https://etherscan.io/address/${addr}`, target: '_blank' }, [Utils.el('span', { class: 'dork-operator', text: 'ETHERSCAN' }), Utils.el('span', { text: 'Full history on Etherscan' })]));
      }
    } }));
    wrap.appendChild(Utils.el('div', { id: 'ciw-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Crypto Investigation', wrap);
  },

  /* --- Brand Protection --- */
  openBrandProtection() {
    AuditLog.log('VIEW', 'Brand Protection');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> BRAND PROTECTION' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Monitor for typosquatted domains and fake social accounts impersonating your brand.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'bp-brand', placeholder: 'brand name or domain...', style: { marginTop: '8px' } }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'SCAN', onclick: () => {
      const brand = Utils.$('#bp-brand').value.trim();
      if (!brand) { Toast.show('Enter a brand', 'error'); return; }
      const out = Utils.$('#bp-result');
      out.innerHTML = '';
      // Generate typosquatted domains
      const typos = [];
      const base = brand.replace(/\.[a-z]+$/, '');
      // Adjacent key typos
      const keyboard = 'qwertyuiopasdfghjklzxcvbnm';
      for (let i = 0; i < base.length; i++) {
        for (const c of keyboard) {
          if (c !== base[i]) typos.push(base.substring(0, i) + c + base.substring(i + 1));
        }
      }
      // Add common TLDs
      const tlds = ['.com', '.net', '.org', '.io', '.co', '.xyz', '.info', '.biz'];
      out.appendChild(Utils.el('div', { class: 'text-sm mt-3', text: `${typos.length} potential typosquatted domains generated. Click to check availability:` }));
      const grid = Utils.el('div', { class: 'platform-grid' });
      typos.slice(0, 50).forEach(t => {
        tlds.forEach(tld => {
          grid.appendChild(Utils.el('a', { class: 'platform-item', href: `https://www.whois.com/whois/${t}${tld}`, target: '_blank' }, [Utils.el('div', { class: 'platform-name', text: `${t}${tld}` })]));
        });
      });
      out.appendChild(grid);
      // Social media impersonation check
      out.appendChild(Utils.el('div', { class: 'text-sm mt-3', text: 'Check social platforms for impersonation:' }));
      const sm = Utils.el('div', { class: 'platform-grid' });
      ['twitter', 'instagram', 'facebook', 'tiktok', 'linkedin'].forEach(p => {
        sm.appendChild(Utils.el('a', { class: 'platform-item', href: `https://${p}.com/${brand}`, target: '_blank' }, [Utils.el('div', { class: 'platform-name', text: `${p}/${brand}` })]));
      });
      out.appendChild(sm);
    } }));
    wrap.appendChild(Utils.el('div', { id: 'bp-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Brand Protection', wrap);
  },

  /* --- Threat Actor Profiling --- */
  openThreatActor() {
    AuditLog.log('VIEW', 'Threat Actor Profiling');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> THREAT ACTOR PROFILING' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Cluster breach data, forum posts, and git activity to profile a threat actor. Enter a username, email, or handle.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'ta-target', placeholder: 'handle/email/username...', style: { marginTop: '8px' }, value: State.results?.query || '' }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'PROFILE', onclick: async () => {
      const t = Utils.$('#ta-target').value.trim();
      if (!t) { Toast.show('Enter a target', 'error'); return; }
      const out = Utils.$('#ta-result');
      out.innerHTML = '<div class="card-placeholder">Profiling threat actor...</div>';
      // Collect data
      const data = { breaches: [], github: null, platforms: [] };
      if (Utils.isValidEmail(t)) {
        const b = await API.Breaches.checkEmail(t, State.settings.hibpApiKey);
        if (b.breaches) data.breaches = b.breaches;
        const gh = await API.GitHub.searchByEmail(t);
        if (gh.items) data.github = gh.items;
      } else {
        const us = await API.Usernames.search(t);
        data.platforms = us.filter(u => u.found);
        const u = await API.GitHub.getUser(t);
        if (u.login) data.github = [u];
      }
      // Generate profile via LLM
      const prompt = `Profile this threat actor based on the following data. Respond in this format:
THREAT_LEVEL: [low/medium/high/critical]
ACTOR_TYPE: [script_kiddie/hacktivist/criminal/APT/insider]
CAPABILITIES: [list of tools, skills, access]
TTPs: [tactics, techniques, procedures]
MOTIVATION: [financial/political/ideological/personal]
INFRASTRUCTURE: [domains, IPs, services used]
RECOMMENDATION: [one sentence defensive recommendation]

DATA:
${JSON.stringify(data, null, 2)}`;
      const profile = await API.LLM.generate(prompt);
      out.innerHTML = '';
      if (profile) {
        out.appendChild(Utils.el('pre', { class: 'api-code', text: profile, style: { whiteSpace: 'pre-wrap' } }));
      } else {
        out.appendChild(Utils.el('div', { class: 'card-placeholder', text: 'LLM unavailable — raw data:' }));
        out.appendChild(Utils.el('pre', { class: 'api-code', text: JSON.stringify(data, null, 2), style: { whiteSpace: 'pre-wrap' } }));
      }
    } }));
    wrap.appendChild(Utils.el('div', { id: 'ta-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Threat Actor Profiling', wrap);
  },

  /* --- Romance Scam Detection --- */
  openRomanceScam() {
    AuditLog.log('VIEW', 'Romance Scam Detection');
    const wrap = Utils.el('div', { class: 'flex-col gap-3' });
    wrap.appendChild(Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> ROMANCE SCAM DETECTION' }));
    wrap.appendChild(Utils.el('p', { class: 'text-sm text-dim', text: 'Cross-reference an email, phone, or photo against known scam databases. Enter any identifier to check.' }));
    wrap.appendChild(Utils.el('input', { type: 'text', class: 'vault-input', id: 'rs-target', placeholder: 'email, phone, or name...', style: { marginTop: '8px' }, value: State.results?.query || '' }));
    wrap.appendChild(Utils.el('button', { class: 'search-btn', style: { marginTop: '8px', width: 'auto' }, text: 'CHECK', onclick: () => {
      const t = Utils.$('#rs-target').value.trim();
      if (!t) { Toast.show('Enter a target', 'error'); return; }
      const out = Utils.$('#rs-result');
      out.innerHTML = '';
      // External scam databases
      const databases = [
        { name: 'ScamSearch', url: `https://scamsearch.io/search?key=${encodeURIComponent(t)}` },
        { name: 'Scamdoc', url: `https://www.scamdoc.com/view/${encodeURIComponent(t)}` },
        { name: 'RomanceScams.org Forum', url: `https://www.romancescams.org/?s=${encodeURIComponent(t)}` },
        { name: 'Reddit /scams', url: `https://www.reddit.com/r/scams/search/?q=${encodeURIComponent(t)}` },
        { name: 'Google (scam reports)', url: `https://www.google.com/search?q=${encodeURIComponent('"' + t + '" scam OR fraud OR fake')}` },
        { name: 'Truecaller (phone)', url: `https://www.truecaller.com/search/${encodeURIComponent(t)}` },
        { name: 'BeenVerified', url: `https://www.beenverified.com/people/${encodeURIComponent(t)}` },
      ];
      out.appendChild(Utils.el('div', { class: 'text-sm mt-3', text: 'Checking external scam databases:' }));
      databases.forEach(d => {
        out.appendChild(Utils.el('a', { class: 'dork-item', href: d.url, target: '_blank' }, [Utils.el('span', { class: 'dork-operator', text: 'SCAM' }), Utils.el('span', { text: d.name })]));
      });
      out.appendChild(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Tip: Also check the target\'s profile photos using Reverse Image Search (available in the Deep Investigation menu). Scammers often reuse photos across multiple fake identities.' }));
    } }));
    wrap.appendChild(Utils.el('div', { id: 'rs-result', class: 'flex-col gap-2', style: { marginTop: '12px' } }));
    Modal.open('Romance Scam Detection', wrap);
  },

  /* --- Monitor (delegate) --- */
  openMonitor() { Monitor.open(); }
};

/* ============================================================
   PART 10 — INITIALIZATION
   ============================================================ */
function initAdvanced() {
  Modal.init();
  CmdPalette.init();
  BulkProcessor.init();
  AdvExport.init();

  // Wire up remaining header buttons
  Utils.$('#btn-graph')?.addEventListener('click', () => AdvDrawer.openGraph());
  Utils.$('#btn-monitor')?.addEventListener('click', () => Monitor.open());

  // Check for shared results in URL hash
  if (location.hash.startsWith('#share=')) {
    try {
      const data = JSON.parse(decodeURIComponent(escape(atob(location.hash.substring(7)))));
      State.results = data;
      Toast.show(`Loaded shared result for ${data.query}`, 'info');
      AuditLog.log('SHARE_LOAD', data.query);
    } catch (e) { console.warn('Failed to load shared result', e); }
  }

  // Check paranoia mode (auto-wipe history)
  const paranoia = parseInt(localStorage.getItem('ghostyeye:paranoia') || '0');
  if (paranoia > 0) {
    const history = Storage.getHistory();
    const cutoff = Date.now() - paranoia * 3600 * 1000;
    const filtered = history.filter(h => h.ts > cutoff);
    if (filtered.length < history.length) {
      try { localStorage.setItem(Storage.HISTORY_KEY, JSON.stringify(filtered)); } catch {}
      console.log(`[GhostyEye] Paranoia mode: wiped ${history.length - filtered.length} old entries`);
    }
  }

  // Check due monitors on load
  setTimeout(() => Monitor.checkDueMonitors(), 3000);

  // Audit log initialization
  AuditLog.log('INIT', 'GhostyEye OSINT loaded');

  console.log('[GhostyEye] Advanced features initialized — 42 features ready');
}

// Initialize when DOM is ready (after main app.js)
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => setTimeout(initAdvanced, 100));
} else {
  setTimeout(initAdvanced, 100);
}
