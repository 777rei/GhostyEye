/* ============================================================
   GhostyEye OSINT — app.js
   Full client-side OSINT toolkit.
   All API calls are made from the browser using free public APIs.
   ============================================================ */
'use strict';

/* ============================================================
   Section 1 — Utilities
   ============================================================ */
const Utils = {
  $(sel, root = document) { return root.querySelector(sel); },
  $$(sel, root = document) { return Array.from(root.querySelectorAll(sel)); },

  el(tag, props = {}, children = []) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') node.className = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'attrs') for (const [ak, av] of Object.entries(v)) node.setAttribute(ak, av);
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
      else node[k] = v;
    }
    for (const c of [].concat(children)) {
      if (c == null) continue;
      if (typeof c === 'string' || typeof c === 'number') node.appendChild(document.createTextNode(String(c)));
      else node.appendChild(c);
    }
    return node;
  },

  // RFC 5322 simplified email regex
  isValidEmail(s) {
    if (typeof s !== 'string') return false;
    const re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
    return re.test(s.trim());
  },

  isValidDomain(s) {
    if (typeof s !== 'string') return false;
    const t = s.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    const re = /^(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/;
    return re.test(t);
  },

  isValidIP(s) {
    const t = s.trim();
    const v4 = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (v4.test(t)) return t.split('.').every(n => +n >= 0 && +n <= 255);
    const v6 = /^(([0-9a-f]{1,4}:){7}[0-9a-f]{1,4}|([0-9a-f]{1,4}:){1,7}:|([0-9a-f]{1,4}:){1,6}:[0-9a-f]{1,4}|([0-9a-f]{1,4}:){1,5}(:[0-9a-f]{1,4}){1,2}|([0-9a-f]{1,4}:){1,4}(:[0-9a-f]{1,4}){1,3}|([0-9a-f]{1,4}:){1,3}(:[0-9a-f]{1,4}){1,4}|([0-9a-f]{1,4}:){1,2}(:[0-9a-f]{1,4}){1,5}|[0-9a-f]{1,4}:((:[0-9a-f]{1,4}){1,6})|:((:[0-9a-f]{1,4}){1,7}|:))$/i;
    return v6.test(t);
  },

  isValidPhone(s) {
    const t = s.trim().replace(/[\s\-\(\)\.]/g, '');
    return /^\+?\d{7,15}$/.test(t);
  },

  isMD5(s) { return /^[a-f0-9]{32}$/i.test(s.trim()); },
  isSHA1(s) { return /^[a-f0-9]{40}$/i.test(s.trim()); },
  isSHA256(s) { return /^[a-f0-9]{64}$/i.test(s.trim()); },

  md5(str) {
    // MD5 implementation (public domain, Joseph Myers)
    function rotateLeft(x, n) { return (x << n) | (x >>> (32 - n)); }
    function addUnsigned(x, y) {
      const x4 = (x & 0x40000000), y4 = (y & 0x40000000);
      const x8 = (x & 0x80000000), y8 = (y & 0x80000000);
      const result = (x & 0x3fffffff) + (y & 0x3fffffff);
      if (x4 & y4) return result ^ 0x80000000 ^ x8 ^ y8;
      if (x4 | y4) {
        if (result & 0x40000000) return result ^ 0xc0000000 ^ x8 ^ y8;
        return result ^ 0x40000000 ^ x8 ^ y8;
      }
      return result ^ x8 ^ y8;
    }
    function F(x, y, z) { return (x & y) | (~x & z); }
    function G(x, y, z) { return (x & z) | (y & ~z); }
    function H(x, y, z) { return x ^ y ^ z; }
    function I(x, y, z) { return y ^ (x | ~z); }
    function FF(a, b, c, d, x, s, ac) { a = addUnsigned(a, addUnsigned(addUnsigned(F(b, c, d), x), ac)); return addUnsigned(rotateLeft(a, s), b); }
    function GG(a, b, c, d, x, s, ac) { a = addUnsigned(a, addUnsigned(addUnsigned(G(b, c, d), x), ac)); return addUnsigned(rotateLeft(a, s), b); }
    function HH(a, b, c, d, x, s, ac) { a = addUnsigned(a, addUnsigned(addUnsigned(H(b, c, d), x), ac)); return addUnsigned(rotateLeft(a, s), b); }
    function II(a, b, c, d, x, s, ac) { a = addUnsigned(a, addUnsigned(addUnsigned(I(b, c, d), x), ac)); return addUnsigned(rotateLeft(a, s), b); }
    function convertToWordArray(str) {
      let lWordCount;
      const lMessageLength = str.length;
      const lNumberOfWords_temp1 = lMessageLength + 8;
      const lNumberOfWords_temp2 = (lNumberOfWords_temp1 - (lNumberOfWords_temp1 % 64)) / 64;
      const lNumberOfWords = (lNumberOfWords_temp2 + 1) * 16;
      const lWordArray = Array(lNumberOfWords - 1);
      let lBytePosition = 0, lByteCount = 0;
      while (lByteCount < lMessageLength) {
        lWordCount = (lByteCount - (lByteCount % 4)) / 4;
        lBytePosition = (lByteCount % 4) * 8;
        lWordArray[lWordCount] = lWordArray[lWordCount] | (str.charCodeAt(lByteCount) << lBytePosition);
        lByteCount++;
      }
      lWordCount = (lByteCount - (lByteCount % 4)) / 4;
      lBytePosition = (lByteCount % 4) * 8;
      lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
      lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
      lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
      return lWordArray;
    }
    function wordToHex(lValue) {
      let WordToHexValue = '', WordToHexValue_temp = '', lByte, lCount;
      for (lCount = 0; lCount <= 3; lCount++) {
        lByte = (lValue >>> (lCount * 8)) & 255;
        WordToHexValue_temp = '0' + lByte.toString(16);
        WordToHexValue = WordToHexValue + WordToHexValue_temp.substr(WordToHexValue_temp.length - 2, 2);
      }
      return WordToHexValue;
    }
    // UTF-8 encode
    str = unescape(encodeURIComponent(str));
    let x = [], k, AA, BB, CC, DD, a, b, c, d;
    const S11 = 7, S12 = 12, S13 = 17, S14 = 22;
    const S21 = 5, S22 = 9, S23 = 14, S24 = 20;
    const S31 = 4, S32 = 11, S33 = 16, S34 = 23;
    const S41 = 6, S42 = 10, S43 = 15, S44 = 21;
    x = convertToWordArray(str);
    a = 0x67452301; b = 0xEFCDAB89; c = 0x98BADCFE; d = 0x10325476;
    for (k = 0; k < x.length; k += 16) {
      AA = a; BB = b; CC = c; DD = d;
      a = FF(a, b, c, d, x[k], S11, 0xD76AA478);
      d = FF(d, a, b, c, x[k + 1], S12, 0xE8C7B756);
      c = FF(c, d, a, b, x[k + 2], S13, 0x242070DB);
      b = FF(b, c, d, a, x[k + 3], S14, 0xC1BDCEEE);
      a = FF(a, b, c, d, x[k + 4], S11, 0xF57C0FAF);
      d = FF(d, a, b, c, x[k + 5], S12, 0x4787C62A);
      c = FF(c, d, a, b, x[k + 6], S13, 0xA8304613);
      b = FF(b, c, d, a, x[k + 7], S14, 0xFD469501);
      a = FF(a, b, c, d, x[k + 8], S11, 0x698098D8);
      d = FF(d, a, b, c, x[k + 9], S12, 0x8B44F7AF);
      c = FF(c, d, a, b, x[k + 10], S13, 0xFFFF5BB1);
      b = FF(b, c, d, a, x[k + 11], S14, 0x895CD7BE);
      a = FF(a, b, c, d, x[k + 12], S11, 0x6B901122);
      d = FF(d, a, b, c, x[k + 13], S12, 0xFD987193);
      c = FF(c, d, a, b, x[k + 14], S13, 0xA679438E);
      b = FF(b, c, d, a, x[k + 15], S14, 0x49B40821);
      a = GG(a, b, c, d, x[k + 1], S21, 0xF61E2562);
      d = GG(d, a, b, c, x[k + 6], S22, 0xC040B340);
      c = GG(c, d, a, b, x[k + 11], S23, 0x265E5A51);
      b = GG(b, c, d, a, x[k], S24, 0xE9B6C7AA);
      a = GG(a, b, c, d, x[k + 5], S21, 0xD62F105D);
      d = GG(d, a, b, c, x[k + 10], S22, 0x2441453);
      c = GG(c, d, a, b, x[k + 15], S23, 0xD8A1E681);
      b = GG(b, c, d, a, x[k + 4], S24, 0xE7D3FBC8);
      a = GG(a, b, c, d, x[k + 9], S21, 0x21E1CDE6);
      d = GG(d, a, b, c, x[k + 14], S22, 0xC33707D6);
      c = GG(c, d, a, b, x[k + 3], S23, 0xF4D50D87);
      b = GG(b, c, d, a, x[k + 8], S24, 0x455A14ED);
      a = GG(a, b, c, d, x[k + 13], S21, 0xA9E3E905);
      d = GG(d, a, b, c, x[k + 2], S22, 0xFCEFA3F8);
      c = GG(c, d, a, b, x[k + 7], S23, 0x676F02D9);
      b = GG(b, c, d, a, x[k + 12], S24, 0x8D2A4C8A);
      a = HH(a, b, c, d, x[k + 5], S31, 0xFFFA3942);
      d = HH(d, a, b, c, x[k + 8], S32, 0x8771F681);
      c = HH(c, d, a, b, x[k + 11], S33, 0x6D9D6122);
      b = HH(b, c, d, a, x[k + 14], S34, 0xFDE5380C);
      a = HH(a, b, c, d, x[k + 1], S31, 0xA4BEEA44);
      d = HH(d, a, b, c, x[k + 4], S32, 0x4BDECFA9);
      c = HH(c, d, a, b, x[k + 7], S33, 0xF6BB4B60);
      b = HH(b, c, d, a, x[k + 10], S34, 0xBEBFBC70);
      a = HH(a, b, c, d, x[k + 13], S31, 0x289B7EC6);
      d = HH(d, a, b, c, x[k], S32, 0xEAA127FA);
      c = HH(c, d, a, b, x[k + 3], S33, 0xD4EF3085);
      b = HH(b, c, d, a, x[k + 6], S34, 0x4881D05);
      a = HH(a, b, c, d, x[k + 9], S31, 0xD9D4D039);
      d = HH(d, a, b, c, x[k + 12], S32, 0xE6DB99E5);
      c = HH(c, d, a, b, x[k + 15], S33, 0x1FA27CF8);
      b = HH(b, c, d, a, x[k + 2], S34, 0xC4AC5665);
      a = II(a, b, c, d, x[k], S41, 0xF4292244);
      d = II(d, a, b, c, x[k + 7], S42, 0x432AFF97);
      c = II(c, d, a, b, x[k + 14], S43, 0xAB9423A7);
      b = II(b, c, d, a, x[k + 5], S44, 0xFC93A039);
      a = II(a, b, c, d, x[k + 12], S41, 0x655B59C3);
      d = II(d, a, b, c, x[k + 3], S42, 0x8F0CCC92);
      c = II(c, d, a, b, x[k + 10], S43, 0xFFEFF47D);
      b = II(b, c, d, a, x[k + 1], S44, 0x85845DD1);
      a = II(a, b, c, d, x[k + 8], S41, 0x6FA87E4F);
      d = II(d, a, b, c, x[k + 15], S42, 0xFE2CE6E0);
      c = II(c, d, a, b, x[k + 6], S43, 0xA3014314);
      b = II(b, c, d, a, x[k + 13], S44, 0x4E0811A1);
      a = II(a, b, c, d, x[k + 4], S41, 0xF7537E82);
      d = II(d, a, b, c, x[k + 11], S42, 0xBD3AF235);
      c = II(c, d, a, b, x[k + 2], S43, 0x2AD7D2BB);
      b = II(b, c, d, a, x[k + 9], S44, 0xEB86D391);
      a = addUnsigned(a, AA);
      b = addUnsigned(b, BB);
      c = addUnsigned(c, CC);
      d = addUnsigned(d, DD);
    }
    return (wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d)).toLowerCase();
  },

  async sha1(str) {
    const buf = new TextEncoder().encode(str);
    const hash = await crypto.subtle.digest('SHA-1', buf);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  },

  async sha256(str) {
    const buf = new TextEncoder().encode(str);
    const hash = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
  },

  escapeHTML(s) {
    return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  },

  formatDate(d) {
    if (!d) return '—';
    try {
      const dt = new Date(d);
      if (isNaN(dt.getTime())) return String(d);
      return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
    } catch { return String(d); }
  },

  formatDateTime(d) {
    if (!d) return '—';
    try {
      const dt = new Date(d);
      if (isNaN(dt.getTime())) return String(d);
      return dt.toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch { return String(d); }
  },

  timeNow() {
    const d = new Date();
    return d.toLocaleTimeString(undefined, { hour12: false });
  },

  // Fetch with timeout
  async fetchJSON(url, opts = {}, timeout = 12000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(url, { ...opts, signal: ctrl.signal });
      const text = await res.text();
      let data;
      try { data = text ? JSON.parse(text) : null; }
      catch { data = text; }
      return { ok: res.ok, status: res.status, data, headers: res.headers };
    } finally {
      clearTimeout(t);
    }
  },

  async fetchText(url, opts = {}, timeout = 12000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeout);
    try {
      const res = await fetch(url, { ...opts, signal: ctrl.signal });
      const text = await res.text();
      return { ok: res.ok, status: res.status, text };
    } finally {
      clearTimeout(t);
    }
  },

  // Test if an image URL loads (used for avatar existence checks)
  testImage(url, timeout = 8000) {
    return new Promise((resolve) => {
      const img = new Image();
      let done = false;
      const finish = (ok) => { if (done) return; done = true; resolve(ok); };
      img.onload = () => finish(true);
      img.onerror = () => finish(false);
      setTimeout(() => finish(false), timeout);
      img.src = url;
    });
  },

  download(filename, content, mime = 'text/plain') {
    const blob = content instanceof Blob ? content : new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 100);
  },

  toCSV(rows) {
    if (!rows || !rows.length) return '';
    const cols = Object.keys(rows[0]);
    const esc = v => {
      if (v == null) return '';
      const s = typeof v === 'object' ? JSON.stringify(v) : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    return [cols.join(','), ...rows.map(r => cols.map(c => esc(r[c])).join(','))].join('\n');
  }
};

/* ============================================================
   Section 2 — Storage (Settings + History)
   ============================================================ */
const Storage = {
  SETTINGS_KEY: 'ghostyeye:settings',
  HISTORY_KEY: 'ghostyeye:history',

  defaultSettings: {
    hibpApiKey: '',
    hunterApiKey: '',
    intelfxApiKey: '',
    enableGravatar: true,
    enableGitHub: true,
    enableBreachCheck: true,
    enableUsernames: true,
    enablePGP: true,
    enableDNS: true,
    scanTimeout: 12,
    concurrent: true
  },

  getSettings() {
    try {
      const raw = localStorage.getItem(this.SETTINGS_KEY);
      return { ...this.defaultSettings, ...(raw ? JSON.parse(raw) : {}) };
    } catch { return { ...this.defaultSettings }; }
  },

  saveSettings(s) {
    try { localStorage.setItem(this.SETTINGS_KEY, JSON.stringify(s)); }
    catch (e) { console.warn('save settings failed', e); }
  },

  getHistory() {
    try {
      const raw = localStorage.getItem(this.HISTORY_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch { return []; }
  },

  addHistory(item) {
    const hist = this.getHistory();
    hist.unshift({ ...item, ts: Date.now() });
    if (hist.length > 50) hist.length = 50;
    try { localStorage.setItem(this.HISTORY_KEY, JSON.stringify(hist)); } catch {}
  },

  clearHistory() {
    try { localStorage.removeItem(this.HISTORY_KEY); } catch {}
  }
};

/* ============================================================
   Section 3 — Toast notifications
   ============================================================ */
const Toast = {
  show(msg, type = 'info', duration = 3000) {
    const icons = {
      success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
      error: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>',
      info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>'
    };
    const t = Utils.el('div', { class: `toast ${type}`, html: icons[type] || icons.info });
    t.appendChild(Utils.el('span', { text: msg }));
    Utils.$('#toast-container').appendChild(t);
    setTimeout(() => t.remove(), duration);
  }
};

/* ============================================================
   Section 4 — Platform catalog (for username search)
   ============================================================ */
const PLATFORMS = [
  // --- Major social networks (15) ---
  { name: 'GitHub',        url: u => `https://github.com/${u}`,          avatar: u => `https://unavatar.io/github/${u}` },
  { name: 'Twitter/X',     url: u => `https://x.com/${u}`,               avatar: u => `https://unavatar.io/twitter/${u}` },
  { name: 'Instagram',     url: u => `https://instagram.com/${u}`,       avatar: u => `https://unavatar.io/instagram/${u}` },
  { name: 'Facebook',      url: u => `https://facebook.com/${u}`,        avatar: u => `https://unavatar.io/facebook/${u}` },
  { name: 'TikTok',        url: u => `https://tiktok.com/@${u}`,         avatar: u => `https://unavatar.io/tiktok/${u}` },
  { name: 'YouTube',       url: u => `https://youtube.com/@${u}`,        avatar: u => `https://unavatar.io/youtube/${u}` },
  { name: 'Reddit',        url: u => `https://reddit.com/user/${u}`,     avatar: u => `https://unavatar.io/reddit/${u}` },
  { name: 'Threads',       url: u => `https://threads.net/@${u}`,        avatar: null },
  { name: 'Bluesky',       url: u => `https://bsky.app/profile/${u}`,    avatar: null },
  { name: 'Mastodon',      url: u => `https://mastodon.social/@${u}`,    avatar: u => `https://unavatar.io/mastodon/${u}` },
  { name: 'LinkedIn',      url: u => `https://linkedin.com/in/${u}`,     avatar: null },
  { name: 'Snapchat',      url: u => `https://snapchat.com/add/${u}`,    avatar: null },
  { name: 'Pinterest',     url: u => `https://pinterest.com/${u}`,       avatar: u => `https://unavatar.io/pinterest/${u}` },
  { name: 'Tumblr',        url: u => `https://${u}.tumblr.com`,          avatar: u => `https://unavatar.io/tumblr/${u}` },
  { name: 'VK',            url: u => `https://vk.com/${u}`,              avatar: null },
  { name: 'Weibo',         url: u => `https://weibo.com/${u}`,           avatar: null },
  { name: 'Quora',         url: u => `https://quora.com/profile/${u}`,   avatar: null },
  { name: 'Medium',        url: u => `https://medium.com/@${u}`,         avatar: u => `https://unavatar.io/medium/${u}` },
  { name: 'WordPress',     url: u => `https://${u}.wordpress.com`,       avatar: null },
  { name: 'Blogger',       url: u => `https://${u}.blogspot.com`,        avatar: null },
  { name: 'Substack',      url: u => `https://${u}.substack.com`,        avatar: null },
  { name: 'Ghost',         url: u => `https://${u}.ghost.io`,            avatar: null },
  { name: 'Hashnode',      url: u => `https://hashnode.com/@${u}`,       avatar: null },
  { name: 'Dev.to',        url: u => `https://dev.to/${u}`,              avatar: u => `https://unavatar.io/devto/${u}` },
  { name: 'Daily.dev',     url: u => `https://app.daily.dev/${u}`,       avatar: null },
  { name: 'Hacker News',   url: u => `https://news.ycombinator.com/user?id=${u}`, avatar: null },
  { name: 'Product Hunt',  url: u => `https://producthunt.com/@${u}`,    avatar: null },
  { name: '9GAG',          url: u => `https://9gag.com/u/${u}`,          avatar: null },
  { name: 'Imgur',         url: u => `https://imgur.com/user/${u}`,      avatar: null },
  { name: 'Flickr',        url: u => `https://flickr.com/people/${u}`,   avatar: null },
  { name: '500px',         url: u => `https://500px.com/${u}`,           avatar: null },
  { name: 'Unsplash',      url: u => `https://unsplash.com/@${u}`,       avatar: null },
  { name: 'VSCO',          url: u => `https://vsco.co/${u}`,             avatar: null },
  { name: 'EyeEm',         url: u => `https://www.eyeem.com/u/${u}`,     avatar: null },

  // --- Streaming & video (6) ---
  { name: 'Twitch',        url: u => `https://twitch.tv/${u}`,           avatar: u => `https://unavatar.io/twitch/${u}` },
  { name: 'Vimeo',         url: u => `https://vimeo.com/${u}`,           avatar: u => `https://unavatar.io/vimeo/${u}` },
  { name: 'Dailymotion',   url: u => `https://dailymotion.com/${u}`,     avatar: null },
  { name: 'Kick',          url: u => `https://kick.com/${u}`,            avatar: null },
  { name: 'Rumble',        url: u => `https://rumble.com/user/${u}`,     avatar: null },
  { name: 'Streamlabs',    url: u => `https://streamlabs.com/${u}`,      avatar: null },

  // --- Music & audio (7) ---
  { name: 'SoundCloud',    url: u => `https://soundcloud.com/${u}`,      avatar: u => `https://unavatar.io/soundcloud/${u}` },
  { name: 'Spotify',       url: u => `https://open.spotify.com/user/${u}`, avatar: u => `https://unavatar.io/spotify/${u}` },
  { name: 'Bandcamp',      url: u => `https://bandcamp.com/${u}`,        avatar: null },
  { name: 'Mixcloud',      url: u => `https://mixcloud.com/${u}`,        avatar: null },
  { name: 'Audiomack',     url: u => `https://audiomack.com/${u}`,       avatar: null },
  { name: 'Last.fm',       url: u => `https://last.fm/user/${u}`,        avatar: null },
  { name: 'Genius',        url: u => `https://genius.com/${u}`,          avatar: null },
  { name: 'ReverbNation',  url: u => `https://reverbnation.com/${u}`,    avatar: null },

  // --- Art & design (7) ---
  { name: 'DeviantArt',    url: u => `https://${u}.deviantart.com`,      avatar: null },
  { name: 'Behance',       url: u => `https://behance.net/${u}`,         avatar: null },
  { name: 'Dribbble',      url: u => `https://dribbble.com/${u}`,        avatar: u => `https://unavatar.io/dribbble/${u}` },
  { name: 'ArtStation',    url: u => `https://artstation.com/${u}`,      avatar: null },
  { name: 'CodePen',       url: u => `https://codepen.io/${u}`,          avatar: null },
  { name: 'JSFiddle',      url: u => `https://jsfiddle.net/user/${u}`,   avatar: null },
  { name: 'Replit',        url: u => `https://replit.com/@${u}`,         avatar: null },

  // --- Gaming (8) ---
  { name: 'Steam',         url: u => `https://steamcommunity.com/id/${u}`, avatar: null },
  { name: 'Xbox',          url: u => `https://account.xbox.com/profile?gamertag=${u}`, avatar: null },
  { name: 'PlayStation',   url: u => `https://psnprofiles.com/${u}`,     avatar: null },
  { name: 'Epic Games',    url: u => `https://store.epicgames.com/u/${u}`, avatar: null },
  { name: 'Itch.io',       url: u => `https://${u}.itch.io`,             avatar: null },
  { name: 'Roblox',        url: u => `https://roblox.com/user.aspx?username=${u}`, avatar: null },
  { name: 'GOG',           url: u => `https://gog.com/u/${u}`,           avatar: null },
  { name: 'Backloggd',     url: u => `https://backloggd.com/u/${u}`,     avatar: null },

  // --- Messaging (5) ---
  { name: 'Telegram',      url: u => `https://t.me/${u}`,                avatar: u => `https://unavatar.io/telegram/${u}` },
  { name: 'Discord',       url: u => `https://discord.com/users/${u}`,   avatar: null },
  { name: 'Keybase',       url: u => `https://keybase.io/${u}`,          avatar: u => `https://keybase.io/${u}/picture` },
  { name: 'Skype',         url: u => `skype:${u}?userinfo`,              avatar: null },
  { name: 'Signal',        url: u => `https://signal.me/#p/${u}`,        avatar: null },

  // --- Developer & security (16) ---
  { name: 'GitLab',        url: u => `https://gitlab.com/${u}`,          avatar: u => `https://gitlab.com/${u}.png` },
  { name: 'Bitbucket',     url: u => `https://bitbucket.org/${u}`,       avatar: null },
  { name: 'Stack Overflow',url: u => `https://stackoverflow.com/users/${u}`, avatar: null },
  { name: 'Super User',    url: u => `https://superuser.com/users/${u}`, avatar: null },
  { name: 'Ask Ubuntu',    url: u => `https://askubuntu.com/users/${u}`, avatar: null },
  { name: 'Server Fault',  url: u => `https://serverfault.com/users/${u}`, avatar: null },
  { name: 'HackerRank',    url: u => `https://hackerrank.com/${u}`,      avatar: null },
  { name: 'LeetCode',      url: u => `https://leetcode.com/${u}`,        avatar: null },
  { name: 'CodeChef',      url: u => `https://codechef.com/users/${u}`,  avatar: null },
  { name: 'Codewars',      url: u => `https://codewars.com/users/${u}`,  avatar: null },
  { name: 'HackerEarth',   url: u => `https://hackerearth.com/@${u}`,    avatar: null },
  { name: 'FreeCodeCamp',  url: u => `https://freecodecamp.org/${u}`,    avatar: null },
  { name: 'Kaggle',        url: u => `https://kaggle.com/${u}`,          avatar: null },
  { name: 'HackTheBox',    url: u => `https://hackthebox.com/profile/${u}`, avatar: null },
  { name: 'TryHackMe',     url: u => `https://tryhackme.com/p/${u}`,     avatar: null },
  { name: 'CTFtime',       url: u => `https://ctftime.org/user/${u}`,    avatar: null },

  // --- Academic & reading (13) ---
  { name: 'Google Scholar',url: u => `https://scholar.google.com/citations?user=${u}`, avatar: null },
  { name: 'ResearchGate',  url: u => `https://researchgate.net/profile/${u}`, avatar: null },
  { name: 'Academia.edu',  url: u => `https://academia.edu/${u}`,        avatar: null },
  { name: 'ORCID',         url: u => `https://orcid.org/${u}`,           avatar: null },
  { name: 'Goodreads',     url: u => `https://goodreads.com/${u}`,       avatar: null },
  { name: 'LibraryThing',  url: u => `https://librarything.com/profile/${u}`, avatar: null },
  { name: 'Letterboxd',    url: u => `https://letterboxd.com/${u}`,      avatar: null },
  { name: 'Trakt',         url: u => `https://trakt.tv/users/${u}`,      avatar: null },
  { name: 'IMDb',          url: u => `https://www.imdb.com/user/${u}`,   avatar: null },
  { name: 'Scribd',        url: u => `https://scribd.com/${u}`,          avatar: null },
  { name: 'Wattpad',       url: u => `https://wattpad.com/user/${u}`,    avatar: null },
  { name: 'Archive of Our Own', url: u => `https://archiveofourown.org/users/${u}`, avatar: null },
  { name: 'FanFiction.net',url: u => `https://fanfiction.net/u/${u}`,    avatar: null },

  // --- Learning (6) ---
  { name: 'Coursera',      url: u => `https://coursera.org/instructor/${u}`, avatar: null },
  { name: 'edX',           url: u => `https://edx.org/bio/profiles/${u}`, avatar: null },
  { name: 'Udemy',         url: u => `https://udemy.com/user/${u}`,      avatar: null },
  { name: 'Khan Academy',  url: u => `https://khanacademy.org/profile/${u}`, avatar: null },
  { name: 'Codecademy',    url: u => `https://codecademy.com/profiles/${u}`, avatar: null },
  { name: 'Skillshare',    url: u => `https://skillshare.com/${u}`,      avatar: null },

  // --- Creator & business (10) ---
  { name: 'Patreon',       url: u => `https://patreon.com/${u}`,         avatar: null },
  { name: 'Ko-fi',         url: u => `https://ko-fi.com/${u}`,           avatar: null },
  { name: 'Buy Me a Coffee', url: u => `https://buymeacoffee.com/${u}`,  avatar: null },
  { name: 'Etsy',          url: u => `https://etsy.com/shop/${u}`,       avatar: null },
  { name: 'Gumroad',       url: u => `https://${u}.gumroad.com`,         avatar: null },
  { name: 'Redbubble',     url: u => `https://redbubble.com/people/${u}`, avatar: null },
  { name: 'Cargo',         url: u => `https://${u}.cargo.site`,          avatar: null },
  { name: 'Webflow',       url: u => `https://webflow.com/@${u}`,        avatar: null },
  { name: 'Figma',         url: u => `https://figma.com/@${u}`,          avatar: null },
  { name: 'Notion',        url: u => `https://notion.so/${u}`,           avatar: null },

  // --- Productivity (3) ---
  { name: 'Trello',        url: u => `https://trello.com/${u}`,          avatar: null },
  { name: 'Asana',         url: u => `https://asana.com/${u}`,           avatar: null },
  { name: 'Slack',         url: u => `https://${u}.slack.com`,           avatar: null },

  // --- Payment & crypto (4) ---
  { name: 'PayPal',        url: u => `https://paypal.me/${u}`,           avatar: null },
  { name: 'Coinbase',      url: u => `https://coinbase.com/${u}`,        avatar: null },
  { name: 'Binance',       url: u => `https://binance.com/en/profile/${u}`, avatar: null },
  { name: 'OpenSea',       url: u => `https://opensea.io/${u}`,          avatar: null },

  // --- Dating & social (4) ---
  { name: 'Badoo',         url: u => `https://badoo.com/${u}`,           avatar: null },
  { name: 'OkCupid',       url: u => `https://okcupid.com/profile/${u}`, avatar: u => `https://unavatar.io/okcupid/${u}` },
  { name: 'Meetup',        url: u => `https://meetup.com/members/${u}`,  avatar: null },
  { name: 'Eventbrite',    url: u => `https://eventbrite.com/e/${u}`,    avatar: null },

  // --- Link-in-bio & portfolios (5) ---
  { name: 'About.me',      url: u => `https://about.me/${u}`,            avatar: u => `https://unavatar.io/aboutme/${u}` },
  { name: 'Gravatar',      url: u => `https://gravatar.com/${u}`,        avatar: null },
  { name: 'Linktree',      url: u => `https://linktr.ee/${u}`,           avatar: null },
  { name: 'Bio.link',      url: u => `https://bio.link/${u}`,            avatar: null },
  { name: 'Carrd',         url: u => `https://${u}.carrd.co`,            avatar: null },

  // --- Code & package registries (5) ---
  { name: 'NPM',           url: u => `https://npmjs.com/~${u}`,          avatar: null },
  { name: 'PyPI',          url: u => `https://pypi.org/user/${u}`,       avatar: null },
  { name: 'Docker Hub',    url: u => `https://hub.docker.com/u/${u}`,    avatar: null },
  { name: 'Crates.io',     url: u => `https://crates.io/users/${u}`,     avatar: null },
  { name: 'Packagist',     url: u => `https://packagist.org/users/${u}`, avatar: null },

  // --- Pastes & misc (2) ---
  { name: 'Pastebin',      url: u => `https://pastebin.com/u/${u}`,      avatar: u => `https://unavatar.io/pastebin/${u}` },
  { name: 'GitBook',       url: u => `https://${u}.gitbook.io`,          avatar: null }
];


/* ============================================================
   Section 5 — OSINT API modules
   ============================================================ */
const API = {

  /* ---- Email validation (multiple free providers) ---- */
  Email: {
    async validate(email) {
      const results = {};
      // Disify - format, alias, disposable, DNS
      try {
        const r = await Utils.fetchJSON(`https://www.disify.com/api/email/${encodeURIComponent(email)}`);
        if (r.ok && r.data && typeof r.data === 'object') {
          results.disify = r.data;
        }
      } catch (e) { results.disifyError = e.message; }

      // Kickbox Open API - disposable check
      try {
        const r = await Utils.fetchJSON(`https://open.kickbox.com/v1/disposable/${encodeURIComponent(email)}`);
        if (r.ok && r.data) {
          results.kickbox = r.data;
        }
      } catch (e) { results.kickboxError = e.message; }

      // Mailcheck.ai - domain info
      const domain = email.split('@')[1];
      try {
        const r = await Utils.fetchJSON(`https://api.mailcheck.ai/domain/${encodeURIComponent(domain)}`);
        if (r.ok && r.data) {
          results.mailcheck = r.data;
        }
      } catch (e) { results.mailcheckError = e.message; }

      return results;
    }
  },

  /* ---- DNS over HTTPS (Cloudflare + Google fallback) ---- */
  DNS: {
    async lookup(domain, type = 'A') {
      // Cloudflare DoH
      try {
        const r = await Utils.fetchJSON(
          `https://cloudflare-dns.com/dns-query?name=${encodeURIComponent(domain)}&type=${type}`,
          { headers: { 'accept': 'application/dns-json' } }
        );
        if (r.ok && r.data && r.data.Answer) return r.data.Answer;
        if (r.ok && r.data && r.data.Status === 0 && !r.data.Answer) return []; // NXDOMAIN-like
      } catch {}
      // Google DoH fallback
      try {
        const r = await Utils.fetchJSON(
          `https://dns.google/resolve?name=${encodeURIComponent(domain)}&type=${type}`
        );
        if (r.ok && r.data && r.data.Answer) return r.data.Answer;
        if (r.ok && r.data && r.data.Status === 0 && !r.data.Answer) return [];
      } catch {}
      return null;
    },

    async fullLookup(domain) {
      const types = ['A', 'AAAA', 'MX', 'TXT', 'NS', 'CAA', 'SOA'];
      const out = {};
      await Promise.all(types.map(async t => {
        const r = await this.lookup(domain, t);
        out[t] = r;
      }));
      return out;
    }
  },

  /* ---- Gravatar ---- */
  Gravatar: {
    avatarUrl(email, size = 200) {
      const hash = Utils.md5(email.trim().toLowerCase());
      return `https://www.gravatar.com/avatar/${hash}?s=${size}&d=404`;
    },
    profileUrl(email) {
      const hash = Utils.md5(email.trim().toLowerCase());
      return `https://www.gravatar.com/${hash}`;
    },
    async checkExists(email) {
      const url = this.avatarUrl(email, 80);
      return await Utils.testImage(url, 6000);
    }
  },

  /* ---- GitHub (search by email) ---- */
  GitHub: {
    async searchByEmail(email) {
      try {
        const r = await Utils.fetchJSON(
          `https://api.github.com/search/users?q=${encodeURIComponent(email + ' in:email')}`,
          { headers: { 'Accept': 'application/vnd.github.v3+json' } }
        );
        if (r.ok && r.data) return r.data;
        return { error: r.status, data: r.data };
      } catch (e) { return { error: e.message }; }
    },
    async getUser(username) {
      try {
        const r = await Utils.fetchJSON(`https://api.github.com/users/${encodeURIComponent(username)}`);
        if (r.ok && r.data) return r.data;
        return { error: r.status };
      } catch (e) { return { error: e.message }; }
    }
  },

  /* ---- Have I Been Pwned (requires API key — open external if missing) ---- */
  Breaches: {
    async checkEmail(email, apiKey) {
      if (!apiKey) {
        return { needsKey: true, url: `https://haveibeenpwned.com/account/${encodeURIComponent(email)}` };
      }
      try {
        const r = await Utils.fetchJSON(
          `https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(email)}?truncateResponse=false`,
          { headers: { 'hibp-api-key': apiKey, 'user-agent': 'GhostyEye-OSINT' } }
        );
        if (r.ok && r.data) return { breaches: r.data };
        if (r.status === 404) return { breaches: [] };
        if (r.status === 401) return { error: 'Invalid HIBP API key' };
        if (r.status === 429) return { error: 'Rate limited. Try again later.' };
        return { error: `HTTP ${r.status}` };
      } catch (e) { return { error: e.message }; }
    },

    async listAllBreaches() {
      try {
        const r = await Utils.fetchJSON('https://haveibeenpwned.com/api/v3/breaches');
        if (r.ok && r.data) return r.data;
        return null;
      } catch { return null; }
    },

    async checkPasswordHash(hash) {
      // HIBP password range API — free, no key
      const prefix = hash.substring(0, 5).toUpperCase();
      const suffix = hash.substring(5).toUpperCase();
      try {
        const r = await Utils.fetchText(`https://api.pwnedpasswords.com/range/${prefix}`);
        if (r.ok && r.text) {
          const lines = r.text.split('\n');
          for (const line of lines) {
            const [s, count] = line.trim().split(':');
            if (s === suffix) return { found: true, count: parseInt(count, 10) };
          }
          return { found: false, count: 0 };
        }
        return { error: `HTTP ${r.status}` };
      } catch (e) { return { error: e.message }; }
    }
  },

  /* ---- PGP key lookup (keys.openpgp.org) ---- */
  PGP: {
    async lookup(email) {
      try {
        const r = await Utils.fetchText(
          `https://keys.openpgp.org/vks/v1/by-email/${encodeURIComponent(email)}`,
          { headers: { 'accept': 'application/pgp-keys' } }
        );
        if (r.ok && r.text && r.text.trim()) {
          return { found: true, key: r.text };
        }
        if (r.status === 404) return { found: false };
        return { error: `HTTP ${r.status}` };
      } catch (e) { return { error: e.message }; }
    }
  },

  /* ---- Username search across platforms ---- */
  Usernames: {
    async search(username) {
      const results = [];
      const checks = PLATFORMS.map(async p => {
        let found = false;
        if (p.avatar) {
          found = await Utils.testImage(p.avatar(username), 7000);
        }
        results.push({ ...p, username, found });
        return p;
      });
      await Promise.all(checks);
      return results;
    }
  },

  /* ---- IP / Hash lookups ---- */
  IP: {
    async lookup(ip) {
      // ipapi.co — free, CORS-enabled
      try {
        const r = await Utils.fetchJSON(`https://ipapi.co/${encodeURIComponent(ip)}/json/`);
        if (r.ok && r.data) return r.data;
        return { error: r.status };
      } catch (e) { return { error: e.message }; }
    },
    async ipinfo(ip) {
      try {
        const r = await Utils.fetchJSON(`https://ipinfo.io/${encodeURIComponent(ip)}/json`);
        if (r.ok && r.data) return r.data;
        return null;
      } catch { return null; }
    }
  },

  /* ---- Phone (basic) ---- */
  Phone: {
    async lookup(phone) {
      // Free API: numverify.com has free tier but limited; use libphonenumber-js local logic
      // We'll do client-side parsing only with a basic approach.
      const cleaned = phone.replace(/[^\d+]/g, '');
      return {
        input: phone,
        cleaned,
        // We can't easily determine country without a library; provide links to external lookups
        links: {
          'Truecaller': `https://www.truecaller.com/search/${encodeURIComponent(cleaned)}`,
          'Sync.me': `https://sync.me/search/?number=${encodeURIComponent(cleaned)}`,
          'Whoscall Web': `https://www.whoscall.com/en/search/${encodeURIComponent(cleaned)}`,
          'Google Search': `https://www.google.com/search?q=${encodeURIComponent(cleaned)}`
        }
      };
    }
  },

  /* ---- Domain analysis ---- */
  Domain: {
    async analyze(domain) {
      const dns = await API.DNS.fullLookup(domain);
      // Try to get WHOIS-like info from free RDAP
      let rdap = null;
      try {
        const r = await Utils.fetchJSON(`https://rdap.org/domain/${encodeURIComponent(domain)}`);
        if (r.ok && r.data) rdap = r.data;
      } catch {}
      return { dns, rdap };
    }
  },

  /* ---- Infostealer log checks (free public sources) ---- */
  Infostealer: {
    async checkEmail(email) {
      const results = { sources: [], hits: [], checked: 0 };

      // Source 1: GitHub code search — find email in leaked databases / paste dumps
      try {
        results.checked++;
        const r = await Utils.fetchJSON(
          `https://api.github.com/search/code?q=${encodeURIComponent('"' + email + '"')}&per_page=10`,
          { headers: { 'Accept': 'application/vnd.github.v3+json' } }
        );
        if (r.ok && r.data && r.data.total_count > 0) {
          results.sources.push({ name: 'GitHub Code Search', type: 'info', count: r.data.total_count, url: `https://github.com/search?q=${encodeURIComponent('"' + email + '"')}&type=code` });
          for (const item of (r.data.items || []).slice(0, 5)) {
            results.hits.push({
              source: 'GitHub',
              name: item.repository?.full_name || item.name,
              url: item.html_url,
              type: 'Public code/paste reference'
            });
          }
        }
      } catch (e) { results.sources.push({ name: 'GitHub Code Search', type: 'error', error: e.message }); }

      // Source 2: IntelligenceX public search (free, no key — limited)
      try {
        results.checked++;
        const r = await Utils.fetchText(`https://2.intelx.io/lookup/search?s=${encodeURIComponent(email)}`);
        if (r.ok && r.text) {
          results.sources.push({ name: 'Intelligence X', type: 'info', url: `https://intelx.io/?s=${encodeURIComponent(email)}` });
        }
      } catch {}

      // Source 3: HIBP (already checked separately, but link to stealer-specific view)
      results.sources.push({
        name: 'Have I Been Pwned (Stealer Logs)',
        type: 'link',
        url: `https://haveibeenpwned.com/account/${encodeURIComponent(email)}`,
        note: 'HIBP now includes stealer log data. Check directly for full results.'
      });

      // Source 4: BreachDirectory (free public)
      results.sources.push({
        name: 'BreachDirectory',
        type: 'link',
        url: `https://breachdirectory.org/search?query=${encodeURIComponent(email)}`,
        note: 'Free breach database with stealer log coverage.'
      });

      // Source 5: LeakCheck
      results.sources.push({
        name: 'LeakCheck',
        type: 'link',
        url: `https://leakcheck.io/search/${encodeURIComponent(email)}`,
        note: 'Search 4+ billion leaked credentials.'
      });

      // Source 6: Dehashed
      results.sources.push({
        name: 'DeHashed',
        type: 'link',
        url: `https://dehashed.com/search?query=email:${encodeURIComponent(email)}`,
        note: 'Search engine for breached data.'
      });

      return results;
    }
  },

  /* ---- AI Synthesis via Pollinations.AI (100% free, no API key) ---- */
  LLM: {
    async generate(prompt, timeout = 30000) {
      // Pollinations.AI — free, no auth, CORS-enabled
      try {
        const r = await Utils.fetchText(
          `https://text.pollinations.ai/${encodeURIComponent(prompt)}`,
          {},
          timeout
        );
        if (r.ok && r.text && r.text.trim()) {
          return r.text.trim();
        }
        return null;
      } catch (e) {
        console.warn('LLM generation failed:', e.message);
        return null;
      }
    },

    async synthesizeProfile(email, data) {
      const summary = this._buildDataSummary(email, data);
      const prompt = `You are an OSINT (Open Source Intelligence) analyst. Based on the following intelligence gathered about an email address, write a concise, professional digital profile breakdown in 3-4 short paragraphs. Cover: (1) identity footprint and verified accounts, (2) data breach exposure, (3) infostealer/credential exposure risk, (4) overall digital posture assessment. Be factual, objective, and analytical. Do not speculate beyond the data provided. Do not include disclaimers.

INTELLIGENCE DATA:
${summary}

Write the profile breakdown now:`;
      return await this.generate(prompt);
    },

    async generateRiskReasoning(email, data, riskScore, riskLevel) {
      const summary = this._buildDataSummary(email, data);
      const prompt = `You are an OSINT risk analyst. Based on the following intelligence data, the calculated risk score is ${riskScore}/100 (${riskLevel} risk). In ONE single sentence (max 25 words), explain the primary reason for this risk level. Be specific and cite the most impactful factor. Do not use phrases like "the risk is" — just state the reason.

INTELLIGENCE DATA:
${summary}

One-sentence risk reasoning:`;
      return await this.generate(prompt);
    },

    _buildDataSummary(email, data) {
      const lines = [`Email: ${email}`];
      if (data.validation) {
        const v = data.validation;
        if (v.disify) lines.push(`Validation: format=${v.disify.format}, disposable=${v.disify.disposable}, dns=${v.disify.dns}, alias=${v.disify.alias}`);
        if (v.mailcheck) lines.push(`Domain risk: ${v.mailcheck.risk || 'unknown'}`);
      }
      if (data.gravatar) lines.push(`Gravatar: ${data.gravatar.exists ? 'profile picture found' : 'not found'}`);
      if (data.github) lines.push(`GitHub: ${data.github.items ? data.github.items.length + ' accounts found' : 'none'}`);
      if (data.breaches) {
        if (data.breaches.breaches) {
          lines.push(`Data breaches: ${data.breaches.breaches.length} found`);
          if (data.breaches.breaches.length) {
            lines.push('Breach names: ' + data.breaches.breaches.slice(0, 10).map(b => b.Name).join(', '));
          }
        } else if (data.breaches.needsKey) {
          lines.push('Data breaches: requires HIBP API key (not checked)');
        }
      }
      if (data.pgp) lines.push(`PGP key: ${data.pgp.found ? 'published' : 'not found'}`);
      if (data.usernames) {
        const found = data.usernames.filter(u => u.found);
        lines.push(`Username search: ${found.length}/${data.usernames.length} platforms matched`);
        if (found.length) lines.push('Found on: ' + found.slice(0, 15).map(u => u.name).join(', '));
      }
      if (data.infostealer) {
        lines.push(`Infostealer sources checked: ${data.infostealer.checked}`);
        if (data.infostealer.hits.length) lines.push(`Infostealer hits: ${data.infostealer.hits.length} references found`);
      }
      if (data.dns) {
        const mx = (data.dns.MX || []).length;
        const a = (data.dns.A || []).length;
        lines.push(`DNS: ${a} A records, ${mx} MX records`);
      }
      return lines.join('\n');
    }
  },

  /* ---- Risk Assessment (algorithmic + LLM reasoning) ---- */
  Risk: {
    assess(data) {
      let score = 0;
      const factors = [];

      // Email validity & domain reputation
      if (data.validation && data.validation.disify) {
        const v = data.validation.disify;
        if (!v.format) { score += 50; factors.push({ label: 'Invalid email format', impact: +50, type: 'pos' }); }
        if (v.disposable) { score += 25; factors.push({ label: 'Disposable email domain', impact: +25, type: 'pos' }); }
        if (!v.dns) { score += 15; factors.push({ label: 'Domain has no MX records', impact: +15, type: 'pos' }); }
        if (v.alias) { score += 5; factors.push({ label: 'Uses email alias (+)', impact: +5, type: 'pos' }); }
      }

      // Data breaches
      if (data.breaches && data.breaches.breaches) {
        const n = data.breaches.breaches.length;
        const breachScore = Math.min(40, n * 8);
        score += breachScore;
        factors.push({ label: `${n} data breach(es) found`, impact: +breachScore, type: 'pos' });
      }

      // Infostealer hits
      if (data.infostealer && data.infostealer.hits && data.infostealer.hits.length) {
        const n = data.infostealer.hits.length;
        const stealScore = Math.min(30, n * 10);
        score += stealScore;
        factors.push({ label: `${n} infostealer/paste reference(s)`, impact: +stealScore, type: 'pos' });
      }

      // Linked accounts (more accounts = bigger footprint)
      if (data.usernames) {
        const found = data.usernames.filter(u => u.found).length;
        if (found > 0) {
          const acctScore = Math.min(15, found);
          score += acctScore;
          factors.push({ label: `${found} linked platform account(s)`, impact: +acctScore, type: 'pos' });
        }
      }

      // Gravatar
      if (data.gravatar && data.gravatar.exists) {
        score += 3;
        factors.push({ label: 'Gravatar profile picture exists', impact: +3, type: 'pos' });
      }

      // GitHub
      if (data.github && data.github.items && data.github.items.length) {
        score += 5;
        factors.push({ label: `${data.github.items.length} GitHub account(s) linked`, impact: +5, type: 'pos' });
      }

      // PGP key (indicates tech-savvy user, bigger digital footprint)
      if (data.pgp && data.pgp.found) {
        score += 4;
        factors.push({ label: 'PGP key published (active digital identity)', impact: +4, type: 'pos' });
      }

      // Negative factors (reduce risk)
      if (data.validation && data.validation.disify && data.validation.disify.format && !data.validation.disify.disposable && data.validation.disify.dns) {
        factors.push({ label: 'Valid email with proper domain setup', impact: -5, type: 'neg' });
        score = Math.max(0, score - 5);
      }
      if (data.breaches && data.breaches.breaches && data.breaches.breaches.length === 0) {
        factors.push({ label: 'No breaches found in HIBP database', impact: -10, type: 'neg' });
        score = Math.max(0, score - 10);
      }

      score = Math.min(100, Math.max(0, score));
      const level = score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low';
      const levelLabel = score >= 60 ? 'High' : score >= 30 ? 'Medium' : 'Low';

      return { score, level, levelLabel, factors };
    }
  }
};

/* ============================================================
   Section 6 — Card builder & UI renderer
   ============================================================ */
const Card = {
  icons: {
    email: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 5L2 7"/></svg>',
    validation: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="10"/></svg>',
    gravatar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/></svg>',
    github: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 .3a12 12 0 0 0-3.8 23.4c.6.1.8-.3.8-.6v-2c-3.3.7-4-1.6-4-1.6-.6-1.4-1.4-1.8-1.4-1.8-1-.7.1-.7.1-.7 1.2.1 1.9 1.2 1.9 1.2 1 1.8 2.8 1.3 3.5 1 .1-.8.4-1.3.8-1.6-2.7-.3-5.5-1.3-5.5-6 0-1.3.5-2.4 1.3-3.3-.2-.4-.6-1.6 0-3.2 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0C17.3 4.7 18.3 5 18.3 5c.7 1.6.3 2.8 0 3.2.9.9 1.3 2 1.3 3.3 0 4.7-2.8 5.7-5.5 6 .5.4.8 1.1.8 2.2v3.3c0 .3.2.7.8.6A12 12 0 0 0 12 .3"/></svg>',
    breach: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
    usernames: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
    pgp: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>',
    dns: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    domain: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
    phone: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
    ip: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
    summary: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>'
  },

  create(id, title, iconName) {
    const card = Utils.el('div', { class: 'card glass', attrs: { 'data-card': id } }, [
      Utils.el('div', { class: 'card-head' }, [
        Utils.el('div', { class: 'card-title' }, [
          Utils.el('div', { class: 'card-title-icon', html: this.icons[iconName] || this.icons.summary }),
          Utils.el('span', { text: title })
        ]),
        Utils.el('div', { class: 'card-status idle', text: 'Idle', attrs: { 'data-status': 'idle' } })
      ]),
      Utils.el('div', { class: 'card-body', attrs: { 'data-body': '' } }, [
        Utils.el('div', { class: 'card-placeholder', text: 'Awaiting scan…' })
      ])
    ]);
    return card;
  },

  setStatus(card, status, label) {
    const s = Utils.$('[data-status]', card);
    s.className = `card-status ${status}`;
    s.textContent = label;
  },

  setBody(card, nodes) {
    const body = Utils.$('[data-body]', card);
    body.innerHTML = '';
    const arr = [].concat(nodes);
    for (const n of arr) {
      if (n == null) continue;
      body.appendChild(typeof n === 'string' ? Utils.el('div', { text: n }) : n);
    }
  },

  skeleton(card, count = 3) {
    const body = Utils.$('[data-body]', card);
    body.innerHTML = '';
    for (let i = 0; i < count; i++) {
      const sk = Utils.el('div', { class: 'skeleton' });
      sk.style.width = `${60 + Math.random() * 35}%`;
      body.appendChild(sk);
    }
  },

  row(label, valueNode, opts = {}) {
    const valClass = ['value'];
    if (opts.mono) valClass.push('mono');
    if (opts.color) valClass.push(opts.color);
    return Utils.el('div', { class: 'data-row' }, [
      Utils.el('div', { class: 'label', text: label }),
      Utils.el('div', { class: valClass.join(' ') }, typeof valueNode === 'string' ? [document.createTextNode(valueNode)] : [valueNode])
    ]);
  },

  pill(text, type = '') {
    return Utils.el('span', { class: `pill ${type}`, text });
  }
};

/* ============================================================
   Section 7 — State & Investigation orchestrator
   ============================================================ */
const State = {
  mode: 'email',
  query: '',
  results: null,
  scanning: false,
  abort: false,
  settings: null,
  cards: {}
};

const ScanLog = {
  add(text, type = '') {
    const log = Utils.$('#scan-log');
    const line = Utils.el('div', { class: 'scan-log-line' }, [
      Utils.el('span', { class: 'time', text: Utils.timeNow() }),
      Utils.el('span', { class: type || 'text-dim', text })
    ]);
    log.appendChild(line);
    log.scrollTop = log.scrollHeight;
  },
  clear() { Utils.$('#scan-log').innerHTML = ''; },
  setProgress(pct) { Utils.$('#scan-progress-fill').style.width = `${pct}%`; },
  setText(t) { Utils.$('#scan-status-text').textContent = t; },
  show() { Utils.$('#scan-status').classList.add('active'); },
  hide() { Utils.$('#scan-status').classList.remove('active'); ScanLog.setProgress(0); }
};

/* SSE-style Live Stream system */
const Stream = {
  startTime: 0,
  events: 0,
  sources: new Set(),
  timer: null,

  start() {
    this.startTime = Date.now();
    this.events = 0;
    this.sources = new Set();
    Utils.$('#stream-body').innerHTML = '';
    Utils.$('#stream-panel').classList.remove('hidden');
    Utils.$('#stream-count').textContent = '0';
    Utils.$('#stream-elapsed').textContent = '0.0s';
    Utils.$('#stream-sources').textContent = '0';
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this._tick(), 100);
    this.emit('info', '→', 'Establishing intel stream connection…');
  },

  stop() {
    if (this.timer) { clearInterval(this.timer); this.timer = null; }
    this.emit('ok', '✓', 'Stream closed. All modules reported.');
  },

  _tick() {
    const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(1);
    Utils.$('#stream-elapsed').textContent = elapsed + 's';
  },

  emit(type, icon, html) {
    const body = Utils.$('#stream-body');
    const elapsed = ((Date.now() - this.startTime) / 1000).toFixed(2);
    const timeStr = '+' + elapsed + 's';
    const line = Utils.el('div', { class: `stream-line ${type}` }, [
      Utils.el('span', { class: 'stream-time', text: timeStr }),
      Utils.el('span', { class: 'stream-icon', text: icon }),
      Utils.el('span', { class: 'stream-text', html: html })
    ]);
    body.appendChild(line);
    body.scrollTop = body.scrollHeight;
    this.events++;
    Utils.$('#stream-count').textContent = this.events;
  },

  source(name) {
    this.sources.add(name);
    Utils.$('#stream-sources').textContent = this.sources.size;
  },

  hide() { Utils.$('#stream-panel').classList.add('hidden'); }
};

/* ============================================================
   Section 8 — Investigation runners (per mode)
   ============================================================ */
const Runner = {

  async runEmail(email) {
    State.query = email;
    const s = State.settings;
    State.results = { mode: 'email', query: email, startedAt: new Date().toISOString(), modules: {} };

    // Build cards for email mode (now includes infostealer, AI synthesis, risk assessment)
    const grid = Utils.$('#results-grid');
    grid.innerHTML = '';
    State.cards = {};
    const cardDefs = [
      ['risk',       'Risk Assessment',         'breach'],
      ['ai',         'AI Profile Synthesis',    'summary'],
      ['summary',    'Investigation Summary',   'summary'],
      ['validation', 'Email Validation',        'validation'],
      ['gravatar',   'Gravatar Profile',        'gravatar'],
      ['github',     'GitHub Account',          'github'],
      ['breaches',   'Data Breaches',           'breach'],
      ['infostealer','Infostealer Logs',        'breach'],
      ['pgp',        'PGP Public Key',          'pgp'],
      ['dns',        'Domain DNS Records',      'dns'],
      ['usernames',  'Linked Accounts (100+)',  'usernames']
    ];
    for (const [id, title, icon] of cardDefs) {
      const c = Card.create(id, title, icon);
      grid.appendChild(c);
      State.cards[id] = c;
    }
    Utils.$('#empty-state').classList.add('hidden');
    grid.classList.remove('hidden');
    Utils.$('#export-bar').classList.remove('hidden');

    ScanLog.show();
    ScanLog.clear();
    ScanLog.setText(`Investigating ${email}…`);
    Stream.start();
    State.scanning = true;
    State.abort = false;

    const domain = email.split('@')[1];
    const localPart = email.split('@')[0];
    const cleanedUsername = localPart.replace(/[._+\-0-9]+$/, '').replace(/[._+\-]/g, '') || localPart.replace(/[._+\-]/g, '');

    // Place AI & Risk cards at top with skeleton
    Card.setStatus(State.cards.ai, 'loading', 'Waiting');
    Card.skeleton(State.cards.ai, 4);
    Card.setStatus(State.cards.risk, 'loading', 'Waiting');
    Card.skeleton(State.cards.risk, 3);
    Card.setStatus(State.cards.summary, 'loading', 'Working');
    Card.skeleton(State.cards.summary, 4);
    Card.setStatus(State.cards.infostealer, 'loading', 'Waiting');
    Card.skeleton(State.cards.infostealer, 2);

    // 1. Validation
    if (s.enableDNS !== false) {
      Card.setStatus(State.cards.validation, 'loading', 'Scanning');
      Card.skeleton(State.cards.validation, 3);
      Stream.source('Disify'); Stream.source('Kickbox'); Stream.source('Mailcheck');
      Stream.emit('info', '◈', 'Querying <b>Disify</b>, <b>Kickbox</b>, <b>Mailcheck</b> for email validation…');
      try {
        const v = await API.Email.validate(email);
        State.results.modules.validation = v;
        Render.validation(v, email);
        const valid = v.disify && v.disify.format;
        const disp = v.disify && v.disify.disposable;
        Stream.emit(valid ? 'ok' : 'err', valid ? '✓' : '✗', `Email validation: <b>${valid ? 'valid format' : 'invalid'}</b>${disp ? ', <span class="danger">disposable domain</span>' : ''}`);
      } catch (e) {
        Card.setStatus(State.cards.validation, 'error', 'Error');
        Card.setBody(State.cards.validation, [Utils.el('div', { class: 'text-dim text-sm', text: `Error: ${e.message}` })]);
        Stream.emit('err', '✗', `Validation failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(10);
    if (State.abort) return Runner.finish();

    // 2. Gravatar
    if (s.enableGravatar) {
      Card.setStatus(State.cards.gravatar, 'loading', 'Checking');
      Card.skeleton(State.cards.gravatar, 2);
      Stream.source('Gravatar');
      Stream.emit('info', '◈', 'Querying <b>Gravatar</b> for profile picture…');
      try {
        const exists = await API.Gravatar.checkExists(email);
        const profileUrl = API.Gravatar.profileUrl(email);
        const avatarUrl = API.Gravatar.avatarUrl(email, 200);
        State.results.modules.gravatar = { exists, profileUrl, avatarUrl };
        Render.gravatar(exists, profileUrl, avatarUrl, email);
        Stream.emit(exists ? 'ok' : 'warn', exists ? '✓' : '!', `Gravatar: ${exists ? '<span class="success">profile picture found</span>' : 'not found'}`);
      } catch (e) {
        Card.setStatus(State.cards.gravatar, 'error', 'Error');
        Stream.emit('err', '✗', `Gravatar check failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(20);
    if (State.abort) return Runner.finish();

    // 3. GitHub
    if (s.enableGitHub) {
      Card.setStatus(State.cards.github, 'loading', 'Searching');
      Card.skeleton(State.cards.github, 3);
      Stream.source('GitHub');
      Stream.emit('info', '◈', 'Searching <b>GitHub API</b> for accounts linked to this email…');
      try {
        const gh = await API.GitHub.searchByEmail(email);
        State.results.modules.github = gh;
        Render.github(gh);
        const n = gh.items ? gh.items.length : 0;
        Stream.emit(n ? 'ok' : 'warn', n ? '✓' : '!', `GitHub: ${n ? `<b>${n} account(s)</b> found` : 'no matches'}`);
      } catch (e) {
        Card.setStatus(State.cards.github, 'error', 'Error');
        Stream.emit('err', '✗', `GitHub search failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(30);
    if (State.abort) return Runner.finish();

    // 4. Breaches
    if (s.enableBreachCheck) {
      Card.setStatus(State.cards.breaches, 'loading', 'Checking');
      Card.skeleton(State.cards.breaches, 2);
      Stream.source('HIBP');
      Stream.emit('info', '◈', 'Querying <b>Have I Been Pwned</b> breach database (billions of leaked records)…');
      try {
        const b = await API.Breaches.checkEmail(email, s.hibpApiKey);
        State.results.modules.breaches = b;
        Render.breaches(b, email);
        if (b.needsKey) {
          Stream.emit('warn', '!', 'HIBP requires free API key — providing external link');
        } else if (b.breaches && b.breaches.length) {
          Stream.emit('err', '⚠', `<span class="danger">Found in ${b.breaches.length} data breach(es)</span>: ${b.breaches.slice(0, 5).map(x => x.Name).join(', ')}${b.breaches.length > 5 ? '…' : ''}`);
        } else if (b.breaches) {
          Stream.emit('ok', '✓', '<span class="success">No breaches found in HIBP database</span>');
        }
      } catch (e) {
        Card.setStatus(State.cards.breaches, 'error', 'Error');
        Stream.emit('err', '✗', `Breach check failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(42);
    if (State.abort) return Runner.finish();

    // 5. Infostealer logs
    Card.setStatus(State.cards.infostealer, 'loading', 'Checking');
    Stream.source('GitHub Code'); Stream.source('IntelX'); Stream.source('BreachDirectory');
    Stream.emit('info', '◈', 'Scanning <b>infostealer malware logs</b> across GitHub, IntelligenceX, BreachDirectory, LeakCheck, DeHashed…');
    try {
      const is = await API.Infostealer.checkEmail(email);
      State.results.modules.infostealer = is;
      Render.infostealer(is, email);
      if (is.hits && is.hits.length) {
        Stream.emit('err', '⚠', `<span class="danger">${is.hits.length} infostealer reference(s) found</span> in public code/paste dumps`);
      } else {
        Stream.emit('ok', '✓', 'No direct infostealer hits — providing 6 external lookup sources for manual verification');
      }
    } catch (e) {
      Card.setStatus(State.cards.infostealer, 'error', 'Error');
      Stream.emit('err', '✗', `Infostealer check failed: ${e.message}`);
    }
    ScanLog.setProgress(55);
    if (State.abort) return Runner.finish();

    // 6. PGP
    if (s.enablePGP) {
      Card.setStatus(State.cards.pgp, 'loading', 'Searching');
      Card.skeleton(State.cards.pgp, 2);
      Stream.source('keys.openpgp.org');
      Stream.emit('info', '◈', 'Looking up <b>PGP public keys</b> on keys.openpgp.org…');
      try {
        const p = await API.PGP.lookup(email);
        State.results.modules.pgp = p;
        Render.pgp(p);
        Stream.emit(p.found ? 'ok' : 'warn', p.found ? '✓' : '!', `PGP key: ${p.found ? '<span class="success">published</span>' : 'not found'}`);
      } catch (e) {
        Card.setStatus(State.cards.pgp, 'error', 'Error');
        Stream.emit('err', '✗', `PGP lookup failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(65);
    if (State.abort) return Runner.finish();

    // 7. DNS for domain
    if (s.enableDNS) {
      Card.setStatus(State.cards.dns, 'loading', 'Resolving');
      Card.skeleton(State.cards.dns, 3);
      Stream.source('Cloudflare DoH'); Stream.source('Google DoH');
      Stream.emit('info', '◈', `Resolving <b>DNS records</b> (A, AAAA, MX, TXT, NS, CAA, SOA) for <b>${domain}</b>…`);
      try {
        const dns = await API.DNS.fullLookup(domain);
        State.results.modules.dns = dns;
        Render.dns(dns, domain);
        const total = Object.values(dns).reduce((s, a) => s + (a ? a.length : 0), 0);
        Stream.emit('ok', '✓', `DNS: resolved <b>${total} records</b> across 7 record types`);
      } catch (e) {
        Card.setStatus(State.cards.dns, 'error', 'Error');
        Stream.emit('err', '✗', `DNS lookup failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(75);
    if (State.abort) return Runner.finish();

    // 8. Username search (uses local-part before any separators)
    if (s.enableUsernames && cleanedUsername) {
      Card.setStatus(State.cards.usernames, 'loading', 'Searching');
      Card.skeleton(State.cards.usernames, 2);
      Stream.source('100+ Platforms');
      Stream.emit('info', '◈', `Probing <b>${PLATFORMS.length} platforms</b> for username "<b>${cleanedUsername}</b>" (silent check, no alert to target)…`);
      try {
        const us = await API.Usernames.search(cleanedUsername);
        State.results.modules.usernames = us;
        State.results.derivedUsername = cleanedUsername;
        Render.usernames(us);
        const found = us.filter(u => u.found).length;
        Stream.emit(found ? 'ok' : 'warn', found ? '✓' : '!', `Linked accounts: <b>${found}/${us.length} platforms</b> matched${found ? ` (${us.filter(u=>u.found).slice(0,5).map(u=>u.name).join(', ')}${found>5?'…':''})` : ''}`);
      } catch (e) {
        Card.setStatus(State.cards.usernames, 'error', 'Error');
        Stream.emit('err', '✗', `Username search failed: ${e.message}`);
      }
    }
    ScanLog.setProgress(85);

    // 9. Risk Assessment (algorithmic)
    Card.setStatus(State.cards.risk, 'loading', 'Calculating');
    Stream.source('Risk Engine');
    Stream.emit('ai', '◆', 'Running <b>risk assessment algorithm</b> — synthesizing all signals…');
    const risk = API.Risk.assess(State.results.modules);
    State.results.risk = risk;
    Render.risk(risk);
    Stream.emit(risk.level === 'high' ? 'err' : risk.level === 'medium' ? 'warn' : 'ok',
               risk.level === 'high' ? '⚠' : '✓',
               `<b>Risk score: ${risk.score}/100 (${risk.levelLabel})</b> — ${risk.factors.length} factors analyzed`);
    ScanLog.setProgress(90);

    // 10. AI Synthesis (LLM)
    Card.setStatus(State.cards.ai, 'loading', 'AI analyzing');
    Stream.source('LLM (Pollinations.AI)');
    Stream.emit('ai', '◆', 'Invoking <b>LLM synthesis</b> via Pollinations.AI (free, no key) — generating profile breakdown…');
    try {
      const aiText = await API.LLM.synthesizeProfile(email, State.results.modules);
      State.results.aiSynthesis = aiText;
      await Render.aiSynthesis(aiText);
      if (aiText) {
        Stream.emit('ai', '✓', '<b>AI profile synthesis complete</b> — digital identity breakdown generated');
      } else {
        Stream.emit('warn', '!', 'AI synthesis unavailable (LLM service busy) — using fallback summary');
      }
    } catch (e) {
      Card.setStatus(State.cards.ai, 'error', 'Error');
      Stream.emit('err', '✗', `AI synthesis failed: ${e.message}`);
    }

    // 11. Risk reasoning (LLM)
    if (risk) {
      Stream.emit('ai', '◆', 'Generating cited risk reasoning statement…');
      const reasoning = await API.LLM.generateRiskReasoning(email, State.results.modules, risk.score, risk.levelLabel);
      if (reasoning) {
        State.results.riskReasoning = reasoning;
        Render.riskReasoning(reasoning);
        Stream.emit('ai', '✓', 'Risk reasoning generated');
      }
    }

    // Fill summary
    Render.summary(email);
    ScanLog.setProgress(100);
    ScanLog.setText('Investigation complete.');
    Stream.stop();
    setTimeout(() => ScanLog.hide(), 1800);

    // Save to history
    Storage.addHistory({ mode: 'email', query: email, ts: Date.now() });
    Runner.finish();
  },

  async runUsername(username) {
    State.query = username;
    State.results = { mode: 'username', query: username, startedAt: new Date().toISOString(), modules: {} };

    const grid = Utils.$('#results-grid');
    grid.innerHTML = '';
    State.cards = {};
    const cardDefs = [
      ['summary',   'Search Summary',   'summary'],
      ['usernames', 'Platform Footprint', 'usernames'],
      ['github',    'GitHub Profile',   'github'],
      ['gravatar',  'Gravatar (by username)', 'gravatar']
    ];
    for (const [id, title, icon] of cardDefs) {
      const c = Card.create(id, title, icon);
      grid.appendChild(c);
      State.cards[id] = c;
    }
    Utils.$('#empty-state').classList.add('hidden');
    grid.classList.remove('hidden');
    Utils.$('#export-bar').classList.remove('hidden');

    ScanLog.show();
    ScanLog.clear();
    ScanLog.setText(`Searching for username "${username}" across the web…`);
    Stream.start();
    State.scanning = true;
    State.abort = false;

    // Platform footprint
    Card.setStatus(State.cards.usernames, 'loading', 'Searching');
    Card.skeleton(State.cards.usernames, 3);
    Stream.source('100+ Platforms');
    Stream.emit('info', '◈', `Probing <b>${PLATFORMS.length} platforms</b> for username "<b>${username}</b>" (silent check, no alert to target)…`);
    try {
      const us = await API.Usernames.search(username);
      State.results.modules.usernames = us;
      Render.usernames(us);
      const found = us.filter(u => u.found).length;
      Stream.emit(found ? 'ok' : 'warn', found ? '✓' : '!', `Linked accounts: <b>${found}/${us.length} platforms</b> matched${found ? ` (${us.filter(u=>u.found).slice(0,5).map(u=>u.name).join(', ')}${found>5?'…':''})` : ''}`);
    } catch (e) {
      Card.setStatus(State.cards.usernames, 'error', 'Error');
      Stream.emit('err', '✗', `Username search failed: ${e.message}`);
    }
    ScanLog.setProgress(50);
    if (State.abort) return Runner.finish();

    // GitHub detailed
    Card.setStatus(State.cards.github, 'loading', 'Fetching');
    Card.skeleton(State.cards.github, 3);
    Stream.source('GitHub API');
    Stream.emit('info', '◈', 'Fetching detailed <b>GitHub profile</b>…');
    try {
      const u = await API.GitHub.getUser(username);
      State.results.modules.github = u;
      Render.githubUser(u);
      Stream.emit(u.login ? 'ok' : 'warn', u.login ? '✓' : '!', `GitHub: ${u.login ? `<b>${u.name || u.login}</b> — ${u.followers || 0} followers` : 'not found'}`);
    } catch (e) {
      Card.setStatus(State.cards.github, 'error', 'Error');
      Stream.emit('err', '✗', `GitHub lookup failed: ${e.message}`);
    }
    ScanLog.setProgress(80);

    // Summary
    Render.summaryUsername(username);
    ScanLog.setProgress(100);
    ScanLog.setText('Search complete.');
    Stream.stop();
    setTimeout(() => ScanLog.hide(), 1800);
    Storage.addHistory({ mode: 'username', query: username, ts: Date.now() });
    Runner.finish();
  },

  async runDomain(domain) {
    State.query = domain;
    State.results = { mode: 'domain', query: domain, startedAt: new Date().toISOString(), modules: {} };

    const grid = Utils.$('#results-grid');
    grid.innerHTML = '';
    State.cards = {};
    const cardDefs = [
      ['summary',   'Domain Summary',  'summary'],
      ['dns',       'DNS Records',     'dns'],
      ['validation','Domain Validation','validation'],
      ['breaches',  'Subdomain & Breach Hints', 'breach']
    ];
    for (const [id, title, icon] of cardDefs) {
      const c = Card.create(id, title, icon);
      grid.appendChild(c);
      State.cards[id] = c;
    }
    Utils.$('#empty-state').classList.add('hidden');
    grid.classList.remove('hidden');
    Utils.$('#export-bar').classList.remove('hidden');

    ScanLog.show();
    ScanLog.clear();
    ScanLog.setText(`Analyzing domain ${domain}…`);
    State.scanning = true;
    State.abort = false;

    // DNS
    Card.setStatus(State.cards.dns, 'loading', 'Resolving');
    Card.skeleton(State.cards.dns, 4);
    ScanLog.add(`Resolving DNS records for ${domain}…`, 'ok');
    try {
      const dns = await API.DNS.fullLookup(domain);
      State.results.modules.dns = dns;
      Render.dns(dns, domain);
      ScanLog.add('DNS resolution complete', 'ok');
    } catch (e) {
      Card.setStatus(State.cards.dns, 'error', 'Error');
      ScanLog.add(`DNS failed: ${e.message}`, 'err');
    }
    ScanLog.setProgress(40);
    if (State.abort) return Runner.finish();

    // Validation
    Card.setStatus(State.cards.validation, 'loading', 'Checking');
    Card.skeleton(State.cards.validation, 2);
    ScanLog.add('Validating domain & checking disposable email services…', 'ok');
    try {
      const mc = await Utils.fetchJSON(`https://api.mailcheck.ai/domain/${encodeURIComponent(domain)}`);
      State.results.modules.validation = mc;
      Render.domainValidation(mc, domain);
      ScanLog.add('Domain validation complete', 'ok');
    } catch (e) {
      Card.setStatus(State.cards.validation, 'error', 'Error');
      ScanLog.add(`Domain validation failed: ${e.message}`, 'err');
    }
    ScanLog.setProgress(70);

    // Subdomain hints (using common subdomains via DNS)
    Card.setStatus(State.cards.breaches, 'loading', 'Probing');
    Card.skeleton(State.cards.breaches, 3);
    ScanLog.add('Probing common subdomains (www, mail, api, dev, admin)…', 'ok');
    try {
      const subs = ['www', 'mail', 'smtp', 'imap', 'api', 'dev', 'staging', 'admin', 'portal', 'vpn', 'remote', 'cloud', 'app', 'blog', 'docs'];
      const results = [];
      await Promise.all(subs.map(async s => {
        const r = await API.DNS.lookup(`${s}.${domain}`, 'A');
        if (r && r.length) results.push({ sub: s, ips: r.map(a => a.data) });
      }));
      State.results.modules.subdomains = results;
      Render.subdomains(results, domain);
      ScanLog.add(`Found ${results.length} live subdomains`, results.length ? 'ok' : 'warn');
    } catch (e) {
      Card.setStatus(State.cards.breaches, 'error', 'Error');
      ScanLog.add(`Subdomain scan failed: ${e.message}`, 'err');
    }
    ScanLog.setProgress(95);

    Render.summaryDomain(domain);
    ScanLog.setProgress(100);
    ScanLog.setText('Domain analysis complete.');
    setTimeout(() => ScanLog.hide(), 1800);
    Storage.addHistory({ mode: 'domain', query: domain, ts: Date.now() });
    Runner.finish();
  },

  async runPhone(phone) {
    State.query = phone;
    State.results = { mode: 'phone', query: phone, startedAt: new Date().toISOString(), modules: {} };

    const grid = Utils.$('#results-grid');
    grid.innerHTML = '';
    State.cards = {};
    const c1 = Card.create('summary', 'Phone Lookup Summary', 'summary');
    const c2 = Card.create('phone', 'Reverse Lookup Services', 'phone');
    grid.appendChild(c1); grid.appendChild(c2);
    State.cards.summary = c1; State.cards.phone = c2;

    Utils.$('#empty-state').classList.add('hidden');
    grid.classList.remove('hidden');
    Utils.$('#export-bar').classList.remove('hidden');

    ScanLog.show();
    ScanLog.clear();
    ScanLog.setText(`Looking up phone ${phone}…`);
    State.scanning = true;
    State.abort = false;

    Card.setStatus(State.cards.phone, 'loading', 'Compiling');
    ScanLog.add('Compiling reverse lookup links…', 'ok');
    try {
      const p = await API.Phone.lookup(phone);
      State.results.modules.phone = p;
      Render.phone(p);
      ScanLog.add('Lookup services ready', 'ok');
    } catch (e) {
      Card.setStatus(State.cards.phone, 'error', 'Error');
      ScanLog.add(`Phone lookup failed: ${e.message}`, 'err');
    }
    ScanLog.setProgress(90);

    Render.summaryPhone(phone);
    ScanLog.setProgress(100);
    ScanLog.setText('Phone lookup complete.');
    setTimeout(() => ScanLog.hide(), 1800);
    Storage.addHistory({ mode: 'phone', query: phone, ts: Date.now() });
    Runner.finish();
  },

  async runIpOrHash(input) {
    State.query = input;
    const isIP = Utils.isValidIP(input);
    const isHash = Utils.isMD5(input) || Utils.isSHA1(input) || Utils.isSHA256(input);
    const mode = isIP ? 'ip' : (isHash ? 'hash' : 'ip');

    State.results = { mode, query: input, startedAt: new Date().toISOString(), modules: {} };

    const grid = Utils.$('#results-grid');
    grid.innerHTML = '';
    State.cards = {};

    if (isIP) {
      const cards = [
        ['summary', 'IP Intelligence Summary', 'summary'],
        ['ip', 'Geolocation & Network', 'ip'],
        ['dns', 'Reverse DNS', 'dns']
      ];
      for (const [id, title, icon] of cards) {
        const c = Card.create(id, title, icon);
        grid.appendChild(c);
        State.cards[id] = c;
      }

      ScanLog.show(); ScanLog.clear();
      ScanLog.setText(`Investigating IP ${input}…`);
      State.scanning = true; State.abort = false;

      Card.setStatus(State.cards.ip, 'loading', 'Geolocating');
      Card.skeleton(State.cards.ip, 4);
      ScanLog.add('Querying geolocation services…', 'ok');
      try {
        const [ipapi, ipinfo] = await Promise.all([API.IP.lookup(input), API.IP.ipinfo(input)]);
        State.results.modules.ip = { ipapi, ipinfo };
        Render.ip(ipapi, ipinfo, input);
        ScanLog.add('Geolocation complete', 'ok');
      } catch (e) {
        Card.setStatus(State.cards.ip, 'error', 'Error');
        ScanLog.add(`IP lookup failed: ${e.message}`, 'err');
      }
      ScanLog.setProgress(50);

      Card.setStatus(State.cards.dns, 'loading', 'Resolving');
      Card.skeleton(State.cards.dns, 2);
      ScanLog.add('Reverse DNS lookup…', 'ok');
      try {
        // Use DNS over HTTPS for PTR record
        const r = await API.DNS.lookup(input, 'PTR');
        State.results.modules.ptr = r;
        Render.ptr(r, input);
        ScanLog.add('Reverse DNS complete', 'ok');
      } catch (e) {
        Card.setStatus(State.cards.dns, 'error', 'Error');
        ScanLog.add(`Reverse DNS failed: ${e.message}`, 'err');
      }
      ScanLog.setProgress(90);

      Render.summaryIP(input);
    } else if (isHash) {
      const cards = [
        ['summary', 'Hash Analysis Summary', 'summary'],
        ['breaches', 'Password Breach Check (HIBP)', 'breach']
      ];
      for (const [id, title, icon] of cards) {
        const c = Card.create(id, title, icon);
        grid.appendChild(c);
        State.cards[id] = c;
      }

      ScanLog.show(); ScanLog.clear();
      ScanLog.setText(`Checking hash ${input.substring(0, 12)}…`);
      State.scanning = true; State.abort = false;

      Card.setStatus(State.cards.breaches, 'loading', 'Checking');
      Card.skeleton(State.cards.breaches, 2);
      ScanLog.add('Checking HIBP password database…', 'ok');

      // HIBP password API expects SHA1 hash; if user provides MD5/SHA256, we note it
      let hashToCheck = input;
      let hashType = 'SHA-1';
      if (Utils.isMD5(input)) { hashType = 'MD5 (cannot check HIBP — needs SHA-1)'; hashToCheck = null; }
      else if (Utils.isSHA256(input)) { hashType = 'SHA-256 (cannot check HIBP — needs SHA-1)'; hashToCheck = null; }

      if (hashToCheck) {
        try {
          const r = await API.Breaches.checkPasswordHash(hashToCheck);
          State.results.modules.passwordCheck = r;
          Render.passwordCheck(r, hashToCheck, hashType);
          ScanLog.add(r.found ? `Pwned ${r.count.toLocaleString()} times` : 'Not found in breaches', r.found ? 'err' : 'ok');
        } catch (e) {
          Card.setStatus(State.cards.breaches, 'error', 'Error');
          ScanLog.add(`Check failed: ${e.message}`, 'err');
        }
      } else {
        Card.setStatus(State.cards.breaches, 'warn', 'Unsupported');
        Card.setBody(State.cards.breaches, [Utils.el('div', { class: 'text-dim text-sm', text: `Provided hash is ${hashType}. HIBP password range API requires SHA-1. Please convert your hash to SHA-1 to check.` })]);
        ScanLog.add(hashType, 'warn');
      }
      ScanLog.setProgress(90);

      Render.summaryHash(input, hashType);
    }

    ScanLog.setProgress(100);
    ScanLog.setText('Analysis complete.');
    setTimeout(() => ScanLog.hide(), 1800);
    Storage.addHistory({ mode, query: input, ts: Date.now() });
    Runner.finish();
  },

  finish() {
    State.scanning = false;
  },

  cancel() {
    State.abort = true;
    State.scanning = false;
    ScanLog.add('Scan cancelled by user', 'warn');
    ScanLog.setText('Cancelled.');
    setTimeout(() => ScanLog.hide(), 1200);
  }
};

/* ============================================================
   Section 9 — Renderers
   ============================================================ */
const Render = {

  validation(v, email) {
    const c = State.cards.validation;
    Card.setStatus(c, v.disify || v.kickbox || v.mailcheck ? 'success' : 'error', v.disify || v.kickbox || v.mailcheck ? 'Complete' : 'Error');
    const nodes = [];

    if (v.disify) {
      nodes.push(Card.row('Email Format', v.disify.format ? Card.pill('Valid', 'success') : Card.pill('Invalid', 'danger')));
      nodes.push(Card.row('Disposable Domain', v.disify.disposable ? Card.pill('Yes', 'danger') : Card.pill('No', 'success')));
      nodes.push(Card.row('Alias / + Address', v.disify.alias ? Card.pill('Yes', 'warn') : Card.pill('No', 'success')));
      nodes.push(Card.row('Domain MX Records', v.disify.dns ? Card.pill('Configured', 'success') : Card.pill('Missing', 'danger')));
    }
    if (v.kickbox) {
      nodes.push(Card.row('Disposable (Kickbox)', v.kickbox.disposable ? Card.pill('Yes', 'danger') : Card.pill('No', 'success')));
    }
    if (v.mailcheck) {
      if (typeof v.mailcheck.valid !== 'undefined') nodes.push(Card.row('Domain Valid', v.mailcheck.valid ? Card.pill('Yes', 'success') : Card.pill('No', 'danger')));
      if (typeof v.mailcheck.disposable !== 'undefined') nodes.push(Card.row('Disposable (Mailcheck)', v.mailcheck.disposable ? Card.pill('Yes', 'danger') : Card.pill('No', 'success')));
      if (v.mailcheck.risk) nodes.push(Card.row('Risk Score', String(v.mailcheck.risk)));
    }
    if (!nodes.length) {
      nodes.push(Utils.el('div', { class: 'card-placeholder', text: 'No validation data returned' }));
    }
    Card.setBody(c, nodes);
  },

  gravatar(exists, profileUrl, avatarUrl, email) {
    const c = State.cards.gravatar;
    Card.setStatus(c, exists ? 'success' : 'empty', exists ? 'Found' : 'Not Found');
    if (exists) {
      const pc = Utils.el('div', { class: 'profile-card' }, [
        Utils.el('div', { class: 'profile-avatar' }, [Utils.el('img', { src: avatarUrl, alt: 'Gravatar', attrs: { referrerpolicy: 'no-referrer' } })]),
        Utils.el('div', { class: 'profile-info' }, [
          Utils.el('div', { class: 'profile-name', text: 'Gravatar Profile Detected' }),
          Utils.el('div', { class: 'profile-meta mono', text: email }),
          Utils.el('a', { class: 'profile-link', href: profileUrl, target: '_blank', rel: 'noopener', html: 'View profile <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M7 7h10v10"/></svg>' })
        ])
      ]);
      Card.setBody(c, [pc]);
    } else {
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: 'No Gravatar profile picture associated with this email.' })]);
    }
  },

  github(gh) {
    const c = State.cards.github;
    if (gh.error) {
      Card.setStatus(c, 'error', 'Error');
      const msg = gh.error === 403 ? 'GitHub API rate limit exceeded (10/min for unauthenticated). Try again later.' : `Error: ${gh.error}`;
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: msg })]);
      return;
    }
    if (!gh.items || !gh.items.length) {
      Card.setStatus(c, 'empty', 'Not Found');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: 'No GitHub accounts found with this email in their public profile.' })]);
      return;
    }
    Card.setStatus(c, 'success', `${gh.items.length} match${gh.items.length > 1 ? 'es' : ''}`);
    const nodes = [];
    for (const u of gh.items.slice(0, 5)) {
      const pc = Utils.el('div', { class: 'profile-card' }, [
        Utils.el('div', { class: 'profile-avatar' }, [Utils.el('img', { src: u.avatar_url, alt: u.login, attrs: { referrerpolicy: 'no-referrer' } })]),
        Utils.el('div', { class: 'profile-info' }, [
          Utils.el('div', { class: 'profile-name', text: u.login }),
          Utils.el('div', { class: 'profile-meta mono', text: u.html_url }),
          Utils.el('a', { class: 'profile-link', href: u.html_url, target: '_blank', rel: 'noopener', html: 'View profile <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M7 7h10v10"/></svg>' })
        ])
      ]);
      nodes.push(pc);
    }
    Card.setBody(c, nodes);
  },

  githubUser(u) {
    const c = State.cards.github;
    if (u.error || !u.login) {
      Card.setStatus(c, 'empty', 'Not Found');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: u.message || 'No GitHub user with this username.' })]);
      return;
    }
    Card.setStatus(c, 'success', 'Found');
    const pc = Utils.el('div', { class: 'profile-card' }, [
      Utils.el('div', { class: 'profile-avatar' }, [Utils.el('img', { src: u.avatar_url, alt: u.login, attrs: { referrerpolicy: 'no-referrer' } })]),
      Utils.el('div', { class: 'profile-info' }, [
        Utils.el('div', { class: 'profile-name', text: u.name || u.login }),
        Utils.el('div', { class: 'profile-meta mono', text: u.html_url }),
        u.bio && Utils.el('div', { class: 'profile-meta', text: u.bio }),
        Utils.el('a', { class: 'profile-link', href: u.html_url, target: '_blank', rel: 'noopener', html: 'View profile <svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M7 17L17 7"/><path d="M7 7h10v10"/></svg>' })
      ])
    ]);
    const nodes = [pc];
    if (u.company) nodes.push(Card.row('Company', u.company));
    if (u.location) nodes.push(Card.row('Location', u.location));
    if (u.email) nodes.push(Card.row('Public Email', u.email));
    if (u.blog) nodes.push(Card.row('Website', u.blog));
    if (u.twitter_username) nodes.push(Card.row('Twitter', '@' + u.twitter_username));
    nodes.push(Card.row('Public Repos', String(u.public_repos || 0)));
    nodes.push(Card.row('Followers', String(u.followers || 0)));
    nodes.push(Card.row('Following', String(u.following || 0)));
    if (u.created_at) nodes.push(Card.row('Account Created', Utils.formatDate(u.created_at)));
    Card.setBody(c, nodes);
  },

  breaches(b, email) {
    const c = State.cards.breaches;
    if (b.needsKey) {
      Card.setStatus(c, 'warn', 'External');
      const link = Utils.el('a', { class: 'profile-link', href: b.url, target: '_blank', rel: 'noopener', text: 'Open HaveIBeenPwned →' });
      const node = Utils.el('div', {}, [
        Utils.el('div', { class: 'text-sm text-dim', text: 'Direct breach queries require a free HIBP API key. Add one in Settings to enable in-app results, or check directly:' }),
        Utils.el('div', { class: 'mt-3' }, [link])
      ]);
      Card.setBody(c, [node]);
      return;
    }
    if (b.error) {
      Card.setStatus(c, 'error', 'Error');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: b.error })]);
      return;
    }
    if (!b.breaches || !b.breaches.length) {
      Card.setStatus(c, 'success', 'Clean');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: 'No breaches found. This email does not appear in the HIBP database.' })]);
      return;
    }
    Card.setStatus(c, 'error', `${b.breaches.length} breach${b.breaches.length > 1 ? 'es' : ''}`);
    const nodes = [];
    for (const br of b.breaches) {
      const item = Utils.el('div', { class: 'breach-item' }, [
        Utils.el('div', { class: 'breach-item-head' }, [
          Utils.el('div', { class: 'breach-name', text: br.Name || br.Title }),
          Utils.el('div', { class: 'breach-date', text: br.BreachDate ? Utils.formatDate(br.BreachDate) : '' })
        ]),
        Utils.el('div', { class: 'breach-desc', html: br.Description ? Utils.escapeHTML(br.Description).replace(/<[^>]+>/g, '') : 'No description available.' }),
        Utils.el('div', { class: 'breach-data-types' }, (br.DataClasses || []).map(dc => Card.pill(dc, 'danger')))
      ]);
      nodes.push(item);
    }
    Card.setBody(c, nodes);
  },

  pgp(p) {
    const c = State.cards.pgp;
    if (p.error) {
      Card.setStatus(c, 'error', 'Error');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: p.error })]);
      return;
    }
    if (!p.found) {
      Card.setStatus(c, 'empty', 'Not Found');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: 'No PGP public key found on keys.openpgp.org for this email.' })]);
      return;
    }
    Card.setStatus(c, 'success', 'Found');
    const key = p.key.length > 800 ? p.key.substring(0, 800) + '\n…(truncated)' : p.key;
    const pre = Utils.el('pre', {
      style: { background: 'rgba(0,0,0,0.3)', padding: '12px', borderRadius: '10px', fontSize: '0.72rem', fontFamily: 'var(--font-mono)', overflow: 'auto', maxHeight: '300px', whiteSpace: 'pre-wrap', wordBreak: 'break-all', color: 'var(--accent-green)' },
      text: key
    });
    const dl = Utils.el('button', {
      class: 'icon-btn',
      style: { width: 'auto', padding: '8px 14px', gap: '6px', marginTop: '8px' },
      html: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg><span style="font-size:0.78rem;">Download .asc</span>',
      onclick: () => Utils.download('public-key.asc', p.key, 'application/pgp-keys')
    });
    Card.setBody(c, [pre, dl]);
  },

  dns(dns, domain) {
    const c = State.cards.dns;
    Card.setStatus(c, 'success', 'Resolved');
    const types = ['A', 'AAAA', 'MX', 'TXT', 'NS', 'CAA', 'SOA'];
    const nodes = [];
    let totalRecords = 0;
    for (const t of types) {
      const recs = dns[t];
      if (recs == null) continue;
      if (!recs.length) {
        nodes.push(Card.row(t, Card.pill('None', '')));
        continue;
      }
      totalRecords += recs.length;
      const cell = Utils.el('div', { class: 'flex-col gap-1' }, recs.map(r => Utils.el('div', { class: 'mono text-xs wrap', text: r.data })));
      nodes.push(Card.row(`${t} (${recs.length})`, cell));
    }
    nodes.unshift(Card.row('Domain', domain));
    nodes.unshift(Card.row('Total Records', String(totalRecords)));
    Card.setBody(c, nodes);
  },

  domainValidation(mc, domain) {
    const c = State.cards.validation;
    Card.setStatus(c, 'success', 'Complete');
    const nodes = [];
    if (mc.error) {
      Card.setStatus(c, 'error', 'Error');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: mc.error })]);
      return;
    }
    if (mc.data) mc = mc.data;
    if (typeof mc.valid !== 'undefined') nodes.push(Card.row('Domain Valid', mc.valid ? Card.pill('Yes', 'success') : Card.pill('No', 'danger')));
    if (typeof mc.disposable !== 'undefined') nodes.push(Card.row('Disposable', mc.disposable ? Card.pill('Yes', 'danger') : Card.pill('No', 'success')));
    if (mc.risk) nodes.push(Card.row('Risk Level', mc.risk));
    if (mc.mx) nodes.push(Card.row('MX Records', Array.isArray(mc.mx) ? mc.mx.join(', ') : String(mc.mx)));
    if (mx_text(mc)) nodes.push(Card.row('Mail Server Info', mc.text || '—'));
    Card.setBody(c, nodes.length ? nodes : [Utils.el('div', { class: 'card-placeholder', text: 'No data returned' })]);

    function mx_text(d) { return d && d.text; }
  },

  subdomains(results, domain) {
    const c = State.cards.breaches;
    Card.setStatus(c, results.length ? 'success' : 'empty', results.length ? `${results.length} found` : 'None');
    if (!results.length) {
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: 'No common subdomains resolved for this domain.' })]);
      return;
    }
    const nodes = [];
    for (const r of results) {
      const link = Utils.el('a', {
        class: 'profile-link',
        href: `https://${r.sub}.${domain}`,
        target: '_blank',
        rel: 'noopener',
        text: `${r.sub}.${domain}`
      });
      const ips = Utils.el('div', { class: 'mono text-xs wrap', text: r.ips.join(', ') });
      nodes.push(Card.row(link, ips));
    }
    Card.setBody(c, nodes);
  },

  usernames(us) {
    const c = State.cards.usernames;
    const found = us.filter(u => u.found);
    Card.setStatus(c, found.length ? 'success' : 'empty', found.length ? `${found.length} found` : 'None');
    const grid = Utils.el('div', { class: 'platform-grid' });
    for (const u of us) {
      const item = Utils.el('a', {
        class: `platform-item ${u.found ? 'found' : ''}`,
        href: u.url(u.username),
        target: '_blank',
        rel: 'noopener',
        attrs: { 'data-platform': u.name }
      }, [
        Utils.el('div', { class: 'platform-icon', html: `<img src="https://icons.duckduckgo.com/ip3/${getPlatformDomain(u.name)}.ico" alt="" onerror="this.style.display='none'">` }),
        Utils.el('div', { class: 'platform-name', text: u.name })
      ]);
      grid.appendChild(item);
    }
    const summary = Utils.el('div', { class: 'text-xs text-dim', text: `Probed ${us.length} platforms. Found on ${found.length}. Click any tile to open the profile.` });
    Card.setBody(c, [summary, grid]);

    function getPlatformDomain(name) {
      const map = {
        'GitHub': 'github.com',
        'Twitter/X': 'twitter.com',
        'Instagram': 'instagram.com',
        'Facebook': 'facebook.com',
        'TikTok': 'tiktok.com',
        'YouTube': 'youtube.com',
        'Reddit': 'reddit.com',
        'Twitch': 'twitch.tv',
        'Telegram': 'telegram.org',
        'Medium': 'medium.com',
        'Pinterest': 'pinterest.com',
        'Tumblr': 'tumblr.com',
        'SoundCloud': 'soundcloud.com',
        'Spotify': 'spotify.com',
        'Vimeo': 'vimeo.com',
        'DeviantArt': 'deviantart.com',
        'Steam': 'steamcommunity.com',
        'GitLab': 'gitlab.com',
        'Bitbucket': 'bitbucket.org',
        'Stack Overflow': 'stackoverflow.com',
        'Hacker News': 'ycombinator.com',
        'Product Hunt': 'producthunt.com',
        'Patreon': 'patreon.com',
        'Behance': 'behance.net',
        'Dribbble': 'dribbble.com',
        'Mastodon': 'mastodon.social',
        'Keybase': 'keybase.io',
        'Quora': 'quora.com',
        'Flickr': 'flickr.com',
        'WordPress': 'wordpress.com',
        'Blogger': 'blogspot.com',
        'Snapchat': 'snapchat.com',
        'Discord': 'discord.com',
        'PayPal': 'paypal.com',
        'LinkedIn': 'linkedin.com',
        'About.me': 'about.me',
        'Gravatar': 'gravatar.com',
        'HackTheBox': 'hackthebox.com',
        'TryHackMe': 'tryhackme.com'
      };
      return map[name] || 'example.com';
    }
  },

  phone(p) {
    const c = State.cards.phone;
    Card.setStatus(c, 'success', 'Ready');
    const nodes = [];
    nodes.push(Card.row('Input', p.input));
    nodes.push(Card.row('Cleaned', p.cleaned, { mono: true }));
    nodes.push(Utils.el('div', { class: 'text-xs text-dim mt-2', text: 'Open this number in free reverse lookup services:' }));
    for (const [name, url] of Object.entries(p.links)) {
      const a = Utils.el('a', {
        class: 'profile-link',
        href: url,
        target: '_blank',
        rel: 'noopener',
        text: `${name} →`
      });
      nodes.push(a);
    }
    Card.setBody(c, nodes);
  },

  ip(ipapi, ipinfo, ip) {
    const c = State.cards.ip;
    Card.setStatus(c, 'success', 'Located');
    const nodes = [];
    const data = ipinfo || ipapi || {};
    if (ipinfo) {
      nodes.push(Card.row('IP', ipinfo.ip || ip));
      if (ipinfo.hostname) nodes.push(Card.row('Hostname', ipinfo.hostname, { mono: true }));
      if (ipinfo.city) nodes.push(Card.row('City', ipinfo.city));
      if (ipinfo.region) nodes.push(Card.row('Region', ipinfo.region));
      if (ipinfo.country) nodes.push(Card.row('Country', ipinfo.country));
      if (ipinfo.loc) nodes.push(Card.row('Coordinates', ipinfo.loc, { mono: true }));
      if (ipinfo.org) nodes.push(Card.row('ISP / Org', ipinfo.org));
      if (ipinfo.postal) nodes.push(Card.row('Postal', ipinfo.postal));
      if (ipinfo.timezone) nodes.push(Card.row('Timezone', ipinfo.timezone));
    }
    if (ipapi && !ipinfo) {
      nodes.push(Card.row('IP', ipapi.ip || ip));
      if (ipapi.city) nodes.push(Card.row('City', ipapi.city));
      if (ipapi.region) nodes.push(Card.row('Region', ipapi.region));
      if (ipapi.country_name) nodes.push(Card.row('Country', ipapi.country_name));
      if (ipapi.org) nodes.push(Card.row('ISP', ipapi.org));
      if (ipapi.asn) nodes.push(Card.row('ASN', ipapi.asn));
      if (ipapi.timezone) nodes.push(Card.row('Timezone', ipapi.timezone));
    }
    if (ipapi && ipapi.error) {
      nodes.push(Utils.el('div', { class: 'text-dim text-sm', text: `ipapi.co: ${ipapi.reason || ipapi.error}` }));
    }
    Card.setBody(c, nodes);
  },

  ptr(r, ip) {
    const c = State.cards.dns;
    Card.setStatus(c, r && r.length ? 'success' : 'empty', r && r.length ? 'Found' : 'None');
    if (!r || !r.length) {
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: 'No PTR (reverse DNS) record found for this IP.' })]);
      return;
    }
    const nodes = [Card.row('IP', ip)];
    for (const a of r) {
      nodes.push(Card.row('PTR', a.data, { mono: true }));
    }
    Card.setBody(c, nodes);
  },

  passwordCheck(r, hash, hashType) {
    const c = State.cards.breaches;
    if (r.error) {
      Card.setStatus(c, 'error', 'Error');
      Card.setBody(c, [Utils.el('div', { class: 'card-placeholder', text: r.error })]);
      return;
    }
    Card.setStatus(c, r.found ? 'error' : 'success', r.found ? 'Pwned' : 'Safe');
    const nodes = [];
    nodes.push(Card.row('Hash Type', hashType));
    nodes.push(Card.row('Hash (first 12)', hash.substring(0, 12) + '…', { mono: true }));
    if (r.found) {
      nodes.push(Card.row('Found in Breaches', Card.pill(r.count.toLocaleString() + ' occurrences', 'danger')));
      nodes.push(Utils.el('div', { class: 'text-sm', style: { color: 'var(--accent-red)', marginTop: '8px' }, text: 'This password has been exposed in data breaches. Do not use it.' }));
    } else {
      nodes.push(Card.row('Breach Status', Card.pill('Not found', 'success')));
      nodes.push(Utils.el('div', { class: 'text-sm text-dim', style: { marginTop: '8px' }, text: 'This hash was not found in the HIBP password database. This does not guarantee the password is secure.' }));
    }
    Card.setBody(c, nodes);
  },

  summary(email) {
    const c = State.cards.summary;
    const m = State.results.modules;
    const domain = email.split('@')[1];
    const parts = [];
    parts.push({ label: 'Target Email', value: email });
    parts.push({ label: 'Local Part', value: email.split('@')[0] });
    parts.push({ label: 'Domain', value: domain });

    let risk = 0;
    let findings = [];

    if (m.validation && m.validation.disify) {
      if (m.validation.disify.disposable) { risk += 30; findings.push('Disposable email domain'); }
      if (!m.validation.disify.format) { risk += 50; findings.push('Invalid format'); }
      if (!m.validation.disify.dns) { risk += 20; findings.push('No MX records'); }
    }
    if (m.gravatar && m.gravatar.exists) { findings.push('Gravatar profile exists'); }
    if (m.github && m.github.items && m.github.items.length) { findings.push(`${m.github.items.length} GitHub match(es)`); }
    if (m.breaches && m.breaches.breaches && m.breaches.breaches.length) {
      risk += Math.min(40, m.breaches.breaches.length * 8);
      findings.push(`${m.breaches.breaches.length} data breach(es)`);
    }
    if (m.pgp && m.pgp.found) { findings.push('PGP key published'); }
    if (m.usernames) {
      const f = m.usernames.filter(u => u.found).length;
      if (f) findings.push(`${f} platform username match(es)`);
    }
    if (m.dns) {
      const mx = (m.dns.MX || []).length;
      if (mx) findings.push(`${mx} MX record(s)`);
    }

    const riskLabel = risk >= 60 ? 'High' : risk >= 30 ? 'Medium' : risk >= 10 ? 'Low' : 'Minimal';
    const riskColor = risk >= 60 ? 'danger' : risk >= 30 ? 'warn' : 'success';

    Card.setStatus(c, 'success', 'Complete');
    const nodes = [];
    for (const p of parts) nodes.push(Card.row(p.label, p.value, p.mono ? { mono: true } : {}));
    nodes.push(Card.row('Risk Assessment', Card.pill(`${riskLabel} (${risk}/100)`, riskColor)));
    nodes.push(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Key findings:' }));
    if (findings.length) {
      for (const f of findings) nodes.push(Utils.el('div', { class: 'text-sm', style: { padding: '4px 0', color: 'var(--text)' }, html: `• ${Utils.escapeHTML(f)}` }));
    } else {
      nodes.push(Utils.el('div', { class: 'text-sm text-dim', text: 'No significant findings.' }));
    }
    Card.setBody(c, nodes);
  },

  summaryUsername(username) {
    const c = State.cards.summary;
    const m = State.results.modules;
    const found = m.usernames ? m.usernames.filter(u => u.found) : [];
    Card.setStatus(c, 'success', 'Complete');
    const nodes = [
      Card.row('Username', username),
      Card.row('Platforms Probed', String(PLATFORMS.length)),
      Card.row('Profiles Found', Card.pill(String(found.length), found.length >= 5 ? 'danger' : found.length ? 'warn' : 'success'))
    ];
    if (found.length) {
      nodes.push(Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Found on:' }));
      for (const f of found.slice(0, 10)) {
        nodes.push(Utils.el('div', { class: 'text-sm', style: { padding: '2px 0' }, html: `• <a href="${f.url(f.username)}" target="_blank" rel="noopener" style="color:var(--accent-cyan);">${Utils.escapeHTML(f.name)}</a>` }));
      }
      if (found.length > 10) {
        nodes.push(Utils.el('div', { class: 'text-xs text-dim', text: `…and ${found.length - 10} more (see card)` }));
      }
    }
    Card.setBody(c, nodes);
  },

  summaryDomain(domain) {
    const c = State.cards.summary;
    const m = State.results.modules;
    const dns = m.dns || {};
    const subdomains = m.subdomains || [];
    Card.setStatus(c, 'success', 'Complete');
    const nodes = [
      Card.row('Domain', domain),
      Card.row('A Records', String((dns.A || []).length)),
      Card.row('MX Records', String((dns.MX || []).length)),
      Card.row('NS Records', String((dns.NS || []).length)),
      Card.row('TXT Records', String((dns.TXT || []).length)),
      Card.row('Live Subdomains', String(subdomains.length))
    ];
    Card.setBody(c, nodes);
  },

  summaryPhone(phone) {
    const c = State.cards.summary;
    Card.setStatus(c, 'success', 'Complete');
    Card.setBody(c, [
      Card.row('Phone', phone),
      Card.row('Status', Card.pill('Lookup services ready', 'info')),
      Utils.el('div', { class: 'text-xs text-dim mt-3', text: 'Note: Phone number OSINT typically requires paid services for full reverse lookup. Use the services listed in the card to investigate further.' })
    ]);
  },

  summaryIP(ip) {
    const c = State.cards.summary;
    const m = State.results.modules;
    const info = m.ip && (m.ip.ipinfo || m.ip.ipapi) || {};
    Card.setStatus(c, 'success', 'Complete');
    const nodes = [Card.row('IP Address', ip)];
    if (info.country || info.country_name) nodes.push(Card.row('Country', info.country || info.country_name));
    if (info.org) nodes.push(Card.row('ISP', info.org));
    if (info.hostname) nodes.push(Card.row('Hostname', info.hostname, { mono: true }));
    Card.setBody(c, nodes);
  },

  summaryHash(hash, hashType) {
    const c = State.cards.summary;
    const m = State.results.modules;
    Card.setStatus(c, 'success', 'Complete');
    const nodes = [
      Card.row('Hash', hash.substring(0, 24) + (hash.length > 24 ? '…' : ''), { mono: true }),
      Card.row('Hash Type', hashType),
      Card.row('Length', String(hash.length) + ' chars')
    ];
    if (m.passwordCheck) {
      if (m.passwordCheck.found) {
        nodes.push(Card.row('Breach Status', Card.pill('Pwned', 'danger')));
        nodes.push(Card.row('Occurrence Count', String(m.passwordCheck.count.toLocaleString())));
      } else {
        nodes.push(Card.row('Breach Status', Card.pill('Not found', 'success')));
      }
    }
    Card.setBody(c, nodes);
  },

  /* ---- Infostealer logs renderer ---- */
  infostealer(is, email) {
    const c = State.cards.infostealer;
    const hasHits = is.hits && is.hits.length;
    Card.setStatus(c, hasHits ? 'error' : 'warn', hasHits ? `${is.hits.length} hit(s)` : 'No direct hits');

    const nodes = [];

    if (hasHits) {
      nodes.push(Utils.el('div', { class: 'text-sm', style: { color: 'var(--accent-red)', marginBottom: '8px' }, text: `${is.hits.length} reference(s) found in public code/paste dumps:` }));
      for (const h of is.hits.slice(0, 5)) {
        const item = Utils.el('div', { class: 'stealer-item' }, [
          Utils.el('div', { class: 'icon', html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>' }),
          Utils.el('div', { class: 'info' }, [
            Utils.el('div', { class: 'name', text: h.name }),
            Utils.el('div', { class: 'meta', text: h.type })
          ]),
          Utils.el('a', { class: 'profile-link', href: h.url, target: '_blank', rel: 'noopener', text: 'View →' })
        ]);
        nodes.push(item);
      }
    }

    // External lookup sources
    nodes.push(Utils.el('div', { class: 'text-xs text-dim', style: { marginTop: '12px', marginBottom: '8px' }, text: 'Manual verification sources (infostealer log databases):' }));
    for (const src of is.sources) {
      if (src.type === 'error') continue;
      const item = Utils.el('a', {
        class: 'stealer-item',
        href: src.url,
        target: '_blank',
        rel: 'noopener',
        style: { textDecoration: 'none', color: 'inherit' }
      }, [
        Utils.el('div', { class: 'icon', style: { background: 'rgba(0, 212, 255, 0.12)', color: 'var(--accent-cyan)' }, html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>' }),
        Utils.el('div', { class: 'info' }, [
          Utils.el('div', { class: 'name', text: src.name }),
          Utils.el('div', { class: 'meta', text: src.note || src.type || '' })
        ])
      ]);
      nodes.push(item);
    }
    Card.setBody(c, nodes);
  },

  /* ---- AI Synthesis renderer (typewriter effect) ---- */
  async aiSynthesis(text) {
    const c = State.cards.ai;
    if (!text) {
      Card.setStatus(c, 'warn', 'Fallback');
      Card.setBody(c, [
        Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> AI synthesis unavailable — using fallback summary' }),
        Utils.el('div', { class: 'ai-content text-dim', text: 'The LLM service is currently busy. All structured intelligence is available in the cards below. The algorithmic risk assessment above provides the key findings.' })
      ]);
      return;
    }
    Card.setStatus(c, 'success', 'AI Complete');
    Card.setBody(c, [
      Utils.el('div', { class: 'ai-badge', html: '<span class="dot"></span> AI-synthesized digital profile breakdown' }),
      Utils.el('div', { class: 'ai-content', id: 'ai-content-text' })
    ]);
    // Typewriter effect
    const target = Utils.$('#ai-content-text');
    const words = text.split(/(\s+)/);
    let i = 0;
    return new Promise(resolve => {
      const typeNext = () => {
        if (i >= words.length) {
          target.innerHTML = text;
          resolve();
          return;
        }
        target.innerHTML = Utils.escapeHTML(words.slice(0, i + 1).join('')) + '<span class="cursor"></span>';
        i++;
        setTimeout(typeNext, 30);
      };
      typeNext();
    });
  },

  /* ---- Risk Assessment renderer ---- */
  risk(risk) {
    const c = State.cards.risk;
    Card.setStatus(c, risk.level === 'high' ? 'error' : risk.level === 'medium' ? 'warn' : 'success', risk.levelLabel);

    const circumference = 2 * Math.PI * 38;
    const offset = circumference - (risk.score / 100) * circumference;
    const strokeColor = risk.level === 'high' ? '#ef4444' : risk.level === 'medium' ? '#fbbf24' : '#22d3a6';

    const gauge = Utils.el('div', { class: 'risk-gauge' }, [
      Utils.el('div', { class: 'risk-circle' }, [
        Utils.el('svg', { width: 88, height: 88, viewBox: '0 0 88 88', html: `
          <circle class="bg-ring" cx="44" cy="44" r="38" fill="none" stroke-width="6"/>
          <circle class="fg-ring" cx="44" cy="44" r="38" fill="none" stroke="${strokeColor}" stroke-width="6"
                  stroke-dasharray="${circumference}" stroke-dashoffset="${offset}" stroke-linecap="round"/>
        ` }),
        Utils.el('div', { class: 'risk-score-text', style: { color: strokeColor }, html: `${risk.score}<div class="risk-level-text">${risk.levelLabel}</div>` })
      ]),
      Utils.el('div', { class: 'risk-info' }, [
        Utils.el('div', { class: `risk-level-badge ${risk.level}`, text: risk.levelLabel + ' Risk' }),
        Utils.el('div', { class: 'risk-reasoning', id: 'risk-reasoning-text', text: 'Analyzing factors…' })
      ])
    ]);

    const factors = Utils.el('div', { class: 'risk-factors' });
    for (const f of risk.factors.slice(0, 8)) {
      factors.appendChild(Utils.el('div', { class: 'risk-factor' }, [
        Utils.el('div', { class: 'label', text: f.label }),
        Utils.el('div', { class: `impact ${f.type}`, text: (f.impact > 0 ? '+' : '') + f.impact })
      ]));
    }

    Card.setBody(c, [gauge, factors]);
  },

  /* ---- Risk reasoning (LLM) renderer ---- */
  riskReasoning(reasoning) {
    const el = Utils.$('#risk-reasoning-text');
    if (el && reasoning) {
      el.textContent = reasoning;
    }
  }
};

/* ============================================================
   Section 10 — UI Controller
   ============================================================ */
const UI = {
  init() {
    State.settings = Storage.getSettings();

    // Mode tabs
    Utils.$$('.mode-tab').forEach(tab => {
      tab.addEventListener('click', () => this.setMode(tab.dataset.mode));
    });

    // Search form
    Utils.$('#search-form').addEventListener('submit', e => {
      e.preventDefault();
      this.runSearch();
    });

    // Cancel scan
    Utils.$('#btn-cancel-scan').addEventListener('click', () => Runner.cancel());

    // Header buttons
    Utils.$('#btn-settings').addEventListener('click', () => Drawer.openSettings());
    Utils.$('#btn-history').addEventListener('click', () => Drawer.openHistory());
    Utils.$('#btn-api').addEventListener('click', () => Drawer.openAPI());
    Utils.$('#btn-close-drawer').addEventListener('click', () => Drawer.close());
    Utils.$('#drawer-backdrop').addEventListener('click', () => Drawer.close());

    // Export buttons
    Utils.$('[data-export="json"]').addEventListener('click', () => this.exportJSON());
    Utils.$('[data-export="csv"]').addEventListener('click', () => this.exportCSV());
    Utils.$('[data-export="print"]').addEventListener('click', () => window.print());
    Utils.$('[data-export="clear"]').addEventListener('click', () => this.clearResults());

    // Footer links
    Utils.$('#link-about').addEventListener('click', e => { e.preventDefault(); Drawer.openAbout(); });
    Utils.$('#link-apis').addEventListener('click', e => { e.preventDefault(); Drawer.openAPIs(); });

    // URL query param for shortcuts
    const params = new URLSearchParams(location.search);
    const action = params.get('action');
    if (action && ['email', 'username', 'domain', 'phone', 'ip'].includes(action)) {
      this.setMode(action);
    }

    // Focus input
    Utils.$('#search-input').focus();

    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js').catch(() => {});
    }
  },

  setMode(mode) {
    State.mode = mode;
    Utils.$$('.mode-tab').forEach(t => {
      const active = t.dataset.mode === mode;
      t.classList.toggle('active', active);
      t.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    const input = Utils.$('#search-input');
    const placeholders = {
      email: 'Enter an email address to investigate…',
      username: 'Enter a username to search across 100+ platforms…',
      domain: 'Enter a domain (e.g. example.com) to analyze…',
      phone: 'Enter a phone number (e.g. +14155551234)…',
      ip: 'Enter an IP address or password hash (MD5/SHA1/SHA256)…'
    };
    input.placeholder = placeholders[mode] || placeholders.email;
    input.value = '';
    input.focus();
  },

  runSearch() {
    const input = Utils.$('#search-input');
    const q = input.value.trim();
    if (!q) {
      Toast.show('Please enter a value to search', 'error');
      return;
    }
    if (State.scanning) {
      Toast.show('A scan is already running. Please wait or cancel it.', 'info');
      return;
    }

    // Validate per mode
    let validated = q;
    switch (State.mode) {
      case 'email':
        if (!Utils.isValidEmail(q)) { Toast.show('Invalid email format', 'error'); return; }
        Runner.runEmail(q);
        break;
      case 'username':
        validated = q.replace(/^@/, '').trim();
        if (!/^[a-zA-Z0-9._-]{2,40}$/.test(validated)) { Toast.show('Invalid username (allowed: letters, digits, . _ -)', 'error'); return; }
        Runner.runUsername(validated);
        break;
      case 'domain':
        const d = q.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^www\./, '');
        if (!Utils.isValidDomain(d)) { Toast.show('Invalid domain format', 'error'); return; }
        Runner.runDomain(d);
        break;
      case 'phone':
        if (!Utils.isValidPhone(q)) { Toast.show('Invalid phone number', 'error'); return; }
        Runner.runPhone(q);
        break;
      case 'ip':
        if (!Utils.isValidIP(q) && !Utils.isMD5(q) && !Utils.isSHA1(q) && !Utils.isSHA256(q)) {
          Toast.show('Enter a valid IP address or hash (MD5/SHA1/SHA256)', 'error');
          return;
        }
        Runner.runIpOrHash(q);
        break;
    }
  },

  clearResults() {
    Utils.$('#results-grid').innerHTML = '';
    Utils.$('#results-grid').classList.add('hidden');
    Utils.$('#empty-state').classList.remove('hidden');
    Utils.$('#export-bar').classList.add('hidden');
    ScanLog.hide();
    Stream.hide();
    State.results = null;
    State.cards = {};
    Utils.$('#search-input').value = '';
    Utils.$('#search-input').focus();
  },

  exportJSON() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    const data = { ...State.results, exportedAt: new Date().toISOString(), tool: 'GhostyEye OSINT v2.0 by REI', deployedAt: 'ghostyeye.dpdns' };
    Utils.download(`ghostyeye-${State.results.mode}-${State.results.query.replace(/[^a-z0-9]/gi, '_')}-${Date.now()}.json`, JSON.stringify(data, null, 2), 'application/json');
    Toast.show('JSON exported', 'success');
  },

  exportCSV() {
    if (!State.results) { Toast.show('No results to export', 'info'); return; }
    const rows = [];
    const flatten = (obj, prefix = '') => {
      for (const [k, v] of Object.entries(obj)) {
        const key = prefix ? `${prefix}.${k}` : k;
        if (v && typeof v === 'object' && !Array.isArray(v)) flatten(v, key);
        else if (Array.isArray(v)) rows.push({ module: key, value: JSON.stringify(v) });
        else rows.push({ module: key, value: v });
      }
    };
    flatten(State.results);
    Utils.download(`ghostyeye-${State.results.mode}-${State.results.query.replace(/[^a-z0-9]/gi, '_')}-${Date.now()}.csv`, Utils.toCSV(rows), 'text/csv');
    Toast.show('CSV exported', 'success');
  }
};

/* ============================================================
   Section 11 — Drawer (Settings / History / About)
   ============================================================ */
const Drawer = {
  open(title, contentNode) {
    Utils.$('#drawer-title').textContent = title;
    const body = Utils.$('#drawer-body');
    body.innerHTML = '';
    body.appendChild(contentNode);
    Utils.$('#drawer').classList.add('open');
    Utils.$('#drawer').setAttribute('aria-hidden', 'false');
    Utils.$('#drawer-backdrop').classList.add('open');
  },

  close() {
    Utils.$('#drawer').classList.remove('open');
    Utils.$('#drawer').setAttribute('aria-hidden', 'true');
    Utils.$('#drawer-backdrop').classList.remove('open');
  },

  openSettings() {
    const s = Storage.getSettings();
    const wrap = Utils.el('div', {}, []);

    // API Keys section
    const sec1 = Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'API Keys (Optional)' }),
      Utils.el('div', { class: 'drawer-field' }, [
        Utils.el('label', { text: 'Have I Been Pwned API Key' }),
        Utils.el('input', { type: 'password', value: s.hibpApiKey, attrs: { 'data-key': 'hibpApiKey' }, placeholder: 'hibp-api-key…' }),
        Utils.el('div', { class: 'hint', html: 'Get a free key at <a href="https://haveibeenpwned.com/API/Key" target="_blank" rel="noopener">haveibeenpwned.com/API/Key</a>. Required for in-app breach checks.' })
      ]),
      Utils.el('div', { class: 'drawer-field' }, [
        Utils.el('label', { text: 'Hunter.io API Key' }),
        Utils.el('input', { type: 'password', value: s.hunterApiKey, attrs: { 'data-key': 'hunterApiKey' }, placeholder: 'hunter-api-key…' }),
        Utils.el('div', { class: 'hint', text: 'For email finder / verifier enrichment (free tier: 25 searches/month).' })
      ])
    ]);

    // Modules section
    const sec2 = Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Scan Modules' })
    ]);
    const toggles = [
      ['enableGravatar', 'Gravatar Profile Lookup'],
      ['enableGitHub', 'GitHub Account Search'],
      ['enableBreachCheck', 'Data Breach Check (HIBP)'],
      ['enableUsernames', 'Cross-Platform Username Search'],
      ['enablePGP', 'PGP Key Lookup'],
      ['enableDNS', 'DNS Records Lookup']
    ];
    for (const [key, label] of toggles) {
      const tg = Utils.el('div', { class: 'toggle' }, [
        Utils.el('div', { class: 'toggle-label', text: label }),
        Utils.el('div', { class: `toggle-switch ${s[key] ? 'on' : ''}`, attrs: { 'data-toggle': key } })
      ]);
      sec2.appendChild(tg);
    }

    // Storage info
    const sec3 = Utils.el('div', { class: 'drawer-section' }, [
      Utils.el('h4', { text: 'Data & Privacy' }),
      Utils.el('div', { class: 'text-xs text-dim', text: 'All settings and search history are stored locally in your browser. No data leaves your device except API calls to public OSINT services.' }),
      Utils.el('button', {
        class: 'icon-btn',
        style: { width: 'auto', padding: '10px 14px', marginTop: '12px', gap: '8px' },
        html: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg><span style="font-size:0.78rem;">Clear all history</span>',
        onclick: () => {
          if (confirm('Clear all search history? This cannot be undone.')) {
            Storage.clearHistory();
            Toast.show('History cleared', 'success');
          }
        }
      })
    ]);

    wrap.appendChild(sec1);
    wrap.appendChild(sec2);
    wrap.appendChild(sec3);

    // Wire up toggles
    wrap.addEventListener('click', e => {
      const t = e.target.closest('[data-toggle]');
      if (t) {
        const key = t.dataset.toggle;
        s[key] = !s[key];
        t.classList.toggle('on', s[key]);
        Storage.saveSettings(s);
        State.settings = s;
      }
    });
    // Wire up inputs
    wrap.addEventListener('input', e => {
      const inp = e.target.closest('[data-key]');
      if (inp) {
        const key = inp.dataset.key;
        s[key] = inp.value.trim();
        Storage.saveSettings(s);
        State.settings = s;
      }
    });

    this.open('Settings', wrap);
  },

  openHistory() {
    const hist = Storage.getHistory();
    const wrap = Utils.el('div', {});
    if (!hist.length) {
      wrap.appendChild(Utils.el('div', { class: 'text-dim text-sm', style: { padding: '24px 0', textAlign: 'center' }, text: 'No search history yet. Run an investigation to populate this list.' }));
    } else {
      const list = Utils.el('div', { class: 'history-list' });
      for (const h of hist) {
        const item = Utils.el('div', { class: 'history-item' }, [
          Utils.el('div', {}, [
            Utils.el('div', { class: 'history-query', text: h.query }),
            Utils.el('div', { class: 'history-meta', text: Utils.formatDateTime(h.ts) })
          ]),
          Utils.el('div', { class: 'history-mode', text: h.mode })
        ]);
        item.addEventListener('click', () => {
          UI.setMode(h.mode);
          Utils.$('#search-input').value = h.query;
          this.close();
          UI.runSearch();
        });
        list.appendChild(item);
      }
      wrap.appendChild(list);
      wrap.appendChild(Utils.el('button', {
        class: 'icon-btn',
        style: { width: 'auto', padding: '10px 14px', marginTop: '12px', gap: '8px' },
        html: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg><span style="font-size:0.78rem;">Clear history</span>',
        onclick: () => {
          if (confirm('Clear all search history?')) {
            Storage.clearHistory();
            this.openHistory();
            Toast.show('History cleared', 'success');
          }
        }
      }));
    }
    this.open('Search History', wrap);
  },

  openAbout() {
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'About GhostyEye' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6' }, text: 'GhostyEye is a free, open, client-side OSINT toolkit created by REI. Every search runs entirely in your browser using free public APIs — no servers, no logs, no tracking.' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6', marginTop: '8px' }, text: 'Use it for security research, fraud prevention, identity verification, and digital footprint analysis.' }),
        Utils.el('div', { class: 'text-xs', style: { marginTop: '12px', color: 'var(--accent-cyan)', textShadow: '0 0 4px rgba(0,255,240,0.4)' }, html: 'deployed at: <b>ghostyeye.dpdns</b> · v2.0.0' })
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Features (50+)' }),
        Utils.el('div', { class: 'text-sm text-dim', style: { lineHeight: '1.8' }, html: '• <b>SSE-style Live Stream</b> — real-time intel streaming dashboard<br>• <b>Email validation</b> (format, disposable, MX, alias)<br>• <b>Gravatar</b> profile detection<br>• <b>GitHub</b> account discovery by email<br>• <b>Have I Been Pwned</b> breach checks (billions of records)<br>• <b>Infostealer log checks</b> (GitHub, IntelX, BreachDirectory, LeakCheck, DeHashed)<br>• <b>PGP public key</b> lookup<br>• <b>DNS records</b> (A, AAAA, MX, TXT, NS, CAA, SOA)<br>• <b>100+ platform</b> username search (silent, no alert to target)<br>• <b>AI Profile Synthesis</b> via free LLM (Pollinations.AI)<br>• <b>Risk Assessment</b> with algorithmic scoring + LLM reasoning<br>• <b>SSL Certificate Analysis</b> (crt.sh)<br>• <b>Wayback Machine</b> archive search<br>• <b>Google Dorking Engine</b> (30+ operators)<br>• <b>WHOIS/RDAP</b> deep lookup<br>• <b>Crypto Wallet</b> tracing (BTC/ETH)<br>• <b>Exposed Git Secrets</b> scanner<br>• <b>Subdomain Enumeration++</b> (100+ common + PassiveDNS)<br>• <b>Network Graph</b> (D3.js force-directed)<br>• <b>Email Pattern Predictor</b><br>• <b>Username Similarity Engine</b><br>• <b>Anomaly Detection</b><br>• <b>Breach Timeline</b> (Chart.js)<br>• <b>Geographic Map</b> (Leaflet, dark theme)<br>• <b>Activity Heatmap</b><br>• <b>Command Palette</b> (Ctrl+K, 50 commands)<br>• <b>Bulk CSV Investigation</b> (200 targets)<br>• <b>Continuous Monitoring</b> & Diff Engine<br>• <b>Encrypted Vault</b> (AES-GCM 256-bit)<br>• <b>Audit Log</b> & Paranoia Mode<br>• <b>STIX/JSON-LD/MISP</b> exports<br>• <b>Shareable encrypted links</b><br>• <b>Specialized verticals</b>: Corporate, Crypto, Brand, Threat Actor, Romance Scam' })
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Pricing: 100% Free' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6' }, text: 'GhostyEye has no pricing tiers, no signups, no API keys required (HIBP key is optional for in-app breach results). All features are free for everyone, forever. No daily limits, no rate limits beyond what the underlying free APIs impose.' })
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Credits' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6' }, html: 'Created by <b style="color:var(--accent-green);text-shadow:var(--glow-sm);">REI</b> · <a href="https://ghostyeye.dpdns" target="_blank" rel="noopener" style="color:var(--accent-cyan);">ghostyeye.dpdns</a><br>Built for the OSINT community with ♥ and zero tracking.' })
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Legal & Ethical Use' }),
        Utils.el('p', { class: 'text-xs text-dim', style: { lineHeight: '1.6' }, text: 'This tool is for authorized security research, fraud prevention, and identity verification only. Do not use it for stalking, harassment, doxxing, or any unlawful activity. You are solely responsible for compliance with all applicable laws in your jurisdiction.' })
      ])
    ]);
    this.open('About GhostyEye', wrap);
  },

  openAPI() {
    const wrap = Utils.el('div', { class: 'flex-col gap-3' }, [
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Developer REST API' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6', marginBottom: '12px' }, text: 'GhostyEye exposes a free, no-auth REST API via URL parameters. Open these URLs in any browser or fetch() them from your code to get a downloadable JSON report.' }),
        Utils.el('div', { class: 'api-endpoint' }, [
          Utils.el('div', {}, [
            Utils.el('span', { class: 'api-method get', text: 'GET' }),
            Utils.el('span', { class: 'api-path', text: '?action=email&email=user@example.com' })
          ]),
          Utils.el('div', { class: 'text-xs text-dim', style: { marginTop: '6px' }, text: 'Triggers a full email investigation. Returns JSON with all modules.' })
        ]),
        Utils.el('div', { class: 'api-endpoint' }, [
          Utils.el('div', {}, [
            Utils.el('span', { class: 'api-method get', text: 'GET' }),
            Utils.el('span', { class: 'api-path', text: '?action=username&u=johndoe' })
          ]),
          Utils.el('div', { class: 'text-xs text-dim', style: { marginTop: '6px' }, text: 'Searches 100+ platforms for the username.' })
        ]),
        Utils.el('div', { class: 'api-endpoint' }, [
          Utils.el('div', {}, [
            Utils.el('span', { class: 'api-method get', text: 'GET' }),
            Utils.el('span', { class: 'api-path', text: '?action=domain&d=example.com' })
          ]),
          Utils.el('div', { class: 'text-xs text-dim', style: { marginTop: '6px' }, text: 'Full domain analysis (DNS + subdomains).' })
        ]),
        Utils.el('div', { class: 'api-endpoint' }, [
          Utils.el('div', {}, [
            Utils.el('span', { class: 'api-method get', text: 'GET' }),
            Utils.el('span', { class: 'api-path', text: '?action=ip&ip=8.8.8.8' })
          ]),
          Utils.el('div', { class: 'text-xs text-dim', style: { marginTop: '6px' }, text: 'IP geolocation & reverse DNS.' })
        ])
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'JavaScript Example' }),
        Utils.el('div', { class: 'api-code', html: `<span class="com">// Run an email investigation from your code</span>
<span class="kw">async function</span> <span class="fn">lookupEmail</span>(email) {
  <span class="kw">const</span> url = <span class="str">\`https://ghostyeye.dpdns/?action=email&email=\${email}\`</span>;
  <span class="kw">const</span> res = <span class="kw">await</span> <span class="fn">fetch</span>(url);
  <span class="kw">const</span> json = <span class="kw">await</span> res.<span class="fn">json</span>();
  <span class="kw">return</span> json;
}

<span class="com">// Response includes:</span>
<span class="com">// - validation, gravatar, github, breaches</span>
<span class="com">// - infostealer, pgp, dns, usernames</span>
<span class="com">// - risk (algorithmic score + LLM reasoning)</span>
<span class="com">// - aiSynthesis (LLM profile breakdown)</span>
<span class="kw">const</span> result = <span class="kw">await</span> <span class="fn">lookupEmail</span>(<span class="str">"test@example.com"</span>);
console.<span class="fn">log</span>(result.risk.score); <span class="com">// 0-100</span>
console.<span class="fn">log</span>(result.aiSynthesis); <span class="com">// LLM text</span>` }),
        Utils.el('div', { class: 'api-code', html: `<span class="com">// cURL example</span>
<span class="fn">curl</span> -L <span class="str">"https://ghostyeye.dpdns/?action=email&email=test@example.com"</span> \\
  -o <span class="str">"report.json"</span>` })
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'JSON Export (In-App)' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6' }, text: 'After any investigation, click the "Export JSON" button to download the complete results. The JSON includes all modules, risk assessment, AI synthesis, and metadata — ready for programmatic use.' }),
        Utils.el('p', { class: 'text-xs text-dim', style: { lineHeight: '1.6', marginTop: '8px' }, text: 'No API key, no rate limits, no authentication. Deploy GhostyEye to any static host (GitHub Pages, Netlify, Vercel) and you have a free OSINT API endpoint.' })
      ]),
      Utils.el('div', { class: 'drawer-section' }, [
        Utils.el('h4', { text: 'Self-Host' }),
        Utils.el('p', { class: 'text-sm text-dim', style: { lineHeight: '1.6' }, text: 'GhostyEye is 100% static. Download the ZIP, extract, and host the folder on any web server. No backend, no database, no environment variables. Your instance is your API.' })
      ])
    ]);
    this.open('Developer API', wrap);
  },

  openAPIs() {
    const apis = [
      ['Cloudflare DNS over HTTPS', 'DNS records (A, AAAA, MX, TXT, NS, CAA, SOA)', 'https://developers.cloudflare.com/1.1.1.1/encryption/dns-over-https/'],
      ['Google DNS over HTTPS', 'DNS fallback resolver', 'https://developers.google.com/speed/public-dns/docs/doh'],
      ['Disify', 'Email format, disposable & alias check', 'https://www.disify.com/'],
      ['Kickbox Open API', 'Disposable email detection', 'https://open.kickbox.com/'],
      ['Mailcheck.ai', 'Domain validity & risk', 'https://www.mailcheck.ai/'],
      ['Gravatar', 'Globally recognized avatar profile', 'https://gravatar.com/'],
      ['GitHub API', 'Search users by public email', 'https://docs.github.com/rest'],
      ['Have I Been Pwned', 'Data breach & password check', 'https://haveibeenpwned.com/'],
      ['keys.openpgp.org', 'PGP public key directory', 'https://keys.openpgp.org/'],
      ['Unavatar.io', 'Cross-platform avatar resolver', 'https://unavatar.io/'],
      ['Intelligence X', 'Infostealer log search', 'https://intelx.io/'],
      ['BreachDirectory', 'Free breach database', 'https://breachdirectory.org/'],
      ['LeakCheck', 'Leaked credential search', 'https://leakcheck.io/'],
      ['DeHashed', 'Breached data search engine', 'https://dehashed.com/'],
      ['Pollinations.AI', 'Free LLM for AI synthesis', 'https://pollinations.ai/'],
      ['ipapi.co', 'IP geolocation', 'https://ipapi.co/'],
      ['ipinfo.io', 'IP info (ISP, ASN, hostname)', 'https://ipinfo.io/'],
      ['DuckDuckGo Icons', 'Favicon service', 'https://duckduckgo.com/']
    ];
    const list = apis.map(([name, desc, url]) => Utils.el('div', { class: 'history-item', style: { flexDirection: 'column', alignItems: 'flex-start', gap: '4px' } }, [
      Utils.el('div', { class: 'history-query', text: name }),
      Utils.el('div', { class: 'history-meta', text: desc }),
      Utils.el('a', { class: 'profile-link', href: url, target: '_blank', rel: 'noopener', text: 'Visit →' })
    ]));
    const wrap = Utils.el('div', { class: 'flex-col gap-2' }, [
      Utils.el('p', { class: 'text-sm text-dim', text: 'GhostyEye is powered by these free public APIs. All requests are made directly from your browser.' }),
      ...list
    ]);
    this.open('APIs Used', wrap);
  }
};

/* ============================================================
   Section 12 — Boot
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => UI.init());
